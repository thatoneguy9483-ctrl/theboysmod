#!/bin/sh
./gradlew build && echo "Done. Your mod is in build/libs/"
