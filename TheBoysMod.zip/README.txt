1. Install JDK 17 (https://adoptium.net) if you don't have Java 17.
2. Windows: double-click BUILD.bat   |  Mac/Linux: ./BUILD.sh
   (first run downloads Forge, takes several minutes, needs internet)
3. Take build/libs/theboys-1.0.0.jar and put it in your mods folder with Palladium (Forge 1.20.1).
