1. Install JDK 17 (https://adoptium.net) if you don't have Java 17.
2. Windows: double-click BUILD.bat   |  Mac/Linux: ./BUILD.sh
   (first run downloads Forge, takes several minutes, needs internet)
3. Take build/libs/theboys-1.0.0.jar and put it in your mods folder with Palladium (Forge 1.20.1).


Lamplighter (theboys:lamplighter): he can NOT create fire. Everything he does scales with how much fire he has access to
(reserve on the energy bar + size of the fires around him).
Toggles: Flame Command (draw in existing fire), Flame Blast, Flame Shield.
Presses: Fireball, Flame Burst.
Passives: Flame Lash, Superhuman Recuperation, Superhuman Durability (+1 armor bar).
The bar is Palladium's energy bar, fed from the scoreboard objective theboys_heat (created by the mod automatically).
Give it with: /superpower add theboys:lamplighter <player>

Homelander (theboys:homelander): not in the Compound V pool (give it with /superpower add theboys:homelander <player>).
Flight is Palladium's attribute flight: jump to lift off, then hold sprint to fly fast. Toggles: Super Hearing, Heat Vision.
Passives: Strength (2 tiers), Invulnerability, Rapid Healing, Speed. Fast flight throws a sonic boom.

Gore: Homelander's lasers and post-boom flying impact cut bodies in half when they kill (any player or mob).
No vanilla particles are used by the mod anymore (all custom, see TheBoysMod + ClientSetup).
Homelander X-ray outlines hidden living things through walls (client side only, see client/XrayClient.java).
