1. Install JDK 17 (https://adoptium.net) if you don't have Java 17.
2. Windows: double-click BUILD.bat   |  Mac/Linux: ./BUILD.sh
   (first run downloads Forge, takes several minutes, needs internet)
3. Take build/libs/theboys-1.0.0.jar and put it in your mods folder with Palladium (Forge 1.20.1).


Lamplighter (theboys:lamplighter): he can NOT create fire. Everything he does scales with how much fire he has access to
(reserve on the energy bar + size of the fires around him).
Toggles: Flame Command (draw in existing fire), Flame Blast, Flame Shield.
Presses: Fireball, Flame Burst.
Passives: Flame Lash, Superhuman Recuperation, Superhuman Durability (+1 armor bar).
The bar is Palladium's energy bar, fed from the scoreboard objective theboys_heat (created by the mod automatically).
Give it with: /superpower add theboys:lamplighter <player>

Homelander (theboys:homelander): not in the Compound V pool (give it with /superpower add theboys:homelander <player>).
Flight is Palladium's attribute flight: jump to lift off, then hold sprint to fly fast. Toggles: Super Hearing, Heat Vision, X-Ray Vision.
Passives: Strength (2 tiers), Invulnerability, Rapid Healing, Speed. Fast flight throws a sonic boom.

Gore: Homelander's lasers and post-boom flying impact cut bodies in half when they kill (any player or mob).
No vanilla particles are used by the mod anymore (all custom, see TheBoysMod + ClientSetup).
Heat Vision beams are drawn by the mod itself (client/VisionClient.java), not Palladium's energy beam.
Super Hearing pings come from every server-side sound within 64 blocks and show through walls (client/FxParticle overlay mode).
Homelander X-ray outlines hidden living things through walls (client side only, see client/XrayClient.java).

The Deep (theboys:deep): in the Compound V pool, or /superpower add theboys:deep <player>.
Gills (water breathing), Superhuman Swimming (sprint in water, breach), Dolphin Rider (right-click a dolphin, empty hand), Abyssal Sight,
Aquatic Strength, Deep-Sea Durability, Rapid Healing, Marine Telepathy (toggle: sense sea life, it won't attack you and fights for you), Call of the Deep (press: every sea creature swarms whatever you are looking at).
X-Ray Vision lasts 10s with a 50s cooldown and is drawn with server-sent overlay particles. NetPackets carries dolphin steering input.

Splinter (theboys:splinter): in the Compound V pool, or /superpower add theboys:splinter <player>.
No passives. Press: Split (a clone peels out of you; your armor drops), Merge (pull clones back; looking at one merges only that one).
Right-click your clone with armor to dress it, or a sword/axe/trident to arm it. Sneak + empty hand takes its gear back. Clone gear drops when it dies. Max 8 clones.

Neuman (theboys:neuman): in the Compound V pool, or /superpower add theboys:neuman <player>.
Press: look at someone within 32 blocks and hold your gaze for 1.5s with a clear line of sight; their head bursts and visibly disappears. You are slowed while focusing and any real hit on you breaks it.
Second press (unlockable): focus on up to 4 enemies or players in the cone ahead of you. Passives: Superhuman Strength, Superhuman Durability.
