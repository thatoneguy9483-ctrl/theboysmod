package com.theboys.mod;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraftforge.network.NetworkHooks;

public class CinderBurstEntity extends Entity {
    public static final int DISCARD_AFTER = 420;

    private static final EntityDataAccessor<Float> SCALE = SynchedEntityData.defineId(CinderBurstEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Boolean> LETHAL = SynchedEntityData.defineId(CinderBurstEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Integer> COUNT = SynchedEntityData.defineId(CinderBurstEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> LIFE = SynchedEntityData.defineId(CinderBurstEntity.class, EntityDataSerializers.INT);

    public CinderBurstEntity(EntityType<?> type, Level level) {
        super(type, level);
        this.noPhysics = true;
    }

    @Override
    protected void defineSynchedData() {
        this.entityData.define(SCALE, 1.0f);
        this.entityData.define(LETHAL, false);
        this.entityData.define(COUNT, 30);
        this.entityData.define(LIFE, 160);
    }

    public float getScale() { return this.entityData.get(SCALE); }
    public void setScale(float s) { this.entityData.set(SCALE, s); }
    public boolean isLethal() { return this.entityData.get(LETHAL); }
    public void setLethal(boolean b) { this.entityData.set(LETHAL, b); }

    public int getCount() { return this.entityData.get(COUNT); }
    public void setCount(int c) { this.entityData.set(COUNT, c); }

    public int getLife() { return this.entityData.get(LIFE); }
    public void setLife(int l) { this.entityData.set(LIFE, l); }

    @Override
    public void tick() {
        super.tick();
        if (!this.level().isClientSide && this.tickCount > DISCARD_AFTER) this.discard();
    }

    @Override public boolean shouldBeSaved() { return false; }
    @Override protected void readAdditionalSaveData(CompoundTag tag) {}
    @Override protected void addAdditionalSaveData(CompoundTag tag) {}

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }
}
