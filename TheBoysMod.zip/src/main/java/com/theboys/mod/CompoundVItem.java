package com.theboys.mod;

import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;

import java.util.List;

public class CompoundVItem extends Item {
    public static final List<String> POWER_POOL = List.of(
            "theboys:regeneration",
            "theboys:super_speed",
            "theboys:translucent",
            "theboys:lamplighter",
            "theboys:deep",
            "theboys:splinter",
            "theboys:neuman"
    );

    public CompoundVItem(Properties props) {
        super(props);
    }

    @Override
    public UseAnim getUseAnimation(ItemStack stack) {
        return UseAnim.SPEAR;
    }

    @Override
    public int getUseDuration(ItemStack stack) {
        return 40;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        player.startUsingItem(hand);
        level.playSound(null, player.blockPosition(), SoundEvents.BEACON_POWER_SELECT, SoundSource.PLAYERS, 0.6f, 0.5f);
        return InteractionResultHolder.consume(player.getItemInHand(hand));
    }

    @Override
    public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity entity) {
        if (!level.isClientSide && entity instanceof ServerPlayer player) {
            String power = POWER_POOL.get(level.random.nextInt(POWER_POOL.size()));
            CommandSourceStack src = player.createCommandSourceStack().withPermission(4).withSuppressedOutput();

            player.server.getCommands().performPrefixedCommand(src, "superpower add " + power + " " + player.getStringUUID());

            player.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 160, 0));
            player.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 160, 1));
            player.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 30, 0));
            player.hurt(level.damageSources().magic(), 2.0f);

            ServerLevel sl = (ServerLevel) level;
            sl.sendParticles(TheBoysMod.GLOW_MOTE.get(), player.getX(), player.getY() + 1.0, player.getZ(), 40, 0.4, 0.8, 0.4, 0.05);
            sl.sendParticles(TheBoysMod.GLOW_MOTE.get(), player.getX(), player.getY() + 1.0, player.getZ(), 25, 0.3, 0.7, 0.3, 0.08);
            level.playSound(null, player.blockPosition(), SoundEvents.GENERIC_DRINK, SoundSource.PLAYERS, 1f, 0.6f);
            level.playSound(null, player.blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 1f, 1.4f);
            player.displayClientMessage(Component.literal("Something changed inside you.").withStyle(ChatFormatting.AQUA, ChatFormatting.ITALIC), true);
            if (!player.getAbilities().instabuild) stack.shrink(1);
        }
        return stack;
    }
}
