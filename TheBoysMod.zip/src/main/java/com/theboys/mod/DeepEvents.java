package com.theboys.mod;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.animal.Dolphin;
import net.minecraft.world.entity.animal.Turtle;
import net.minecraft.world.entity.animal.WaterAnimal;
import net.minecraft.world.entity.animal.axolotl.Axolotl;
import net.minecraft.world.entity.monster.Guardian;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingChangeTargetEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Mod.EventBusSubscriber(modid = TheBoysMod.MOD_ID)
public class DeepEvents {
    private static final double SWIM_SPEED = 0.85;
    private static final int BREACH_COOLDOWN = 30;
    private static final double RIDE_SPEED = 1.0;
    private static final double TELEPATHY_RANGE = 40.0;
    private static final double CALL_RANGE = 64.0;
    private static final int CALL_COOLDOWN = 100;
    private static final int CALL_TICKS = 120;
    private static final float WATER_DEFENSE = 0.65f;
    private static final float WATER_STRENGTH = 1.35f;

    private static final String TAG_RIDDEN = "theboys_deep_ridden";
    private static final String REQ_CALL = "theboys_req_call";

    private static final UUID GILLS = UUID.fromString("7e2a9c10-4b3d-4f68-9d21-0e0000000001");
    private static final UUID SWIM = UUID.fromString("7e2a9c10-4b3d-4f68-9d21-0e0000000002");
    private static final UUID RIDER = UUID.fromString("7e2a9c10-4b3d-4f68-9d21-0e0000000003");
    private static final UUID SIGHT = UUID.fromString("7e2a9c10-4b3d-4f68-9d21-0e0000000004");
    private static final UUID STRENGTH = UUID.fromString("7e2a9c10-4b3d-4f68-9d21-0e0000000005");
    private static final UUID DURABILITY = UUID.fromString("7e2a9c10-4b3d-4f68-9d21-0e0000000006");
    private static final UUID TELEPATHY = UUID.fromString("7e2a9c10-4b3d-4f68-9d21-0e0000000007");

    private static class State {
        long callCd, breachCd;
        double lastY;
        boolean wasInWater, nightVision;
        int foeId = -1;
        final Map<Integer, Long> called = new HashMap<>();
        final Map<Integer, Long> hitCd = new HashMap<>();
    }
    private static final Map<UUID, State> STATES = new HashMap<>();
    private static final Map<UUID, float[]> DOLPHIN_INPUT = new HashMap<>();

    public static void setDolphinInput(ServerPlayer p, float forward, float strafe, boolean jump) {
        DOLPHIN_INPUT.put(p.getUUID(), new float[]{Mth.clamp(forward, -1f, 1f), Mth.clamp(strafe, -1f, 1f), jump ? 1f : 0f, p.level().getGameTime()});
    }

    private static boolean has(Player p, Attribute attr, UUID modifier) {
        AttributeInstance a = p.getAttribute(attr);
        return a != null && a.getModifier(modifier) != null;
    }

    private static boolean seaLife(Entity en) {
        return en.isAlive() && (en instanceof WaterAnimal || en instanceof Guardian || en instanceof Axolotl || en instanceof Turtle);
    }

    private static boolean fighter(Entity en) {
        return en instanceof Dolphin || en instanceof Guardian || en instanceof Axolotl;
    }

    private static void cleanup(Player p) {
        p.removeTag(REQ_CALL);
        STATES.remove(p.getUUID());
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        STATES.remove(e.getEntity().getUUID());
        DOLPHIN_INPUT.remove(e.getEntity().getUUID());
    }

    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone e) {
        if (e.isWasDeath()) cleanup(e.getEntity());
    }

    @SubscribeEvent
    public static void onTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.player instanceof ServerPlayer p) || !p.isAlive() || p.isSpectator()) return;

        if (!has(p, Attributes.LUCK, GILLS)) {
            State idle = STATES.remove(p.getUUID());
            if (idle != null && idle.nightVision) p.removeEffect(MobEffects.NIGHT_VISION);
            p.removeTag(REQ_CALL);
            return;
        }

        State s = STATES.computeIfAbsent(p.getUUID(), k -> new State());
        ServerLevel sl = p.serverLevel();
        long now = sl.getGameTime();
        boolean eyes = p.isEyeInFluid(FluidTags.WATER);

        if (eyes) p.setAirSupply(p.getMaxAirSupply());
        swim(p, s, sl, now);
        sight(p, s, eyes);
        if (has(p, Attributes.LUCK, TELEPATHY)) telepathy(p, s, sl, now);
        if (p.removeTag(REQ_CALL)) call(p, s, sl, now);
        pull(p, s, sl, now);
    }

    private static void swim(ServerPlayer p, State s, ServerLevel sl, long now) {
        boolean inWater = p.isInWater();
        double vy = p.getY() - s.lastY;
        s.lastY = p.getY();

        if (has(p, Attributes.LUCK, SWIM)) {
            Vec3 look = p.getLookAngle();
            if (inWater && p.isSprinting()) {
                p.setDeltaMovement(look.scale(SWIM_SPEED));
                p.hurtMarked = true;
                if (p.tickCount % 2 == 0) {
                    sl.sendParticles(TheBoysMod.BUBBLE.get(), p.getX(), p.getY() + 0.9, p.getZ(), 3, 0.3, 0.3, 0.3, 0.02);
                }
            } else if (s.wasInWater && !inWater && vy > 0.2 && now - s.breachCd > BREACH_COOLDOWN) {
                s.breachCd = now;
                p.setDeltaMovement(look.x * 0.9, Math.min(1.4, vy * 1.5 + 0.5), look.z * 0.9);
                p.hurtMarked = true;
                sl.sendParticles(TheBoysMod.WATER_SPLASH.get(), p.getX(), p.getY() + 0.2, p.getZ(), 30, 0.5, 0.2, 0.5, 0.35);
                sl.sendParticles(TheBoysMod.SHOCK_RING.get(), p.getX(), p.getY() + 0.1, p.getZ(), 1, 0, 0, 0, 0);
                sl.playSound(null, p.blockPosition(), SoundEvents.DOLPHIN_JUMP, SoundSource.PLAYERS, 1.0f, 0.8f);
                sl.playSound(null, p.blockPosition(), SoundEvents.PLAYER_SPLASH_HIGH_SPEED, SoundSource.PLAYERS, 1.0f, 1.0f);
            }
        }
        s.wasInWater = inWater;
    }

    private static void sight(ServerPlayer p, State s, boolean eyes) {
        if (!has(p, Attributes.LUCK, SIGHT)) {
            if (s.nightVision) { p.removeEffect(MobEffects.NIGHT_VISION); s.nightVision = false; }
            return;
        }
        if (eyes) {
            MobEffectInstance cur = p.getEffect(MobEffects.NIGHT_VISION);
            if (cur == null || cur.getDuration() < 230) p.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 260, 0, false, false, false));
            s.nightVision = true;
        } else if (s.nightVision) {
            p.removeEffect(MobEffects.NIGHT_VISION);
            s.nightVision = false;
        }
    }

    private static void telepathy(ServerPlayer p, State s, ServerLevel sl, long now) {
        if (now % 10 != 0) return;
        int n = 0;
        for (Entity en : sl.getEntities(p, p.getBoundingBox().inflate(TELEPATHY_RANGE), DeepEvents::seaLife)) {
            if (en.distanceToSqr(p) > TELEPATHY_RANGE * TELEPATHY_RANGE) continue;
            if (n++ >= 40) break;
            sl.sendParticles(p, TheBoysMod.SEA_SENSE.get(), true, en.getX(), en.getY() + en.getBbHeight() + 0.2, en.getZ(), 1, 0, 0, 0, 0);
            if (en instanceof Mob m && !s.called.containsKey(m.getId()) && m.isInWater() && m.getTarget() == null
                    && m.distanceToSqr(p) > 36 && m.distanceToSqr(p) < 576) {
                m.getNavigation().moveTo(p, 1.0);
            }
        }
    }

    private static LivingEntity lookedAt(ServerPlayer p, ServerLevel sl) {
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        Vec3 end = eye.add(look.scale(CALL_RANGE));
        BlockHitResult bh = sl.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        Vec3 stop = bh.getType() == HitResult.Type.MISS ? end : bh.getLocation();
        AABB box = p.getBoundingBox().expandTowards(look.scale(CALL_RANGE)).inflate(1.0);
        EntityHitResult eh = ProjectileUtil.getEntityHitResult(sl, p, eye, stop, box,
                en -> en instanceof LivingEntity && en != p && en.isAlive() && !en.isSpectator() && !seaLife(en));
        return eh != null && eh.getEntity() instanceof LivingEntity le ? le : null;
    }

    private static void call(ServerPlayer p, State s, ServerLevel sl, long now) {
        if (now < s.callCd) return;
        s.callCd = now + CALL_COOLDOWN;

        List<Entity> life = sl.getEntities(p, p.getBoundingBox().inflate(CALL_RANGE), DeepEvents::seaLife);
        LivingEntity foe = lookedAt(p, sl);
        s.foeId = foe == null ? -1 : foe.getId();
        for (Entity en : life) {
            if (en.distanceToSqr(p) > CALL_RANGE * CALL_RANGE) continue;
            s.called.put(en.getId(), now + CALL_TICKS);
            if (foe != null && en instanceof Mob m && fighter(en)) m.setTarget(foe);
        }

        sl.sendParticles(TheBoysMod.SHOCK_RING.get(), p.getX(), p.getY() + 1.0, p.getZ(), 1, 0, 0, 0, 0);
        sl.sendParticles(TheBoysMod.GLOW_MOTE.get(), p.getX(), p.getY() + 1.0, p.getZ(), 40, 1.5, 1.0, 1.5, 0.08);
        sl.sendParticles(TheBoysMod.BUBBLE.get(), p.getX(), p.getY() + 1.0, p.getZ(), 30, 1.2, 1.0, 1.2, 0.05);
        sl.playSound(null, p.blockPosition(), SoundEvents.DOLPHIN_AMBIENT_WATER, SoundSource.PLAYERS, 1.5f, 0.6f);
        sl.playSound(null, p.blockPosition(), SoundEvents.BEACON_POWER_SELECT, SoundSource.PLAYERS, 0.8f, 0.7f);
    }

    private static void pull(ServerPlayer p, State s, ServerLevel sl, long now) {
        if (s.called.isEmpty()) { s.foeId = -1; s.hitCd.clear(); return; }
        Entity foeEntity = s.foeId < 0 ? null : sl.getEntity(s.foeId);
        LivingEntity foe = foeEntity instanceof LivingEntity le && le.isAlive() ? le : null;
        Iterator<Map.Entry<Integer, Long>> it = s.called.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Integer, Long> en = it.next();
            Entity e = sl.getEntity(en.getKey());
            if (e == null || !e.isAlive() || now > en.getValue()) { it.remove(); s.hitCd.remove(en.getKey()); continue; }
            if (!e.isInWater()) continue;
            Vec3 goal = foe != null ? foe.position().add(0, foe.getBbHeight() * 0.5, 0) : p.position().add(0, 1.0, 0);
            Vec3 to = goal.subtract(e.position());
            double d = to.length();
            double reach = foe != null ? e.getBbWidth() * 0.5 + foe.getBbWidth() * 0.5 + 0.9 : 3.5;
            if (d > reach) {
                e.setDeltaMovement(e.getDeltaMovement().scale(0.85).add(to.scale((foe != null ? 0.2 : 0.14) / d)));
            } else if (foe != null && e instanceof Mob m) {
                Long last = s.hitCd.get(m.getId());
                if (last == null || now - last >= 20) {
                    s.hitCd.put(m.getId(), now);
                    AttributeInstance dmg = m.getAttribute(Attributes.ATTACK_DAMAGE);
                    float amount = Math.max(2.0f, dmg == null ? 2.0f : (float) dmg.getValue());
                    foe.hurt(sl.damageSources().mobAttack(m), amount);
                    sl.sendParticles(TheBoysMod.WATER_SPLASH.get(), foe.getX(), foe.getY() + foe.getBbHeight() * 0.5, foe.getZ(), 6, 0.2, 0.2, 0.2, 0.2);
                }
            }
        }
    }

    private static void rally(ServerPlayer p, LivingEntity foe) {
        for (Mob m : p.serverLevel().getEntitiesOfClass(Mob.class, p.getBoundingBox().inflate(24.0), m -> fighter(m) && m.isAlive() && m.getTarget() == null)) {
            m.setTarget(foe);
        }
    }

    @SubscribeEvent
    public static void onHurt(LivingHurtEvent e) {
        LivingEntity victim = e.getEntity();
        if (victim.level().isClientSide) return;
        DamageSource src = e.getSource();

        if (victim instanceof ServerPlayer p) {
            if (has(p, Attributes.LUCK, GILLS) && src.is(DamageTypes.DROWN)) {
                e.setCanceled(true);
                return;
            }
            if (has(p, Attributes.ARMOR, DURABILITY) && p.isInWater() && !src.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
                e.setAmount(e.getAmount() * WATER_DEFENSE);
            }
            if (has(p, Attributes.LUCK, TELEPATHY) && src.getEntity() instanceof LivingEntity atk && atk != p && !seaLife(atk)) rally(p, atk);
        }

        if (src.getEntity() instanceof ServerPlayer a && src.getDirectEntity() == a && victim != a) {
            if (has(a, Attributes.ATTACK_DAMAGE, STRENGTH) && a.isInWater()) e.setAmount(e.getAmount() * WATER_STRENGTH);
            if (has(a, Attributes.LUCK, TELEPATHY) && !seaLife(victim)) rally(a, victim);
        }
    }

    private static boolean commanded(Entity killer) {
        for (State st : STATES.values()) if (st.called.containsKey(killer.getId())) return true;
        for (Player p : killer.level().players()) {
            if (has(p, Attributes.LUCK, TELEPATHY) && p.distanceToSqr(killer) <= CALL_RANGE * CALL_RANGE) return true;
        }
        return false;
    }

    @SubscribeEvent(priority = EventPriority.LOW)
    public static void onDeath(LivingDeathEvent e) {
        LivingEntity t = e.getEntity();
        if (!(t.level() instanceof ServerLevel sl)) return;
        Entity killer = e.getSource().getEntity();
        if (killer == null || killer == t || !seaLife(killer) || !commanded(killer)) return;

        Vec3 at = t.position().add(0, t.getBbHeight() * 0.5, 0);
        Vec3 dir = t.position().subtract(killer.position()).multiply(1, 0, 1);
        dir = dir.lengthSqr() < 1.0E-4 ? new Vec3(0, 0, 1) : dir.normalize();
        float scale = Mth.clamp(0.8f + t.getBbHeight() * 0.5f, 1.0f, 3.0f);

        ImpactBurstEntity blood = new ImpactBurstEntity(TheBoysMod.IMPACT_BURST.get(), sl);
        blood.setPos(at.x, at.y, at.z);
        blood.setYRot((float) (Mth.atan2(-dir.x, dir.z) * 57.29577951308232));
        blood.setLethal(true);
        blood.setCount(100);
        blood.setLife(320);
        blood.setScale(scale);
        sl.addFreshEntity(blood);

        sl.sendParticles(TheBoysMod.BLOOD_DROP.get(), at.x, at.y, at.z, 30, 0.3, 0.3, 0.3, 0.2);
        sl.sendParticles(TheBoysMod.WATER_SPLASH.get(), at.x, at.y, at.z, 60, 0.6, 0.5, 0.6, 0.45);
        sl.sendParticles(TheBoysMod.BUBBLE.get(), at.x, at.y, at.z, 40, 0.5, 0.5, 0.5, 0.08);
        sl.sendParticles(TheBoysMod.SHOCK_RING.get(), at.x, at.y, at.z, 1, 0, 0, 0, 0);
        sl.playSound(null, t.blockPosition(), SoundEvents.PLAYER_ATTACK_CRIT, SoundSource.PLAYERS, 1.2f, 0.6f);
        sl.playSound(null, t.blockPosition(), SoundEvents.HONEY_BLOCK_BREAK, SoundSource.PLAYERS, 1.2f, 0.6f);
        sl.playSound(null, t.blockPosition(), SoundEvents.PLAYER_SPLASH_HIGH_SPEED, SoundSource.PLAYERS, 1.4f, 0.7f);
        sl.playSound(null, t.blockPosition(), SoundEvents.GENERIC_SPLASH, SoundSource.PLAYERS, 1.2f, 0.8f);
        if (!(t instanceof Player)) t.setInvisible(true);
    }

    @SubscribeEvent
    public static void onChangeTarget(LivingChangeTargetEvent e) {
        if (e.getNewTarget() instanceof ServerPlayer p && seaLife(e.getEntity()) && has(p, Attributes.LUCK, TELEPATHY)) {
            e.setNewTarget(null);
        }
    }

    @SubscribeEvent
    public static void onBreakSpeed(PlayerEvent.BreakSpeed e) {
        Player p = e.getEntity();
        if (has(p, Attributes.LUCK, GILLS) && p.isEyeInFluid(FluidTags.WATER)) e.setNewSpeed(e.getNewSpeed() * 5.0f);
    }

    @SubscribeEvent
    public static void onInteract(PlayerInteractEvent.EntityInteract e) {
        if (e.getLevel().isClientSide || e.getHand() != InteractionHand.MAIN_HAND) return;
        if (!(e.getTarget() instanceof Dolphin d) || !(e.getEntity() instanceof ServerPlayer p)) return;
        if (!has(p, Attributes.LUCK, RIDER) || p.isShiftKeyDown() || !p.getMainHandItem().isEmpty() || p.isPassenger() || d.isVehicle()) return;
        if (p.startRiding(d)) {
            p.serverLevel().playSound(null, d.blockPosition(), SoundEvents.DOLPHIN_PLAY, SoundSource.NEUTRAL, 1.0f, 1.0f);
            e.setCanceled(true);
            e.setCancellationResult(InteractionResult.SUCCESS);
        }
    }

    @SubscribeEvent
    public static void onDolphinTick(LivingEvent.LivingTickEvent e) {
        if (!(e.getEntity() instanceof Dolphin d) || d.level().isClientSide) return;
        boolean flagged = d.getPersistentData().getBoolean(TAG_RIDDEN);
        Entity passenger = d.getFirstPassenger();
        if (!(passenger instanceof ServerPlayer p) || !has(p, Attributes.LUCK, RIDER)) {
            if (flagged) {
                d.setNoAi(false);
                d.getPersistentData().remove(TAG_RIDDEN);
            }
            return;
        }
        if (!flagged) {
            d.setNoAi(true);
            d.getPersistentData().putBoolean(TAG_RIDDEN, true);
        }

        d.setTarget(null);
        d.getNavigation().stop();
        d.setAirSupply(d.getMaxAirSupply());

        float yaw = p.getYRot();
        d.setYRot(yaw);
        d.yRotO = yaw;
        d.yBodyRot = yaw;
        d.yBodyRotO = yaw;
        d.yHeadRot = yaw;
        d.yHeadRotO = yaw;
        d.setXRot(Mth.clamp(p.getXRot(), -60.0f, 60.0f));

        Vec3 look = p.getLookAngle();
        Vec3 left = new Vec3(look.z, 0, -look.x);
        if (left.lengthSqr() > 1.0E-6) left = left.normalize();
        Vec3 dm = d.getDeltaMovement();

        float f = p.zza, st = p.xxa;
        boolean jump = false;
        float[] in = DOLPHIN_INPUT.get(p.getUUID());
        if (in != null && p.level().getGameTime() - (long) in[3] <= 5) {
            f = in[0];
            st = in[1];
            jump = in[2] > 0.5f;
        }

        if (d.isInWater()) {
            Vec3 want = look.scale(f * RIDE_SPEED).add(left.scale(st * RIDE_SPEED * 0.6)).add(0, jump ? 0.5 : 0.0, 0);
            d.setDeltaMovement(want.lengthSqr() < 1.0E-4 ? dm.scale(0.9) : dm.lerp(want, 0.25));
            if (want.lengthSqr() > 0.04 && d.tickCount % 3 == 0 && d.level() instanceof ServerLevel sl) {
                sl.sendParticles(TheBoysMod.BUBBLE.get(), d.getX(), d.getY() + 0.3, d.getZ(), 2, 0.3, 0.2, 0.3, 0.02);
            }
        } else if (d.onGround() && f > 0) {
            d.setDeltaMovement(look.x * 0.25, dm.y, look.z * 0.25);
        }
    }
}
