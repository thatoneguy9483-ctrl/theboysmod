package com.theboys.mod;

import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.AbstractHurtingProjectile;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.HitResult;
import net.minecraftforge.network.NetworkHooks;

/**
 * A ball of drawn flame. Its power (the "factor" it was thrown with: how much fire he had access to) decides how big it
 * looks and how hard it detonates. See FlameOrbRenderer.
 */
public class FlameOrbEntity extends AbstractHurtingProjectile {

    private static final int MAX_AGE = 120;
    private static final EntityDataAccessor<Float> POWER = SynchedEntityData.defineId(FlameOrbEntity.class, EntityDataSerializers.FLOAT);

    public FlameOrbEntity(EntityType<? extends FlameOrbEntity> type, Level level) {
        super(type, level);
    }

    public FlameOrbEntity(Level level, LivingEntity owner, double ax, double ay, double az) {
        super(TheBoysMod.FLAME_ORB.get(), owner, ax, ay, az, level);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(POWER, 0.5f);
    }

    public float getPower() { return this.entityData.get(POWER); }
    public void setPower(float f) { this.entityData.set(POWER, f); }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) {
            var r = this.random;
            int n = 2 + (int) (getPower() * 2);
            double spread = 0.15 + 0.15 * getPower();
            for (int i = 0; i < n; i++) {
                this.level().addParticle(getPower() > 0.9 && r.nextBoolean() ? TheBoysMod.FLAME_LICK_BIG.get() : TheBoysMod.FLAME_LICK.get(),
                        this.getX() + (r.nextDouble() - 0.5) * spread * 2, this.getY() + 0.2 + (r.nextDouble() - 0.5) * spread * 2, this.getZ() + (r.nextDouble() - 0.5) * spread * 2,
                        (r.nextDouble() - 0.5) * 0.04, 0.02, (r.nextDouble() - 0.5) * 0.04);
            }
        } else if (this.tickCount > MAX_AGE) {
            this.discard();
        }
    }

    @Override
    protected void onHit(HitResult result) {
        super.onHit(result);
        if (!this.level().isClientSide && this.level() instanceof ServerLevel sl) {
            LamplighterEvents.detonateOrb(sl, this.position().add(0, 0.2, 0), this.getOwner() instanceof ServerPlayer sp ? sp : null, getPower());
            this.discard();
        }
    }

    @Override protected ParticleOptions getTrailParticle() { return TheBoysMod.FLAME_FLOW.get(); }
    @Override protected boolean shouldBurn() { return false; }
    @Override public boolean isPickable() { return false; }
    @Override public boolean hurt(DamageSource source, float amount) { return false; }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }
}
