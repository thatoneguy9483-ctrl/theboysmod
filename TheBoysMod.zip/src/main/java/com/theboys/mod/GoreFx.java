package com.theboys.mod;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;

/**
 * Shared gore: cutting bodies in half, and the same blood burst A-Train's impact uses.
 * To split whatever a hit kills: call markSplit(victim, ...) just BEFORE hurting it. If that hit is fatal, the body is cut in
 * two (and the corpse hidden) automatically when the death event fires.
 */
@Mod.EventBusSubscriber(modid = TheBoysMod.MOD_ID)
public class GoreFx {

    private static final String KEY_SPLIT = "theboys_split_time", KEY_DX = "theboys_split_dx", KEY_DZ = "theboys_split_dz", KEY_DONE = "theboys_split_done";
    private static final int SPLIT_WINDOW_TICKS = 3;

    /** Call right before a hit that should cut its victim in half if it kills. */
    public static void markSplit(LivingEntity victim, Vec3 dir) {
        CompoundTag d = victim.getPersistentData();
        d.putLong(KEY_SPLIT, victim.level().getGameTime());
        d.putDouble(KEY_DX, dir.x);
        d.putDouble(KEY_DZ, dir.z);
    }

    @SubscribeEvent(priority = EventPriority.LOW)
    public static void onDeath(LivingDeathEvent e) {
        LivingEntity t = e.getEntity();
        if (t.level().isClientSide || !(t.level() instanceof ServerLevel sl)) return;
        CompoundTag d = t.getPersistentData();
        if (!d.contains(KEY_SPLIT) || d.getBoolean(KEY_DONE)) return;
        if (sl.getGameTime() - d.getLong(KEY_SPLIT) > SPLIT_WINDOW_TICKS) return;
        d.putBoolean(KEY_DONE, true);
        bisect(sl, t, new Vec3(d.getDouble(KEY_DX), 0, d.getDouble(KEY_DZ)));
    }

    // ---------------- cut in half ----------------
    public static void bisect(ServerLevel sl, LivingEntity t, Vec3 dir) {
        float h = t.getBbHeight();
        Vec3 d = dir.lengthSqr() < 1.0E-4 ? new Vec3(sl.random.nextDouble() - 0.5, 0, sl.random.nextDouble() - 0.5).normalize() : dir.normalize();

        String typeId = String.valueOf(ForgeRegistries.ENTITY_TYPES.getKey(t.getType()));
        boolean player = t instanceof Player;

        ListTag equip = new ListTag();
        for (EquipmentSlot slot : EquipmentSlot.values()) {
            ItemStack st = t.getItemBySlot(slot);
            if (st.isEmpty()) continue;
            CompoundTag c = new CompoundTag();
            c.putString("slot", slot.getName());
            c.put("item", st.save(new CompoundTag()));
            equip.add(c);
        }

        CompoundTag nbt = new CompoundTag();
        if (!player) {
            try {
                t.saveWithoutId(nbt);
                for (String k : new String[]{"Brain", "Attributes", "ActiveEffects", "Inventory", "ForgeData", "ForgeCaps", "Leash", "Health",
                        "HurtTime", "DeathTime", "HurtByTimestamp", "Passengers", "UUID", "Motion", "Fire", "CustomName"}) nbt.remove(k);
                if (nbt.toString().length() > 5000) nbt = new CompoundTag();
            } catch (Exception ex) {
                nbt = new CompoundTag();
            }
        }

        for (int i = 0; i < 2; i++) {
            boolean upper = i == 0;
            SeveredHalfEntity ent = new SeveredHalfEntity(TheBoysMod.SEVERED_HALF.get(), sl);
            ent.setPos(t.getX(), t.getY(), t.getZ());
            ent.setup(typeId, upper, 0.52f, h, t.yBodyRot, player ? t.getUUID() : null, equip, nbt);
            double push = upper ? 0.35 : 0.12;
            ent.setDeltaMovement(d.x * push + (sl.random.nextDouble() - 0.5) * 0.1, upper ? 0.28 : 0.1, d.z * push + (sl.random.nextDouble() - 0.5) * 0.1);
            sl.addFreshEntity(ent);
        }

        // blood: the big lethal burst from the cut, same as A-Train's
        Vec3 at = t.position().add(0, h * 0.52, 0);
        ImpactBurstEntity fx = new ImpactBurstEntity(TheBoysMod.IMPACT_BURST.get(), sl);
        fx.setPos(at.x, at.y, at.z);
        fx.setYRot((float) (Mth.atan2(-d.x, d.z) * 57.29577951308232));
        fx.setLethal(true);
        fx.setCount(110);
        fx.setLife(340);
        fx.setScale(Mth.clamp(0.8f + h * 0.5f, 1.0f, 3.0f));
        sl.addFreshEntity(fx);

        sl.sendParticles(TheBoysMod.BLOOD_DROP.get(), at.x, at.y, at.z, 30, 0.3, 0.3, 0.3, 0.2);
        sl.sendParticles(TheBoysMod.BONE_CHIP.get(), at.x, at.y, at.z, 10, 0.2, 0.2, 0.2, 0.15);
        sl.playSound(null, t.blockPosition(), SoundEvents.PLAYER_ATTACK_CRIT, SoundSource.PLAYERS, 1.2f, 0.6f);
        sl.playSound(null, t.blockPosition(), SoundEvents.SLIME_BLOCK_BREAK, SoundSource.PLAYERS, 1.6f, 0.5f);
        sl.playSound(null, t.blockPosition(), SoundEvents.BONE_BLOCK_BREAK, SoundSource.PLAYERS, 1.2f, 0.6f);

        // the body is gone: hide the corpse (loot and XP still drop normally)
        t.setInvisible(true);
    }

    // ---------------- the same blood a Kinetic Impact makes (for a hit that doesn't kill) ----------------
    public static void impact(ServerPlayer p, LivingEntity t, float dmg, Vec3 dir) {
        ServerLevel sl = p.serverLevel();
        Vec3 at = t.position().add(0, t.getBbHeight() * 0.55, 0);

        ImpactBurstEntity fx = new ImpactBurstEntity(TheBoysMod.IMPACT_BURST.get(), sl);
        fx.setPos(at.x, at.y, at.z);
        fx.setYRot((float) (Mth.atan2(-dir.x, dir.z) * 57.29577951308232));
        fx.setLethal(false);
        fx.setCount(36);
        fx.setLife(160);
        fx.setScale(0.6f + Math.min(0.8f, dmg / 50f));
        sl.addFreshEntity(fx);

        sl.playSound(null, t.blockPosition(), SoundEvents.PLAYER_ATTACK_KNOCKBACK, SoundSource.PLAYERS, 1.4f, 0.7f);
        sl.playSound(null, t.blockPosition(), SoundEvents.HONEY_BLOCK_BREAK, SoundSource.PLAYERS, 1.2f, 0.6f);
    }
}
