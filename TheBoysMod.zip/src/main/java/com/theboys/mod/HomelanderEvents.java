package com.theboys.mod;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.PlayLevelSoundEvent;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.living.LivingKnockBackEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Mod.EventBusSubscriber(modid = TheBoysMod.MOD_ID)
public class HomelanderEvents {
    private static final double VISION_RANGE = 48.0;
    private static final float VISION_DAMAGE = 4.0f;
    private static final int VISION_HIT_INTERVAL = 4;
    private static final int VISION_IGNITE_SECONDS = 5;
    private static final float VISION_EXHAUSTION = 0.05f;

    private static final double HEARING_RANGE = 64.0;
    private static final double HEARING_MIN_RANGE = 2.5;
    private static final int PING_COOLDOWN_TICKS = 6;

    private static final float INVULN_MULT = 0.6f;
    private static final float EXPLOSION_MULT = 0.85f;
    private static final float FIRE_MULT = 0.5f;
    private static final float PROJECTILE_BOUNCE_MAX = 10.0f;

    private static final double STRIKE_KB_1 = 1.8, STRIKE_KB_2 = 3.0, STRIKE_LIFT = 0.4;

    private static final double BOOM_SPEED = 2.0;
    private static final int BOOM_COOLDOWN = 80;
    private static final int BOOM_REARM_TICKS = 20;
    private static final double BOOM_RADIUS = 7.0;
    private static final float BOOM_DAMAGE = 8.0f;

    private static final int SUPERSONIC_TICKS = 80;
    private static final double IMPACT_MIN_SPEED = 0.8;
    private static final float IMPACT_MAX_DAMAGE = 40.0f;
    private static final double IMPACT_DAMAGE_PER_SPEED = 20.0;

    private static final double XRAY_RANGE = 64.0;
    private static final int XRAY_DURATION = 200;
    private static final int XRAY_COOLDOWN = 1000;

    private static final String TAG_FLIGHT = "theboys_hl_flight";

    public static final UUID VISION_MODIFIER = UUID.fromString("6b1d0f42-2c7a-4e53-9a8d-4800000000a2");
    private static final UUID HEARING_MODIFIER = UUID.fromString("6b1d0f42-2c7a-4e53-9a8d-4800000000a3");
    private static final UUID STRENGTH_1_MODIFIER = UUID.fromString("6b1d0f42-2c7a-4e53-9a8d-4800000000a4");
    private static final UUID STRENGTH_2_MODIFIER = UUID.fromString("6b1d0f42-2c7a-4e53-9a8d-4800000000a5");
    private static final UUID INVULN_MODIFIER = UUID.fromString("6b1d0f42-2c7a-4e53-9a8d-4800000000a6");
    public static final UUID XRAY_MODIFIER = UUID.fromString("6b1d0f42-2c7a-4e53-9a8d-4800000000a7");
    private static final UUID FLIGHT_MODIFIER = UUID.fromString("6b1d0f42-2c7a-4e53-9a8d-480000000001");

    private static class State {
        int visionTicks, boomCd, slowTicks;
        boolean xrayActive, xrayWas;
        long xrayEnd, xrayCooldownUntil;
        boolean armed = true;
        long supersonicUntil;
        Vec3 last;
        final ArrayDeque<Vec3> hist = new ArrayDeque<>();
    }
    private static final Map<UUID, State> STATES = new HashMap<>();
    private static final Map<Long, Long> NOISE_COOLDOWN = new HashMap<>();
    private static Attribute flightAttribute;

    private static boolean has(Player p, Attribute attr, UUID modifier) {
        AttributeInstance a = p.getAttribute(attr);
        return a != null && a.getModifier(modifier) != null;
    }

    private static boolean flightOn(Player p) {
        if (p.getTags().contains(TAG_FLIGHT)) return true;
        if (flightAttribute == null) {
            ResourceLocation id = new ResourceLocation("palladium", "flight_speed");
            if (ForgeRegistries.ATTRIBUTES.containsKey(id)) flightAttribute = ForgeRegistries.ATTRIBUTES.getValue(id);
        }
        return flightAttribute != null && has(p, flightAttribute, FLIGHT_MODIFIER);
    }

    private static void cleanup(Player p) {
        p.removeTag(TAG_FLIGHT);
        STATES.remove(p.getUUID());
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) { STATES.remove(e.getEntity().getUUID()); }

    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone e) {
        if (e.isWasDeath()) cleanup(e.getEntity());
    }

    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onHurt(LivingHurtEvent e) {
        LivingEntity victim = e.getEntity();
        if (victim.level().isClientSide) return;
        DamageSource src = e.getSource();

        if (victim instanceof ServerPlayer p && has(p, Attributes.ARMOR, INVULN_MODIFIER)
                && !src.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            if (src.is(DamageTypeTags.IS_PROJECTILE) && e.getAmount() <= PROJECTILE_BOUNCE_MAX) {
                e.setCanceled(true);
                if (p.level() instanceof ServerLevel sl) {
                    sl.sendParticles(TheBoysMod.SPARK.get(), p.getX(), p.getY() + 1.2, p.getZ(), 10, 0.3, 0.4, 0.3, 0.25);
                    sl.playSound(null, p.blockPosition(), SoundEvents.SHIELD_BLOCK, SoundSource.PLAYERS, 0.6f, 1.8f);
                }
                return;
            }
            if (src.is(DamageTypeTags.IS_FALL)) {
                e.setCanceled(true);
                return;
            }
            float mult = src.is(DamageTypeTags.IS_EXPLOSION) ? EXPLOSION_MULT
                    : src.is(DamageTypeTags.IS_FIRE) ? FIRE_MULT : INVULN_MULT;
            e.setAmount(e.getAmount() * mult);
        }

        Entity direct = src.getDirectEntity();
        if (src.getEntity() instanceof ServerPlayer a && direct == a && victim != a) {
            boolean s2 = has(a, Attributes.ATTACK_DAMAGE, STRENGTH_2_MODIFIER);
            boolean s1 = has(a, Attributes.ATTACK_DAMAGE, STRENGTH_1_MODIFIER);
            if (s1 || s2) {
                Vec3 dir = victim.position().subtract(a.position()).multiply(1, 0, 1);
                if (dir.lengthSqr() > 1.0E-4) {
                    dir = dir.normalize();
                    double kb = s2 ? STRIKE_KB_2 : STRIKE_KB_1;
                    victim.setDeltaMovement(victim.getDeltaMovement().add(dir.x * kb, STRIKE_LIFT, dir.z * kb));
                    victim.hurtMarked = true;
                }
                if (a.level() instanceof ServerLevel sl) {
                    sl.sendParticles(TheBoysMod.SPARK.get(), victim.getX(), victim.getY() + victim.getBbHeight() * 0.5, victim.getZ(), 12, 0.3, 0.3, 0.3, 0.3);
                    sl.sendParticles(TheBoysMod.SHOCK_RING.get(), victim.getX(), victim.getY() + victim.getBbHeight() * 0.5, victim.getZ(), 1, 0, 0, 0, 0);
                    sl.playSound(null, victim.blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 0.5f, 1.6f);
                }
            }
        }
    }

    @SubscribeEvent
    public static void onKnockback(LivingKnockBackEvent e) {
        if (e.getEntity() instanceof Player p && !p.level().isClientSide && has(p, Attributes.ARMOR, INVULN_MODIFIER)) e.setCanceled(true);
    }

    @SubscribeEvent
    public static void onTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.player instanceof ServerPlayer p) || !p.isAlive() || p.isSpectator()) return;

        boolean vision = has(p, Attributes.LUCK, VISION_MODIFIER);
        boolean flight = flightOn(p);
        boolean xray = has(p, Attributes.ATTACK_SPEED, XRAY_MODIFIER);
        State existing = STATES.get(p.getUUID());
        if (!vision && !flight && !xray && (existing == null || (!existing.xrayActive && !existing.xrayWas))) {
            if (existing != null) { existing.visionTicks = 0; existing.hist.clear(); existing.last = null; }
            return;
        }
        State s = STATES.computeIfAbsent(p.getUUID(), k -> new State());

        xray(p, s, xray);
        if (vision) vision(p, s); else s.visionTicks = 0;
        if (flight) flight(p, s); else { s.hist.clear(); s.last = null; }
    }

    private static void xrayPulse(ServerPlayer p, ServerLevel sl) {
        Vec3 eye = p.getEyePosition();
        int n = 0;
        for (LivingEntity t : sl.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(XRAY_RANGE), t -> t != p && t.isAlive() && !t.isSpectator())) {
            if (n >= 40) break;
            if (t.distanceToSqr(p) > XRAY_RANGE * XRAY_RANGE) continue;
            Vec3 c = t.getBoundingBox().getCenter();
            if (sl.clip(new ClipContext(eye, c, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p)).getType() == HitResult.Type.MISS) continue;
            n++;
            SimpleParticleType type = t instanceof Enemy ? TheBoysMod.XRAY_RED.get() : t instanceof Player ? TheBoysMod.XRAY_CYAN.get() : TheBoysMod.XRAY_GREEN.get();
            double h = t.getBbHeight();
            for (int i = 0; i < 5; i++) {
                sl.sendParticles(p, type, true, t.getX(), t.getY() + h * (0.1 + 0.2 * i), t.getZ(), 1, 0, 0, 0, 0);
            }
        }
    }

    private static void xray(ServerPlayer p, State s, boolean on) {
        long now = p.level().getGameTime();
        if (s.xrayActive) {
            if (!on || now >= s.xrayEnd) {
                s.xrayActive = false;
                s.xrayCooldownUntil = now + XRAY_COOLDOWN;
                p.displayClientMessage(Component.literal("X-Ray Vision recharging: " + (XRAY_COOLDOWN / 20) + "s"), true);
            } else {
                if (now % 4 == 0) xrayPulse(p, p.serverLevel());
                if ((s.xrayEnd - now) % 20 == 0) p.displayClientMessage(Component.literal("X-Ray Vision: " + ((s.xrayEnd - now) / 20) + "s"), true);
            }
        } else if (on && !s.xrayWas) {
            if (now >= s.xrayCooldownUntil) {
                s.xrayActive = true;
                s.xrayEnd = now + XRAY_DURATION;
                p.playNotifySound(SoundEvents.BEACON_POWER_SELECT, SoundSource.PLAYERS, 0.6f, 1.8f);
            } else {
                p.displayClientMessage(Component.literal("X-Ray Vision recharging: " + ((s.xrayCooldownUntil - now + 19) / 20) + "s"), true);
            }
        }
        s.xrayWas = on;
    }

    private static void vision(ServerPlayer p, State s) {
        s.visionTicks++;
        ServerLevel sl = p.serverLevel();
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        Vec3 end = eye.add(look.scale(VISION_RANGE));

        BlockHitResult bh = sl.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        Vec3 stop = bh.getType() == HitResult.Type.MISS ? end : bh.getLocation();
        AABB box = p.getBoundingBox().expandTowards(look.scale(VISION_RANGE)).inflate(1.0);
        EntityHitResult eh = ProjectileUtil.getEntityHitResult(sl, p, eye, stop, box, en -> !en.isSpectator() && en.isPickable() && en != p);

        Vec3 hit = stop;
        LivingEntity target = null;
        if (eh != null && eh.getEntity() instanceof LivingEntity le) {
            hit = eh.getLocation();
            target = le;
        }

        p.causeFoodExhaustion(VISION_EXHAUSTION);
        sl.sendParticles(TheBoysMod.FLAME_LICK.get(), hit.x, hit.y, hit.z, 2, 0.05, 0.05, 0.05, 0.03);
        sl.sendParticles(TheBoysMod.SPARK.get(), hit.x, hit.y, hit.z, 2, 0.05, 0.05, 0.05, 0.15);
        if (s.visionTicks % 3 == 0) sl.sendParticles(TheBoysMod.SMOKE_PUFF.get(), hit.x, hit.y, hit.z, 1, 0.05, 0.05, 0.05, 0.01);
        if (s.visionTicks == 1) sl.playSound(null, p.blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 0.6f, 2.0f);
        if (s.visionTicks % 10 == 0) sl.playSound(null, BlockPos.containing(hit), SoundEvents.FIRE_EXTINGUISH, SoundSource.PLAYERS, 0.4f, 1.6f);

        if (s.visionTicks % VISION_HIT_INTERVAL != 0) return;

        if (target != null) {
            GoreFx.markSplit(target, look);
            target.setSecondsOnFire(VISION_IGNITE_SECONDS);
            target.invulnerableTime = 0;
            target.hurt(p.damageSources().playerAttack(p), VISION_DAMAGE);
        } else if (bh.getType() == HitResult.Type.BLOCK) {
            BlockPos pos = bh.getBlockPos();
            BlockState st = sl.getBlockState(pos);
            if (st.isFlammable(sl, pos, bh.getDirection())) {
                LamplighterEvents.lightBlock(sl, pos.relative(bh.getDirection()));
            }
        }
    }

    private static boolean hearingOn(ServerPlayer p) {
        return has(p, Attributes.ATTACK_SPEED, HEARING_MODIFIER);
    }

    private static void ping(ServerLevel sl, ServerPlayer listener, Vec3 at) {
        sl.sendParticles(listener, TheBoysMod.PING.get(), true, at.x, at.y, at.z, 1, 0, 0, 0, 0);
    }

    private static void heardNoise(Level level, Vec3 pos, Entity cause) {
        if (!(level instanceof ServerLevel sl)) return;
        ServerPlayer first = null;
        for (ServerPlayer p : sl.players()) {
            if (p == cause || !hearingOn(p)) continue;
            double d = p.position().distanceToSqr(pos);
            if (d > HEARING_RANGE * HEARING_RANGE || d < HEARING_MIN_RANGE * HEARING_MIN_RANGE) continue;
            first = p;
            break;
        }
        if (first == null) return;

        long now = sl.getGameTime();
        long key = BlockPos.asLong(Mth.floor(pos.x / 3.0), Mth.floor(pos.y / 3.0), Mth.floor(pos.z / 3.0));
        Long last = NOISE_COOLDOWN.get(key);
        if (last != null && now - last < PING_COOLDOWN_TICKS) return;
        NOISE_COOLDOWN.put(key, now);
        if (NOISE_COOLDOWN.size() > 800) NOISE_COOLDOWN.clear();

        for (ServerPlayer p : sl.players()) {
            if (p == cause || !hearingOn(p)) continue;
            double d = p.position().distanceToSqr(pos);
            if (d > HEARING_RANGE * HEARING_RANGE || d < HEARING_MIN_RANGE * HEARING_MIN_RANGE) continue;
            ping(sl, p, pos);
        }
    }

    private static boolean audible(SoundSource src) {
        return src != SoundSource.MUSIC && src != SoundSource.AMBIENT && src != SoundSource.MASTER;
    }

    @SubscribeEvent
    public static void onSoundAt(PlayLevelSoundEvent.AtPosition e) {
        if (e.getLevel().isClientSide || e.isCanceled() || e.getSound() == null || !audible(e.getSource())) return;
        heardNoise(e.getLevel(), e.getPosition(), null);
    }

    @SubscribeEvent
    public static void onSoundAtEntity(PlayLevelSoundEvent.AtEntity e) {
        Entity en = e.getEntity();
        if (en == null || en.level().isClientSide || e.isCanceled() || e.getSound() == null || !audible(e.getSource())) return;
        heardNoise(en.level(), en.position().add(0, en.getBbHeight() * 0.5, 0), en);
    }

    @SubscribeEvent
    public static void onChat(ServerChatEvent e) {
        ServerPlayer speaker = e.getPlayer();
        heardNoise(speaker.level(), speaker.position().add(0, speaker.getBbHeight() * 0.5, 0), speaker);
    }

    private static void flight(ServerPlayer p, State s) {
        Vec3 pos = p.position();
        Vec3 delta = s.last == null ? Vec3.ZERO : pos.subtract(s.last);
        if (delta.lengthSqr() > 60 * 60) { delta = Vec3.ZERO; s.hist.clear(); }
        s.last = pos;

        s.hist.addLast(pos);
        while (s.hist.size() > 6) s.hist.removeFirst();
        if (s.boomCd > 0) s.boomCd--;
        long now = p.level().getGameTime();

        if (now <= s.supersonicUntil) impact(p, s, delta, now);

        if (s.hist.size() < 6) return;
        Vec3 first = s.hist.peekFirst();
        double speed = first.distanceTo(pos) / 5.0;
        boolean airborne = !p.onGround() && !p.isFallFlying() && !p.isPassenger() && !p.isInWater();
        boolean notFalling = pos.y - first.y > -speed * 2.5;

        if (speed < BOOM_SPEED * 0.6) {
            if (++s.slowTicks >= BOOM_REARM_TICKS) s.armed = true;
        } else {
            s.slowTicks = 0;
        }

        if (!s.armed || s.boomCd > 0 || !airborne || !notFalling || speed < BOOM_SPEED) return;
        s.armed = false;
        s.boomCd = BOOM_COOLDOWN;
        s.supersonicUntil = now + SUPERSONIC_TICKS;

        ServerLevel sl = p.serverLevel();
        sl.sendParticles(TheBoysMod.SHOCK_RING.get(), pos.x, pos.y + 1.0, pos.z, 1, 0, 0, 0, 0);
        sl.sendParticles(TheBoysMod.SMOKE_PUFF.get(), pos.x, pos.y + 1.0, pos.z, 30, 1.2, 1.0, 1.2, 0.2);
        sl.playSound(null, p.blockPosition(), SoundEvents.WARDEN_SONIC_BOOM, SoundSource.PLAYERS, 1.2f, 1.3f);
        sl.playSound(null, p.blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 1.0f, 0.7f);

        for (LivingEntity t : sl.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(BOOM_RADIUS), t -> t != p && t.isAlive() && !t.isSpectator())) {
            if (t.distanceToSqr(p) > BOOM_RADIUS * BOOM_RADIUS) continue;
            Vec3 away = t.position().subtract(pos);
            away = away.lengthSqr() < 1.0E-4 ? Vec3.ZERO : away.normalize();
            t.hurt(sl.damageSources().sonicBoom(p), BOOM_DAMAGE);
            t.setDeltaMovement(t.getDeltaMovement().add(away.x * 1.2, 0.4, away.z * 1.2));
            t.hurtMarked = true;
        }
    }

    private static void impact(ServerPlayer p, State s, Vec3 delta, long now) {
        double speed = delta.length();
        if (speed < IMPACT_MIN_SPEED) return;
        Vec3 dir = delta.scale(1.0 / speed);
        ServerLevel sl = p.serverLevel();
        AABB box = p.getBoundingBox()
                .expandTowards(-delta.x, -delta.y, -delta.z)
                .expandTowards(delta.x, delta.y, delta.z)
                .inflate(0.7, 0.4, 0.7);
        float dmg = (float) Math.min(IMPACT_MAX_DAMAGE, (speed - 0.3) * IMPACT_DAMAGE_PER_SPEED);
        for (LivingEntity t : sl.getEntitiesOfClass(LivingEntity.class, box, t -> t != p && t.isAlive() && !t.isSpectator())) {
            GoreFx.markSplit(t, dir);
            if (t.hurt(p.damageSources().playerAttack(p), dmg) && !t.isDeadOrDying()) {
                t.setDeltaMovement(dir.x * (1.0 + speed), 0.45, dir.z * (1.0 + speed));
                t.hurtMarked = true;
                GoreFx.impact(p, t, dmg, dir);
            }
        }
    }
}
