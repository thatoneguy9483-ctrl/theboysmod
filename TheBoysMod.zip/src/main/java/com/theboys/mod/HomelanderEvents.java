package com.theboys.mod;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.VanillaGameEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.living.LivingKnockBackEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Homelander. Palladium handles flight (palladium:flight_speed etc.), the laser beam visual and the unlock tree; this class
 * does the parts Palladium can't: bullets bouncing off, taking reduced damage, punches that launch people, heat vision
 * damage (and cutting what it kills in half), super hearing, and the sonic boom with the impact that follows it.
 * X-ray vision is purely client side (see client/XrayClient).
 */
@Mod.EventBusSubscriber(modid = TheBoysMod.MOD_ID)
public class HomelanderEvents {

    // ---------------- tweak these ----------------
    // heat vision
    private static final double VISION_RANGE = 48.0;
    private static final float VISION_DAMAGE = 4.0f;
    private static final int VISION_HIT_INTERVAL = 4;
    private static final int VISION_IGNITE_SECONDS = 5;
    private static final float VISION_EXHAUSTION = 0.05f;        // per tick (4.0 = one hunger point)
    // super hearing: pings only for things that actually make noise
    private static final double HEARING_RANGE = 48.0;
    private static final int PING_COOLDOWN_TICKS = 8;            // per noisemaker, so footsteps don't spam
    // invulnerability
    private static final float INVULN_MULT = 0.6f;               // everything else hurts this much (40% off)
    private static final float EXPLOSION_MULT = 0.85f;
    private static final float FIRE_MULT = 0.5f;
    private static final float PROJECTILE_BOUNCE_MAX = 10.0f;    // projectiles up to this much damage just bounce off
    // strength
    private static final double STRIKE_KB_1 = 1.8, STRIKE_KB_2 = 3.0, STRIKE_LIFT = 0.4;
    // sonic boom
    private static final double BOOM_SPEED = 2.0;                // blocks/tick (40 b/s)
    private static final int BOOM_COOLDOWN = 80;
    private static final int BOOM_REARM_TICKS = 20;              // must slow down this long before another boom
    private static final double BOOM_RADIUS = 7.0;
    private static final float BOOM_DAMAGE = 8.0f;
    // the impact after a boom (same idea as A-Train's run): fly through people while still supersonic
    private static final int SUPERSONIC_TICKS = 80;
    private static final double IMPACT_MIN_SPEED = 0.8;          // blocks/tick
    private static final float IMPACT_MAX_DAMAGE = 40.0f;
    private static final double IMPACT_DAMAGE_PER_SPEED = 20.0;

    private static final String TAG_VISION = "theboys_hl_vision", TAG_HEARING = "theboys_hl_hearing", TAG_FLIGHT = "theboys_hl_flight";

    /** Must match the modifier uuids in homelander.json. */
    private static final UUID VISION_MODIFIER = UUID.fromString("6b1d0f42-2c7a-4e53-9a8d-4800000000a2");
    private static final UUID HEARING_MODIFIER = UUID.fromString("6b1d0f42-2c7a-4e53-9a8d-4800000000a3");
    private static final UUID STRENGTH_1_MODIFIER = UUID.fromString("6b1d0f42-2c7a-4e53-9a8d-4800000000a4");
    private static final UUID STRENGTH_2_MODIFIER = UUID.fromString("6b1d0f42-2c7a-4e53-9a8d-4800000000a5");
    private static final UUID INVULN_MODIFIER = UUID.fromString("6b1d0f42-2c7a-4e53-9a8d-4800000000a6");
    public static final UUID XRAY_MODIFIER = UUID.fromString("6b1d0f42-2c7a-4e53-9a8d-4800000000a7");

    /** Game events that make noise (a sneaking player makes no STEP event, so sneaking really is quiet). */
    private static final Set<GameEvent> NOISY = Set.of(
            GameEvent.STEP, GameEvent.SWIM, GameEvent.SPLASH, GameEvent.HIT_GROUND, GameEvent.BLOCK_DESTROY, GameEvent.BLOCK_PLACE,
            GameEvent.BLOCK_OPEN, GameEvent.BLOCK_CLOSE, GameEvent.EXPLODE, GameEvent.ENTITY_DAMAGE, GameEvent.ENTITY_DIE,
            GameEvent.PROJECTILE_SHOOT, GameEvent.PROJECTILE_LAND, GameEvent.EAT, GameEvent.DRINK, GameEvent.CONTAINER_OPEN,
            GameEvent.CONTAINER_CLOSE, GameEvent.LIGHTNING_STRIKE);

    private static class State {
        int visionTicks, boomCd, slowTicks;
        boolean armed = true;
        long supersonicUntil;
        Vec3 last;
        final ArrayDeque<Vec3> hist = new ArrayDeque<>();
    }
    private static final Map<UUID, State> STATES = new HashMap<>();
    private static final Map<UUID, Long> LAST_PING = new HashMap<>();

    // ---------------- helpers ----------------
    private static boolean has(Player p, Attribute attr, UUID modifier) {
        AttributeInstance a = p.getAttribute(attr);
        return a != null && a.getModifier(modifier) != null;
    }

    private static boolean marked(Player p, String tag, Attribute attr, UUID modifier) {
        return p.getTags().contains(tag) && has(p, attr, modifier);
    }

    private static void cleanup(Player p) {
        p.removeTag(TAG_VISION);
        p.removeTag(TAG_HEARING);
        p.removeTag(TAG_FLIGHT);
        STATES.remove(p.getUUID());
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) { STATES.remove(e.getEntity().getUUID()); }

    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone e) {
        if (e.isWasDeath()) cleanup(e.getEntity());
    }

    // ---------------- invulnerability / strength ----------------
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onHurt(LivingHurtEvent e) {
        LivingEntity victim = e.getEntity();
        if (victim.level().isClientSide) return;
        DamageSource src = e.getSource();

        // ---- he takes reduced damage ----
        if (victim instanceof ServerPlayer p && has(p, Attributes.ARMOR, INVULN_MODIFIER)
                && !src.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            if (src.is(DamageTypeTags.IS_PROJECTILE) && e.getAmount() <= PROJECTILE_BOUNCE_MAX) {
                e.setCanceled(true);
                if (p.level() instanceof ServerLevel sl) {
                    // light projectiles bounce off
                    sl.sendParticles(TheBoysMod.SPARK.get(), p.getX(), p.getY() + 1.2, p.getZ(), 10, 0.3, 0.4, 0.3, 0.25);
                    sl.playSound(null, p.blockPosition(), SoundEvents.SHIELD_BLOCK, SoundSource.PLAYERS, 0.6f, 1.8f);
                }
                return;
            }
            if (src.is(DamageTypeTags.IS_FALL)) {
                e.setCanceled(true);
                return;
            }
            float mult = src.is(DamageTypeTags.IS_EXPLOSION) ? EXPLOSION_MULT
                    : src.is(DamageTypeTags.IS_FIRE) ? FIRE_MULT : INVULN_MULT;
            e.setAmount(e.getAmount() * mult);
        }

        // ---- his punches launch people ----
        Entity direct = src.getDirectEntity();
        if (src.getEntity() instanceof ServerPlayer a && direct == a && victim != a) {
            boolean s2 = has(a, Attributes.ATTACK_DAMAGE, STRENGTH_2_MODIFIER);
            boolean s1 = has(a, Attributes.ATTACK_DAMAGE, STRENGTH_1_MODIFIER);
            if (s1 || s2) {
                Vec3 dir = victim.position().subtract(a.position()).multiply(1, 0, 1);
                if (dir.lengthSqr() > 1.0E-4) {
                    dir = dir.normalize();
                    double kb = s2 ? STRIKE_KB_2 : STRIKE_KB_1;
                    victim.setDeltaMovement(victim.getDeltaMovement().add(dir.x * kb, STRIKE_LIFT, dir.z * kb));
                    victim.hurtMarked = true;
                }
                if (a.level() instanceof ServerLevel sl) {
                    sl.sendParticles(TheBoysMod.SPARK.get(), victim.getX(), victim.getY() + victim.getBbHeight() * 0.5, victim.getZ(), 12, 0.3, 0.3, 0.3, 0.3);
                    sl.sendParticles(TheBoysMod.SHOCK_RING.get(), victim.getX(), victim.getY() + victim.getBbHeight() * 0.5, victim.getZ(), 1, 0, 0, 0, 0);
                    sl.playSound(null, victim.blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 0.5f, 1.6f);
                }
            }
        }
    }

    /** Nothing shoves him around. */
    @SubscribeEvent
    public static void onKnockback(LivingKnockBackEvent e) {
        if (e.getEntity() instanceof Player p && !p.level().isClientSide && has(p, Attributes.ARMOR, INVULN_MODIFIER)) e.setCanceled(true);
    }

    // ---------------- per tick ----------------
    @SubscribeEvent
    public static void onTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.player instanceof ServerPlayer p) || !p.isAlive() || p.isSpectator()) return;

        boolean vision = marked(p, TAG_VISION, Attributes.LUCK, VISION_MODIFIER);
        boolean flight = p.getTags().contains(TAG_FLIGHT);
        if (!vision && !flight) {
            State idle = STATES.get(p.getUUID());
            if (idle != null) { idle.visionTicks = 0; idle.hist.clear(); idle.last = null; }
            return;
        }
        State s = STATES.computeIfAbsent(p.getUUID(), k -> new State());

        if (vision) vision(p, s); else s.visionTicks = 0;
        if (flight) flight(p, s); else { s.hist.clear(); s.last = null; }
    }

    // ---------------- heat vision ----------------
    /** Palladium draws the laser; this finds what it hits, burns it, and cuts it in half if it dies. */
    private static void vision(ServerPlayer p, State s) {
        s.visionTicks++;
        ServerLevel sl = p.serverLevel();
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        Vec3 end = eye.add(look.scale(VISION_RANGE));

        BlockHitResult bh = sl.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        Vec3 stop = bh.getType() == HitResult.Type.MISS ? end : bh.getLocation();
        AABB box = p.getBoundingBox().expandTowards(look.scale(VISION_RANGE)).inflate(1.0);
        EntityHitResult eh = ProjectileUtil.getEntityHitResult(sl, p, eye, stop, box, en -> !en.isSpectator() && en.isPickable() && en != p);

        Vec3 hit = stop;
        LivingEntity target = null;
        if (eh != null && eh.getEntity() instanceof LivingEntity le) {
            hit = eh.getLocation();
            target = le;
        }

        p.causeFoodExhaustion(VISION_EXHAUSTION);
        sl.sendParticles(TheBoysMod.FLAME_LICK.get(), hit.x, hit.y, hit.z, 2, 0.05, 0.05, 0.05, 0.03);
        sl.sendParticles(TheBoysMod.SPARK.get(), hit.x, hit.y, hit.z, 2, 0.05, 0.05, 0.05, 0.15);
        if (s.visionTicks % 3 == 0) sl.sendParticles(TheBoysMod.SMOKE_PUFF.get(), hit.x, hit.y, hit.z, 1, 0.05, 0.05, 0.05, 0.01);
        if (s.visionTicks == 1) sl.playSound(null, p.blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 0.6f, 2.0f);
        if (s.visionTicks % 10 == 0) sl.playSound(null, BlockPos.containing(hit), SoundEvents.FIRE_EXTINGUISH, SoundSource.PLAYERS, 0.4f, 1.6f);

        if (s.visionTicks % VISION_HIT_INTERVAL != 0) return;

        if (target != null) {
            GoreFx.markSplit(target, look);          // if the laser kills, it cuts straight through the body
            target.setSecondsOnFire(VISION_IGNITE_SECONDS);
            target.invulnerableTime = 0;
            target.hurt(p.damageSources().playerAttack(p), VISION_DAMAGE);
        } else if (bh.getType() == HitResult.Type.BLOCK) {
            BlockPos pos = bh.getBlockPos();
            BlockState st = sl.getBlockState(pos);
            if (st.isFlammable(sl, pos, bh.getDirection())) {
                LamplighterEvents.lightBlock(sl, pos.relative(bh.getDirection()));   // scorches whatever can burn
            }
        }
    }

    // ---------------- super hearing: only things that actually make noise ----------------
    private static boolean hearingOn(ServerPlayer p) {
        return marked(p, TAG_HEARING, Attributes.ATTACK_SPEED, HEARING_MODIFIER);
    }

    private static void ping(ServerLevel sl, ServerPlayer listener, Vec3 at) {
        sl.sendParticles(listener, TheBoysMod.PING.get(), true, at.x, at.y, at.z, 1, 0, 0, 0, 0);
    }

    private static void heardNoise(Level level, Vec3 pos, Entity cause) {
        if (!(level instanceof ServerLevel sl)) return;
        boolean any = false;
        for (ServerPlayer p : sl.players()) {
            if (p != cause && hearingOn(p)) { any = true; break; }
        }
        if (!any) return;

        long now = sl.getGameTime();
        Vec3 at = pos;
        if (cause != null) {
            Long last = LAST_PING.get(cause.getUUID());
            if (last != null && now - last < PING_COOLDOWN_TICKS) return;
            LAST_PING.put(cause.getUUID(), now);
            if (LAST_PING.size() > 400) LAST_PING.clear();
            at = cause.position().add(0, cause.getBbHeight() * 0.5, 0);
        }
        for (ServerPlayer p : sl.players()) {
            if (p == cause || !hearingOn(p)) continue;
            if (p.position().distanceToSqr(at) > HEARING_RANGE * HEARING_RANGE) continue;
            ping(sl, p, at);
        }
    }

    @SubscribeEvent
    public static void onGameEvent(VanillaGameEvent e) {
        if (!NOISY.contains(e.getVanillaEvent())) return;
        heardNoise(e.getLevel(), e.getEventPosition(), e.getCause());
    }

    /** He hears what people say, too. */
    @SubscribeEvent
    public static void onChat(ServerChatEvent e) {
        ServerPlayer speaker = e.getPlayer();
        heardNoise(speaker.level(), speaker.position(), speaker);
    }

    // ---------------- flight: sonic boom, then the impact that follows ----------------
    private static void flight(ServerPlayer p, State s) {
        Vec3 pos = p.position();
        Vec3 delta = s.last == null ? Vec3.ZERO : pos.subtract(s.last);
        if (delta.lengthSqr() > 60 * 60) { delta = Vec3.ZERO; s.hist.clear(); }     // teleport / respawn
        s.last = pos;

        s.hist.addLast(pos);
        while (s.hist.size() > 6) s.hist.removeFirst();
        if (s.boomCd > 0) s.boomCd--;
        long now = p.level().getGameTime();

        // keep smashing through whatever is in the way while still supersonic
        if (now <= s.supersonicUntil) impact(p, s, delta, now);

        if (s.hist.size() < 6) return;
        Vec3 first = s.hist.peekFirst();
        double speed = first.distanceTo(pos) / 5.0;
        boolean airborne = !p.onGround() && !p.isFallFlying() && !p.isPassenger() && !p.isInWater();
        boolean notFalling = pos.y - first.y > -speed * 2.5;         // a fast fall is not flying

        if (speed < BOOM_SPEED * 0.6) {
            if (++s.slowTicks >= BOOM_REARM_TICKS) s.armed = true;
        } else {
            s.slowTicks = 0;
        }

        if (!s.armed || s.boomCd > 0 || !airborne || !notFalling || speed < BOOM_SPEED) return;
        s.armed = false;
        s.boomCd = BOOM_COOLDOWN;
        s.supersonicUntil = now + SUPERSONIC_TICKS;

        ServerLevel sl = p.serverLevel();
        sl.sendParticles(TheBoysMod.SHOCK_RING.get(), pos.x, pos.y + 1.0, pos.z, 1, 0, 0, 0, 0);
        sl.sendParticles(TheBoysMod.SMOKE_PUFF.get(), pos.x, pos.y + 1.0, pos.z, 30, 1.2, 1.0, 1.2, 0.2);
        sl.playSound(null, p.blockPosition(), SoundEvents.WARDEN_SONIC_BOOM, SoundSource.PLAYERS, 1.2f, 1.3f);
        sl.playSound(null, p.blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 1.0f, 0.7f);

        for (LivingEntity t : sl.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(BOOM_RADIUS), t -> t != p && t.isAlive() && !t.isSpectator())) {
            if (t.distanceToSqr(p) > BOOM_RADIUS * BOOM_RADIUS) continue;
            Vec3 away = t.position().subtract(pos);
            away = away.lengthSqr() < 1.0E-4 ? Vec3.ZERO : away.normalize();
            t.hurt(sl.damageSources().sonicBoom(p), BOOM_DAMAGE);
            t.setDeltaMovement(t.getDeltaMovement().add(away.x * 1.2, 0.4, away.z * 1.2));
            t.hurtMarked = true;
        }
    }

    /** What A-Train's run does, but at flying speed, and anything it kills is cut in half. */
    private static void impact(ServerPlayer p, State s, Vec3 delta, long now) {
        double speed = delta.length();
        if (speed < IMPACT_MIN_SPEED) return;
        Vec3 dir = delta.scale(1.0 / speed);
        ServerLevel sl = p.serverLevel();
        AABB box = p.getBoundingBox()
                .expandTowards(-delta.x, -delta.y, -delta.z)       // the ground you just covered
                .expandTowards(delta.x, delta.y, delta.z)          // and a bit ahead
                .inflate(0.7, 0.4, 0.7);
        float dmg = (float) Math.min(IMPACT_MAX_DAMAGE, (speed - 0.3) * IMPACT_DAMAGE_PER_SPEED);
        for (LivingEntity t : sl.getEntitiesOfClass(LivingEntity.class, box, t -> t != p && t.isAlive() && !t.isSpectator())) {
            GoreFx.markSplit(t, dir);
            if (t.hurt(p.damageSources().playerAttack(p), dmg) && !t.isDeadOrDying()) {
                t.setDeltaMovement(dir.x * (1.0 + speed), 0.45, dir.z * (1.0 + speed));
                t.hurtMarked = true;
                GoreFx.impact(p, t, dmg, dir);
            }
            // if it died, the death event already cut the body in half
        }
    }
}
