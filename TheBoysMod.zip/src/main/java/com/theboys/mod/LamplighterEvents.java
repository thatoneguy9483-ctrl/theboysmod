package com.theboys.mod;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.block.AbstractFurnaceBlock;
import net.minecraft.world.level.block.BaseFireBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CampfireBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.scores.Objective;
import net.minecraft.world.scores.Scoreboard;
import net.minecraft.world.scores.criteria.ObjectiveCriteria;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Mod.EventBusSubscriber(modid = TheBoysMod.MOD_ID)
public class LamplighterEvents {
    public static final String BAR_OBJECTIVE = "theboys_heat";

    private static final int HEAT_CAP = 1000;
    private static final int HEAT_HARD_CAP = 1200;
    private static final int OVERHEAT_AT = 900;
    private static final int DECAY_EVERY = 12;
    private static final int OVERHEAT_BLEED = 6;

    private static final int DRAW_RANGE = 14;
    private static final int FIRE_GAIN = 120, LAVA_GAIN = 20, CAMPFIRE_GAIN = 12, FURNACE_GAIN = 8, TORCH_GAIN = 3;
    private static final int BURNING_GAIN = 60;
    private static final int LIGHTER_GAIN = 12;
    private static final int LIGHTER_WEAR_EVERY = 80;

    private static final double INTENSITY_FOR_MAX = 8.0;
    private static final double FACTOR_MIN = 0.3, FACTOR_MAX = 2.0;

    private static final double BLAST_RANGE_MIN = 6.0, BLAST_RANGE_PER_F = 8.0;
    private static final double BLAST_CONE_MIN_DEG = 14, BLAST_CONE_PER_F_DEG = 14;
    private static final double BLAST_COST_MIN = 4, BLAST_COST_PER_F = 6;
    private static final double BLAST_DAMAGE_MIN = 4.0, BLAST_DAMAGE_PER_F = 6.0;
    private static final int BLAST_HIT_INTERVAL = 5;
    private static final int BLAST_IGNITE_SECONDS = 8;

    private static final double ORB_COST_MIN = 60, ORB_COST_PER_F = 70;
    private static final int ORB_COOLDOWN = 10;

    private static final double NOVA_COST_MIN = 150, NOVA_COST_PER_F = 120;
    private static final double NOVA_RADIUS_MIN = 5.0, NOVA_RADIUS_PER_F = 6.0;
    private static final double NOVA_DAMAGE_MIN = 10.0, NOVA_DAMAGE_PER_F = 12.0;
    private static final int NOVA_COOLDOWN = 60;

    private static final double SHIELD_RADIUS_MIN = 2.0, SHIELD_RADIUS_PER_F = 1.5;
    private static final double SHIELD_COST_MIN = 2, SHIELD_COST_PER_F = 4;

    private static final double LASH_RANGE = 16.0;
    private static final double LASH_DAMAGE_MIN = 8.0, LASH_DAMAGE_PER_F = 8.0;

    private static final boolean LIGHT_BLOCKS = true;
    private static final int BURN_MEMORY_TICKS = 400;

    private static final String TAG_COMMAND = "theboys_command", TAG_BLAST = "theboys_blast",
            TAG_SHIELD = "theboys_shield", TAG_LASH = "theboys_lash";

    private static final String REQ_ORB = "theboys_req_orb", REQ_NOVA = "theboys_req_nova";
    private static final String KEY_HEAT = "theboys_heat";
    private static final String KEY_BURNER = "theboys_burner", KEY_BURN_TIME = "theboys_burn_time";

    private static final UUID COMMAND_MODIFIER = UUID.fromString("5d3c8b20-6e1f-4a9d-8c47-1f0000000101");
    public static final UUID BLAST_MODIFIER = UUID.fromString("5d3c8b20-6e1f-4a9d-8c47-1f0000000102");
    private static final UUID SHIELD_MODIFIER = UUID.fromString("5d3c8b20-6e1f-4a9d-8c47-1f0000000104");

    private record Src(BlockPos pos, int gain, boolean consumable) {}

    private static class Scan {
        final List<Src> list = new ArrayList<>();
        double intensity;
    }

    private static class State {
        int tick, blastTicks, shieldTicks, orbCd, novaCd;
        Scan scan = new Scan();
    }
    private static final Map<UUID, State> STATES = new HashMap<>();

    private static int getHeat(Player p) { return p.getPersistentData().getInt(KEY_HEAT); }

    private static void setHeat(Player p, int v) {
        int nv = Mth.clamp(v, 0, HEAT_HARD_CAP);
        if (nv == getHeat(p) && p.getPersistentData().contains(KEY_HEAT)) return;
        p.getPersistentData().putInt(KEY_HEAT, nv);
        if (p instanceof ServerPlayer sp) syncBar(sp, nv);
    }

    private static void addHeat(Player p, int d) { setHeat(p, getHeat(p) + d); }

    private static void syncBar(ServerPlayer p, int value) {
        if (p.getServer() == null) return;
        Scoreboard sb = p.getServer().getScoreboard();
        Objective o = sb.getObjective(BAR_OBJECTIVE);
        if (o == null) {
            o = sb.addObjective(BAR_OBJECTIVE, ObjectiveCriteria.DUMMY, Component.literal("Heat"), ObjectiveCriteria.RenderType.INTEGER);
        }
        sb.getOrCreatePlayerScore(p.getScoreboardName(), o).setScore(value);
    }

    private static boolean marked(Player p, String tag, Attribute attr, UUID modifier) {
        AttributeInstance a = p.getAttribute(attr);
        return p.getTags().contains(tag) && a != null && a.getModifier(modifier) != null;
    }

    private static void rememberBurner(ServerPlayer burner, LivingEntity victim) {
        victim.getPersistentData().putUUID(KEY_BURNER, burner.getUUID());
        victim.getPersistentData().putLong(KEY_BURN_TIME, burner.level().getGameTime());
    }

    public static void burn(ServerPlayer p, LivingEntity t, float dmg, int seconds) {
        rememberBurner(p, t);
        t.setSecondsOnFire(seconds);
        t.invulnerableTime = 0;
        t.hurt(p.damageSources().playerAttack(p), dmg);
    }

    public static void lightBlock(ServerLevel sl, BlockPos pos) {
        if (!LIGHT_BLOCKS || !sl.getGameRules().getBoolean(GameRules.RULE_DOFIRETICK)) return;
        if (!sl.getBlockState(pos).isAir()) return;
        BlockState fire = BaseFireBlock.getState(sl, pos);
        if (fire.canSurvive(sl, pos)) sl.setBlockAndUpdate(pos, fire);
    }

    private static void scorchGround(ServerLevel sl, Vec3 pt) {
        BlockPos g = BlockPos.containing(pt);
        for (int k = 0; k < 4; k++) {
            if (sl.getBlockState(g).isAir() && !sl.getBlockState(g.below()).isAir()) { lightBlock(sl, g); return; }
            g = g.below();
        }
    }

    private static Vec3 handPos(ServerPlayer p) {
        return p.getEyePosition().add(p.getLookAngle().scale(0.6)).add(0, -0.35, 0);
    }

    private static Vec3 center(BlockPos pos) { return Vec3.atCenterOf(pos); }

    private static void lick(ServerLevel sl, double x, double y, double z, double vx, double vy, double vz, double f) {
        boolean big = sl.random.nextDouble() < f / 2.0;
        ParticleOptions type = big ? TheBoysMod.FLAME_LICK_BIG.get() : TheBoysMod.FLAME_LICK.get();
        sl.sendParticles(type, x, y, z, 0, vx, vy, vz, 1.0);
    }

    private static void stream(ServerLevel sl, Vec3 from, Vec3 to, int n) {
        var r = sl.random;
        for (int i = 0; i < n; i++) {
            Vec3 a = from.add((r.nextDouble() - 0.5) * 0.5, (r.nextDouble() - 0.5) * 0.5, (r.nextDouble() - 0.5) * 0.5);
            Vec3 v = to.subtract(a).scale(1.0 / 12.0);
            sl.sendParticles(TheBoysMod.FLAME_FLOW.get(), a.x, a.y, a.z, 0, v.x, v.y, v.z, 1.0);
        }
    }

    private static double factor(ServerPlayer p, State s) {
        double held = Math.min(1.0, getHeat(p) / (double) HEAT_CAP);
        double around = Math.min(1.0, s.scan.intensity / INTENSITY_FOR_MAX);
        return Mth.clamp(0.3 + 0.7 * held + 0.9 * around, FACTOR_MIN, FACTOR_MAX);
    }

    private static void cleanup(Player p) {
        p.removeTag(TAG_COMMAND);
        p.removeTag(TAG_BLAST);
        p.removeTag(TAG_SHIELD);
        p.removeTag(REQ_ORB);
        p.removeTag(REQ_NOVA);
        STATES.remove(p.getUUID());
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp && sp.getPersistentData().contains(KEY_HEAT)) syncBar(sp, getHeat(sp));
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) { STATES.remove(e.getEntity().getUUID()); }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent e) {
        STATES.remove(e.getEntity().getUUID());
        if (e.getEntity() instanceof ServerPlayer sp) syncBar(sp, 0);
    }

    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone e) {
        if (e.isWasDeath()) {
            cleanup(e.getEntity());
            e.getEntity().getPersistentData().remove(KEY_HEAT);
        }
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent e) {
        LivingEntity t = e.getEntity();
        if (t.level().isClientSide || !(t.level() instanceof ServerLevel sl)) return;

        if (t instanceof ServerPlayer sp) {
            cleanup(sp);
            sp.getPersistentData().remove(KEY_HEAT);
            syncBar(sp, 0);
        }

        if (!t.getPersistentData().contains(KEY_BURN_TIME)) return;
        long age = sl.getGameTime() - t.getPersistentData().getLong(KEY_BURN_TIME);
        if (age > BURN_MEMORY_TICKS) return;

        DamageSource src = e.getSource();
        UUID burner = t.getPersistentData().hasUUID(KEY_BURNER) ? t.getPersistentData().getUUID(KEY_BURNER) : null;
        boolean fire = src.is(DamageTypeTags.IS_FIRE) || t.isOnFire()
                || (burner != null && src.getEntity() != null && burner.equals(src.getEntity().getUUID()));
        if (!fire) return;

        incinerate(sl, t);
    }

    private static void incinerate(ServerLevel sl, LivingEntity t) {
        Vec3 at = t.position().add(0, t.getBbHeight() * 0.5, 0);

        CinderBurstEntity fx = new CinderBurstEntity(TheBoysMod.CINDER_BURST.get(), sl);
        fx.setPos(at.x, at.y, at.z);
        fx.setLethal(true);
        fx.setScale(Mth.clamp(0.8f + t.getBbHeight() * 0.5f, 1.0f, 3.0f));
        fx.setCount(70);
        fx.setLife(300);
        sl.addFreshEntity(fx);

        sl.sendParticles(TheBoysMod.SMOKE_PUFF.get(), at.x, at.y, at.z, 14, 0.3, 0.4, 0.3, 0.03);
        sl.sendParticles(TheBoysMod.FLAME_LICK.get(), at.x, at.y, at.z, 24, 0.3, 0.5, 0.3, 0.08);
        sl.playSound(null, t.blockPosition(), SoundEvents.GENERIC_BURN, SoundSource.PLAYERS, 1.2f, 0.7f);
        sl.playSound(null, t.blockPosition(), SoundEvents.FIRECHARGE_USE, SoundSource.PLAYERS, 1.4f, 0.6f);
        sl.playSound(null, t.blockPosition(), SoundEvents.LAVA_EXTINGUISH, SoundSource.PLAYERS, 0.8f, 0.8f);

        if (!(t instanceof Player)) t.setInvisible(true);
    }

    @SubscribeEvent
    public static void onTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.player instanceof ServerPlayer p) || !p.isAlive() || p.isSpectator()) return;

        boolean command = marked(p, TAG_COMMAND, Attributes.KNOCKBACK_RESISTANCE, COMMAND_MODIFIER);
        boolean blast = marked(p, TAG_BLAST, Attributes.ARMOR_TOUGHNESS, BLAST_MODIFIER);
        boolean shield = marked(p, TAG_SHIELD, Attributes.ARMOR, SHIELD_MODIFIER);
        boolean lash = p.getTags().contains(TAG_LASH);
        boolean reqOrb = p.removeTag(REQ_ORB);
        boolean reqNova = p.removeTag(REQ_NOVA);
        int heat = getHeat(p);

        if (!command && !blast && !shield && !lash && !reqOrb && !reqNova && heat <= 0) {
            State idle = STATES.get(p.getUUID());
            if (idle != null) { idle.blastTicks = 0; idle.shieldTicks = 0; }
            return;
        }
        State s = STATES.computeIfAbsent(p.getUUID(), k -> new State());
        s.tick++;
        if (s.orbCd > 0) s.orbCd--;
        if (s.novaCd > 0) s.novaCd--;
        ServerLevel sl = p.serverLevel();

        if (heat > 0) {
            if (p.isUnderWater()) {
                if (s.tick % 4 == 0) sl.sendParticles(TheBoysMod.SMOKE_PUFF.get(), p.getX(), p.getY() + 1.0, p.getZ(), 4, 0.3, 0.4, 0.3, 0.02);
                setHeat(p, 0);
            } else if (sl.isRainingAt(p.blockPosition())) {
                addHeat(p, -3);
                if (s.tick % 6 == 0) sl.sendParticles(TheBoysMod.SMOKE_PUFF.get(), p.getX(), p.getY() + 1.2, p.getZ(), 2, 0.3, 0.3, 0.3, 0.01);
            } else if (s.tick % DECAY_EVERY == 0) {
                addHeat(p, -1);
            }
            heat = getHeat(p);
        }

        if (heat > OVERHEAT_AT) {
            addHeat(p, -OVERHEAT_BLEED);
            if (s.tick % 10 == 0) {
                p.setSecondsOnFire(3);
                sl.sendParticles(TheBoysMod.FLAME_LICK.get(), p.getX(), p.getY() + 1.0, p.getZ(), 10, 0.35, 0.7, 0.35, 0.05);
            }
        }

        if (reqOrb || reqNova || ((command || blast || shield || lash) && s.tick % 5 == 0)) {
            s.scan = scan(sl, p.blockPosition());
            if (command && s.tick % 5 == 0) draw(p, s, s.scan);
        }

        if (blast) { s.blastTicks++; blast(p, s); } else s.blastTicks = 0;
        if (shield) { s.shieldTicks++; shield(p, s); } else s.shieldTicks = 0;
        if (lash) lash(p, s);

        if (reqOrb) shootOrb(p, s);
        if (reqNova) nova(p, s);
    }

    private static Scan scan(ServerLevel sl, BlockPos c) {
        Scan out = new Scan();
        for (BlockPos pos : BlockPos.betweenClosed(c.offset(-DRAW_RANGE, -4, -DRAW_RANGE), c.offset(DRAW_RANGE, 5, DRAW_RANGE))) {
            BlockState st = sl.getBlockState(pos);
            if (st.isAir()) continue;
            Block b = st.getBlock();
            int gain = 0;
            boolean consumable = false;
            if (b instanceof BaseFireBlock) { gain = FIRE_GAIN; consumable = true; }
            else if (st.getFluidState().is(FluidTags.LAVA)) gain = LAVA_GAIN;
            else if (b instanceof CampfireBlock && st.hasProperty(BlockStateProperties.LIT) && st.getValue(BlockStateProperties.LIT)) gain = CAMPFIRE_GAIN;
            else if (b instanceof AbstractFurnaceBlock && st.hasProperty(BlockStateProperties.LIT) && st.getValue(BlockStateProperties.LIT)) gain = FURNACE_GAIN;
            else if (st.is(Blocks.TORCH) || st.is(Blocks.WALL_TORCH) || st.is(Blocks.SOUL_TORCH) || st.is(Blocks.SOUL_WALL_TORCH)) gain = TORCH_GAIN;
            if (gain == 0) continue;

            out.list.add(new Src(pos.immutable(), gain, consumable));
            out.intensity += consumable ? 1.0 : (gain >= 5 ? 0.6 : 0.2);
            if (out.list.size() >= 200) break;
        }
        out.list.sort(Comparator.comparingDouble(src -> src.pos().distSqr(c)));
        return out;
    }

    private static void draw(ServerPlayer p, State s, Scan scan) {
        ServerLevel sl = p.serverLevel();
        if (p.isUnderWater()) return;
        if (getHeat(p) >= HEAT_CAP) return;
        double mult = sl.isRainingAt(p.blockPosition()) ? 0.5 : 1.0;
        Vec3 hand = handPos(p);
        int gained = 0;

        int fires = 0, trickles = 0;
        for (Src src : scan.list) {
            if (src.consumable()) {
                if (fires >= 5) continue;
                fires++;
                sl.removeBlock(src.pos(), false);
                gained += src.gain();
                stream(sl, center(src.pos()), hand, 6);
            } else {
                if (trickles >= 8) continue;
                trickles++;
                gained += src.gain();
                stream(sl, center(src.pos()), hand, 2);
            }
        }

        int n = 0;
        for (LivingEntity t : sl.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(DRAW_RANGE), t -> t.isAlive() && t.isOnFire())) {
            if (t == p && getHeat(p) >= OVERHEAT_AT) continue;
            if (n++ >= 4) break;
            t.clearFire();
            gained += BURNING_GAIN;
            stream(sl, t.position().add(0, t.getBbHeight() * 0.5, 0), hand, 5);
        }

        final InteractionHand lh = p.getMainHandItem().is(Items.FLINT_AND_STEEL) ? InteractionHand.MAIN_HAND
                : p.getOffhandItem().is(Items.FLINT_AND_STEEL) ? InteractionHand.OFF_HAND : null;
        if (lh != null) {
            gained += LIGHTER_GAIN;
            sl.sendParticles(TheBoysMod.FLAME_LICK.get(), hand.x, hand.y, hand.z, 1, 0.05, 0.05, 0.05, 0.01);
            if (s.tick % LIGHTER_WEAR_EVERY == 0) {
                p.getItemInHand(lh).hurtAndBreak(1, p, pl -> pl.broadcastBreakEvent(lh));
            }
        }

        if (gained > 0) {
            addHeat(p, (int) (gained * mult));
            if (s.tick % 20 == 0) sl.playSound(null, p.blockPosition(), SoundEvents.FIRE_AMBIENT, SoundSource.PLAYERS, 0.8f, 1.3f);
        }
    }

    private static void blast(ServerPlayer p, State s) {
        ServerLevel sl = p.serverLevel();
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        Vec3 start = handPos(p);
        var r = p.getRandom();

        if (p.isUnderWater()) return;
        double f = factor(p, s);
        int cost = (int) Math.round(BLAST_COST_MIN + BLAST_COST_PER_F * f);
        if (getHeat(p) < cost) {
            if (s.blastTicks % 6 == 0) {
                lick(sl, start.x, start.y, start.z, look.x * 0.15, look.y * 0.15 + 0.02, look.z * 0.15, 0.2);
                sl.sendParticles(TheBoysMod.SMOKE_PUFF.get(), start.x, start.y, start.z, 1, 0.05, 0.05, 0.05, 0.01);
            }
            return;
        }
        addHeat(p, -cost);

        boolean damp = sl.isRainingAt(p.blockPosition());
        double range = BLAST_RANGE_MIN + BLAST_RANGE_PER_F * f;
        double coneDeg = BLAST_CONE_MIN_DEG + BLAST_CONE_PER_F_DEG * f;
        double jitter = 0.08 + 0.14 * f;
        double speed = Math.min(1.1, range / 10.0);
        int count = 3 + (int) Math.round(5 * f);
        for (int i = 0; i < count; i++) {
            double sp = speed * (0.8 + r.nextDouble() * 0.4);
            Vec3 v = look.add((r.nextDouble() - 0.5) * jitter * 2, (r.nextDouble() - 0.5) * jitter * 2, (r.nextDouble() - 0.5) * jitter * 2).scale(sp);
            lick(sl, start.x, start.y, start.z, v.x, v.y, v.z, f);
        }
        if (s.blastTicks % 2 == 0) {
            Vec3 v = look.scale(0.35);
            sl.sendParticles(TheBoysMod.SMOKE_PUFF.get(), start.x, start.y, start.z, 0, v.x, v.y + 0.02, v.z, 1.0);
        }
        if (s.blastTicks == 1 || s.blastTicks % 12 == 0) {
            sl.playSound(null, p.blockPosition(), SoundEvents.BLAZE_SHOOT, SoundSource.PLAYERS, (float) (0.3 + 0.3 * f), (float) (0.9 - 0.3 * f));
        }

        if (s.blastTicks % BLAST_HIT_INTERVAL != 0) return;

        Vec3 end = eye.add(look.scale(range));
        BlockHitResult bh = sl.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        boolean hitBlock = bh.getType() == HitResult.Type.BLOCK;
        double reach = hitBlock ? eye.distanceTo(bh.getLocation()) : range;
        double coneCos = Math.cos(Math.toRadians(coneDeg));
        float dmg = (float) ((BLAST_DAMAGE_MIN + BLAST_DAMAGE_PER_F * f) * (damp ? 0.6 : 1.0));

        AABB box = new AABB(eye, eye.add(look.scale(reach))).inflate(1.0 + 2.0 * f);
        for (LivingEntity t : sl.getEntitiesOfClass(LivingEntity.class, box, t -> t != p && t.isAlive() && !t.isSpectator())) {
            Vec3 to = t.getBoundingBox().getCenter().subtract(eye);
            double dist = to.length();
            if (dist < 1.0E-3 || dist > reach + 0.6) continue;
            if (to.scale(1.0 / dist).dot(look) < coneCos) continue;
            burn(p, t, dmg, BLAST_IGNITE_SECONDS);
        }

        for (int i = 0; i < 2; i++) {
            double d = 1.5 + r.nextDouble() * Math.max(0.0, reach - 1.5);
            scorchGround(sl, eye.add(look.scale(d)));
        }
        if (hitBlock) {
            lightBlock(sl, bh.getBlockPos().relative(bh.getDirection()));
            Vec3 hit = bh.getLocation();
            sl.sendParticles(TheBoysMod.FLAME_LICK.get(), hit.x, hit.y, hit.z, 3 + (int) (4 * f), 0.15, 0.15, 0.15, 0.04);
        }
    }

    private static void shootOrb(ServerPlayer p, State s) {
        ServerLevel sl = p.serverLevel();
        Vec3 look = p.getLookAngle();
        Vec3 hand = handPos(p);
        double f = factor(p, s);
        int cost = (int) Math.round(ORB_COST_MIN + ORB_COST_PER_F * f);
        if (s.orbCd > 0) return;
        if (p.isUnderWater() || getHeat(p) < cost) {
            sl.sendParticles(TheBoysMod.SMOKE_PUFF.get(), hand.x, hand.y, hand.z, 3, 0.1, 0.1, 0.1, 0.01);
            return;
        }
        addHeat(p, -cost);
        s.orbCd = ORB_COOLDOWN;
        FlameOrbEntity orb = new FlameOrbEntity(sl, p, look.x, look.y, look.z);
        orb.setPower((float) f);
        orb.setPos(hand.x + look.x * 0.4, hand.y + look.y * 0.4, hand.z + look.z * 0.4);
        sl.addFreshEntity(orb);
        sl.playSound(null, p.blockPosition(), SoundEvents.BLAZE_SHOOT, SoundSource.PLAYERS, 1.0f, (float) (1.0 - 0.3 * f));
    }

    public static void detonateOrb(ServerLevel sl, Vec3 at, ServerPlayer owner, double f) {
        double radius = 3.0 + 3.5 * f;
        double dmgBase = 12.0 + 14.0 * f;
        for (LivingEntity t : sl.getEntitiesOfClass(LivingEntity.class, new AABB(at, at).inflate(radius),
                t -> t.isAlive() && !t.isSpectator())) {
            double d = t.getBoundingBox().getCenter().distanceTo(at);
            if (d > radius) continue;
            float falloff = (float) (1.0 - d / (radius * 1.4));
            if (owner != null && t == owner) {
                if (d < radius * 0.8) {
                    owner.setSecondsOnFire(4);
                    owner.hurt(sl.damageSources().onFire(), 2.0f * falloff + 1.0f);
                }
            } else if (owner != null) {
                burn(owner, t, (float) dmgBase * falloff, 6);
            }
        }

        int n = 25 + (int) (30 * f);
        for (int i = 0; i < n; i++) {
            var r = sl.random;
            Vec3 v = new Vec3(r.nextGaussian(), r.nextGaussian() * 0.6, r.nextGaussian()).normalize().scale(0.18 * (0.6 + f) * (0.5 + r.nextDouble()));
            lick(sl, at.x, at.y, at.z, v.x, v.y, v.z, f);
        }
        sl.sendParticles(TheBoysMod.SMOKE_PUFF.get(), at.x, at.y, at.z, 6, 0.3, 0.3, 0.3, 0.03);
        CinderBurstEntity fx = new CinderBurstEntity(TheBoysMod.CINDER_BURST.get(), sl);
        fx.setPos(at.x, at.y, at.z);
        fx.setLethal(false);
        fx.setScale((float) (0.5 + 0.5 * f));
        fx.setCount(12 + (int) (12 * f));
        fx.setLife(50);
        sl.addFreshEntity(fx);

        sl.playSound(null, BlockPos.containing(at), SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, (float) (0.4 + 0.3 * f), 1.7f);
        sl.playSound(null, BlockPos.containing(at), SoundEvents.FIRECHARGE_USE, SoundSource.PLAYERS, 1.2f, 0.7f);
        lightBlock(sl, BlockPos.containing(at));
        int patches = 5 + (int) (6 * f);
        for (int i = 0; i < patches; i++) {
            var rr = sl.random;
            scorchGround(sl, at.add((rr.nextDouble() - 0.5) * radius * 1.6, 0.5, (rr.nextDouble() - 0.5) * radius * 1.6));
        }
    }

    private static void nova(ServerPlayer p, State s) {
        ServerLevel sl = p.serverLevel();
        double f = factor(p, s);
        int cost = (int) Math.round(NOVA_COST_MIN + NOVA_COST_PER_F * f);
        if (s.novaCd > 0) return;
        if (p.isUnderWater() || getHeat(p) < cost) {
            sl.sendParticles(TheBoysMod.SMOKE_PUFF.get(), p.getX(), p.getY() + 1.0, p.getZ(), 6, 0.3, 0.4, 0.3, 0.01);
            return;
        }
        addHeat(p, -cost);
        s.novaCd = NOVA_COOLDOWN;

        double radius = NOVA_RADIUS_MIN + NOVA_RADIUS_PER_F * f;
        float dmg = (float) (NOVA_DAMAGE_MIN + NOVA_DAMAGE_PER_F * f);
        Vec3 c = p.position().add(0, 0.9, 0);

        for (LivingEntity t : sl.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(radius), t -> t != p && t.isAlive() && !t.isSpectator())) {
            if (t.distanceToSqr(p) > radius * radius) continue;
            Vec3 away = t.position().subtract(p.position()).multiply(1, 0, 1);
            away = away.lengthSqr() < 1.0E-4 ? new Vec3(0, 0, 0) : away.normalize();
            burn(p, t, dmg, 5);
            t.setDeltaMovement(away.x * (1.4 + 0.9 * f), 0.5, away.z * (1.4 + 0.9 * f));
            t.hurtMarked = true;
        }

        int ring = 28 + (int) (20 * f);
        for (int i = 0; i < ring; i++) {
            double a = i / (double) ring * Math.PI * 2;
            double sp = radius / 10.0;
            lick(sl, c.x, c.y, c.z, Math.cos(a) * sp, 0.02, Math.sin(a) * sp, f);
            lick(sl, c.x, c.y + 0.5, c.z, Math.cos(a) * sp * 0.8, 0.05, Math.sin(a) * sp * 0.8, f);
        }
        sl.sendParticles(TheBoysMod.FLAME_LICK_BIG.get(), c.x, c.y, c.z, 12 + (int) (14 * f), 0.4, 0.4, 0.4, 0.12);
        sl.playSound(null, p.blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 0.7f, 1.4f);
        sl.playSound(null, p.blockPosition(), SoundEvents.BLAZE_SHOOT, SoundSource.PLAYERS, 1.2f, 0.5f);

        for (int i = 0; i < 10; i++) {
            double a = i / 10.0 * Math.PI * 2;
            scorchGround(sl, p.position().add(Math.cos(a) * radius * 0.6, 0.5, Math.sin(a) * radius * 0.6));
        }

        if (f > 1.1) p.setSecondsOnFire(2 + (int) (3 * (f - 1.1)));
    }

    private static void shield(ServerPlayer p, State s) {
        ServerLevel sl = p.serverLevel();
        if (p.isUnderWater()) return;
        double f = factor(p, s);
        int cost = (int) Math.round(SHIELD_COST_MIN + SHIELD_COST_PER_F * f);
        if (getHeat(p) < cost) return;
        addHeat(p, -cost);

        double radius = SHIELD_RADIUS_MIN + SHIELD_RADIUS_PER_F * f;
        double spin = s.shieldTicks * 0.35;
        for (int i = 0; i < 4; i++) {
            double a = spin + i * Math.PI / 2;
            double x = p.getX() + Math.cos(a) * radius, z = p.getZ() + Math.sin(a) * radius;
            double y = p.getY() + 0.3 + sl.random.nextDouble() * 1.5;
            lick(sl, x, y, z, -Math.sin(a) * 0.12, 0.04, Math.cos(a) * 0.12, f);
        }
        if (s.shieldTicks == 1) sl.playSound(null, p.blockPosition(), SoundEvents.BLAZE_SHOOT, SoundSource.PLAYERS, 0.8f, 0.7f);
        if (s.shieldTicks % 20 == 0) sl.playSound(null, p.blockPosition(), SoundEvents.FIRE_AMBIENT, SoundSource.PLAYERS, 1.0f, 0.9f);

        if (s.shieldTicks % 5 != 0) return;
        AABB box = p.getBoundingBox().inflate(radius + 0.5);

        for (LivingEntity t : sl.getEntitiesOfClass(LivingEntity.class, box, t -> t != p && t.isAlive() && !t.isSpectator())) {
            if (t.distanceToSqr(p) > (radius + 0.5) * (radius + 0.5)) continue;
            burn(p, t, (float) (1.5 + 1.5 * f), 3);
            Vec3 away = t.position().subtract(p.position()).multiply(1, 0, 1);
            if (away.lengthSqr() > 1.0E-4) {
                away = away.normalize().scale(0.35);
                t.push(away.x, 0.1, away.z);
                t.hurtMarked = true;
            }
        }

        for (Projectile pr : sl.getEntitiesOfClass(Projectile.class, box, pr -> pr.getOwner() != p && !(pr instanceof FlameOrbEntity))) {
            if (pr.distanceToSqr(p) > (radius + 0.5) * (radius + 0.5)) continue;
            sl.sendParticles(TheBoysMod.FLAME_LICK.get(), pr.getX(), pr.getY(), pr.getZ(), 6, 0.1, 0.1, 0.1, 0.05);
            sl.sendParticles(TheBoysMod.SMOKE_PUFF.get(), pr.getX(), pr.getY(), pr.getZ(), 3, 0.1, 0.1, 0.1, 0.02);
            pr.discard();
        }
    }

    private static boolean hostileTo(ServerPlayer p, LivingEntity t) {
        return t instanceof Enemy || (t instanceof Mob m && m.getTarget() == p);
    }

    private static void lash(ServerPlayer p, State s) {
        if (s.tick % 10 != 0 || s.scan.list.isEmpty()) return;
        ServerLevel sl = p.serverLevel();
        double f = factor(p, s);
        int maxTargets = f > 1.0 ? 5 : 3;
        float dmg = (float) (LASH_DAMAGE_MIN + LASH_DAMAGE_PER_F * f);
        int n = 0;
        for (LivingEntity t : sl.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(LASH_RANGE),
                t -> t != p && t.isAlive() && !t.isSpectator() && hostileTo(p, t))) {
            if (n >= maxTargets) break;
            Src best = null;
            double bestD = 324.0;
            for (Src src : s.scan.list) {
                double d = src.pos().distSqr(t.blockPosition());
                if (d < bestD) { bestD = d; best = src; }
            }
            if (best == null) continue;
            n++;
            Vec3 to = t.position().add(0, t.getBbHeight() * 0.5, 0);
            stream(sl, center(best.pos()), to, 6 + (int) (6 * f));
            sl.sendParticles(TheBoysMod.FLAME_LICK.get(), to.x, to.y, to.z, 8 + (int) (8 * f), 0.25, 0.3, 0.25, 0.06);
            sl.playSound(null, t.blockPosition(), SoundEvents.FIRECHARGE_USE, SoundSource.PLAYERS, 0.6f, 1.2f);
            burn(p, t, dmg, 4);
        }
    }
}
