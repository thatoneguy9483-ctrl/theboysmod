package com.theboys.mod;

import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDamageEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Unkillable limb system. Palladium's "Unkillable" ability just adds the tag below;
 * this class does the rest: fatal hits cost a limb, limbs regrow over time,
 * and you only die once all four are gone.
 */
@Mod.EventBusSubscriber(modid = TheBoysMod.MOD_ID)
public class LimbEvents {

    public static final String TAG_UNKILLABLE = "theboys_unkillable";

    // ---- tweak these ----
    private static final int REGROW_TICKS = 1800;        // time to regrow ONE limb (90 s)
    private static final float SURVIVE_HEALTH_FRACTION = 0.3f;
    private static final double HOP_IMPULSE = 0.24;
    private static final double ONE_LEG_SPEED = -0.92;   // multiplier on walk speed
    private static final double NO_LEGS_SPEED = -0.88;   // crawling

    private static final String KEY = "theboys_limbs";
    private static final int LEFT_ARM = 1, RIGHT_ARM = 2, LEFT_LEG = 4, RIGHT_LEG = 8, ALL = 15;
    private static final int[] REGROW_ORDER = {LEFT_LEG, RIGHT_LEG, LEFT_ARM, RIGHT_ARM};
    private static final UUID SPEED_ID = UUID.fromString("7c1e5a10-4b2d-4c8e-9f31-0a5e00000301");
    private static final UUID JUMP_ID = UUID.fromString("7c1e5a10-4b2d-4c8e-9f31-0a5e00000302");

    // ---------- state helpers ----------
    private static CompoundTag data(ServerPlayer p) {
        CompoundTag root = p.getPersistentData();
        if (!root.contains(KEY)) root.put(KEY, new CompoundTag());
        return root.getCompound(KEY);
    }

    private static int mask(ServerPlayer p) { return data(p).getInt("lost"); }
    private static void setMask(ServerPlayer p, int m) { data(p).putInt("lost", m); }
    private static int armsLost(int m) { return ((m & LEFT_ARM) != 0 ? 1 : 0) + ((m & RIGHT_ARM) != 0 ? 1 : 0); }
    private static int legsLost(int m) { return ((m & LEFT_LEG) != 0 ? 1 : 0) + ((m & RIGHT_LEG) != 0 ? 1 : 0); }

    private static String name(int limb) {
        return switch (limb) {
            case LEFT_ARM -> "left arm";
            case RIGHT_ARM -> "right arm";
            case LEFT_LEG -> "left leg";
            default -> "right leg";
        };
    }

    // ---------- fatal hit => lose a limb ----------
    @SubscribeEvent
    public static void onDamage(LivingDamageEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        if (!p.getTags().contains(TAG_UNKILLABLE)) return;
        if (e.getSource().is(DamageTypeTags.BYPASSES_INVULNERABILITY)) return;   // void, /kill
        if (p.getHealth() - e.getAmount() > 0) return;                           // not fatal

        int m = mask(p);
        if (m == ALL) return;                                                    // nothing left to lose: die

        List<Integer> remaining = new ArrayList<>();
        for (int limb : REGROW_ORDER) if ((m & limb) == 0) remaining.add(limb);
        int limb = remaining.get(p.getRandom().nextInt(remaining.size()));

        setMask(p, m | limb);
        if (data(p).getLong("next") == 0) data(p).putLong("next", p.level().getGameTime() + REGROW_TICKS);

        e.setCanceled(true);
        p.setHealth(Math.max(4.0f, p.getMaxHealth() * SURVIVE_HEALTH_FRACTION));
        p.invulnerableTime = 30;
        gore(p, limb);
        spawnLimb(p, limb);
    }

    private static void spawnLimb(ServerPlayer p, int limb) {
        ServerLevel sl = p.serverLevel();
        SeveredLimbEntity ent = new SeveredLimbEntity(TheBoysMod.SEVERED_LIMB.get(), sl);
        boolean leg = limb == LEFT_LEG || limb == RIGHT_LEG;
        ent.setPos(p.getX(), p.getY() + (leg ? 0.4 : 1.1), p.getZ());
        ent.setLimb(limb);
        ent.setOwner(p.getUUID());
        var r = p.getRandom();
        ent.setDeltaMovement((r.nextDouble() - 0.5) * 0.5, 0.25 + r.nextDouble() * 0.15, (r.nextDouble() - 0.5) * 0.5);
        sl.addFreshEntity(ent);
    }

    private static String tagFor(int limb) {
        return switch (limb) {
            case LEFT_ARM -> "theboys_no_left_arm";
            case RIGHT_ARM -> "theboys_no_right_arm";
            case LEFT_LEG -> "theboys_no_left_leg";
            default -> "theboys_no_right_leg";
        };
    }

    private static void gore(ServerPlayer p, int limb) {
        ServerLevel sl = p.serverLevel();
        double y = p.getY() + ((limb == LEFT_LEG || limb == RIGHT_LEG) ? 0.5 : 1.2);

        // the same custom blood as a Kinetic Impact, but a small, gentle spray
        ImpactBurstEntity fx = new ImpactBurstEntity(TheBoysMod.IMPACT_BURST.get(), sl);
        fx.setPos(p.getX(), y, p.getZ());
        fx.setYRot(p.getRandom().nextFloat() * 360f);
        fx.setLethal(false);
        fx.setScale(0.5f);
        fx.setCount(16);
        fx.setLife(110);
        sl.addFreshEntity(fx);

        sl.sendParticles(TheBoysMod.BONE_CHIP.get(),
                p.getX(), y, p.getZ(), 8, 0.2, 0.2, 0.2, 0.12);
        sl.playSound(null, p.blockPosition(), SoundEvents.BONE_BLOCK_BREAK, SoundSource.PLAYERS, 1.2f, 0.7f);
        sl.playSound(null, p.blockPosition(), SoundEvents.PLAYER_HURT, SoundSource.PLAYERS, 1.0f, 0.6f);
    }

    // ---------- per-tick: regrowth + effects of missing limbs ----------
    @SubscribeEvent
    public static void onTick(TickEvent.PlayerTickEvent e) {
        if (e.phase == TickEvent.Phase.START && e.player.level().isClientSide) {
            clientCrawl(e.player);
            return;
        }
        if (e.phase != TickEvent.Phase.END || !(e.player instanceof ServerPlayer p) || !p.isAlive()) return;
        CompoundTag d = data(p);
        int m = d.getInt("lost");

        if (m != 0) {
            long now = p.level().getGameTime();
            long next = d.getLong("next");
            if (next == 0) {
                d.putLong("next", now + REGROW_TICKS);
            } else if (now >= next) {
                for (int limb : REGROW_ORDER) {
                    if ((m & limb) != 0) {
                        m &= ~limb;
                        regrowFx(p, limb);
                        break;
                    }
                }
                d.putInt("lost", m);
                d.putLong("next", m == 0 ? 0 : now + REGROW_TICKS);
            }
        }
        applyEffects(p, m, d);
    }

    /** Forced poses aren't synced, so the client re-applies the crawl pose itself (detected via the synced speed modifier). */
    private static void clientCrawl(net.minecraft.world.entity.player.Player p) {
        AttributeInstance sp = p.getAttribute(Attributes.MOVEMENT_SPEED);
        AttributeModifier mod = sp == null ? null : sp.getModifier(SPEED_ID);
        boolean crawl = mod != null && mod.getAmount() == NO_LEGS_SPEED;
        if (crawl) {
            p.setForcedPose(Pose.SWIMMING);
            p.getPersistentData().putBoolean("theboys_crawl_c", true);
        } else if (p.getPersistentData().getBoolean("theboys_crawl_c")) {
            p.setForcedPose(null);
            p.getPersistentData().putBoolean("theboys_crawl_c", false);
        }
    }

    private static void regrowFx(ServerPlayer p, int limb) {
        ServerLevel sl = p.serverLevel();
        sl.sendParticles(TheBoysMod.BLOOD_DROP.get(),
                p.getX(), p.getY() + 1.0, p.getZ(), 35, 0.3, 0.5, 0.3, 0.05);
        sl.playSound(null, p.blockPosition(), SoundEvents.SLIME_BLOCK_PLACE, SoundSource.PLAYERS, 1f, 0.5f);
    }

    private static void applyEffects(ServerPlayer p, int m, CompoundTag d) {
        int legs = legsLost(m), arms = armsLost(m);

        // tags drive Palladium's body-part hiding abilities (see regeneration.json)
        for (int limb : REGROW_ORDER) {
            String t = tagFor(limb);
            boolean lost = (m & limb) != 0;
            if (lost && !p.getTags().contains(t)) p.addTag(t);
            else if (!lost && p.getTags().contains(t)) p.removeTag(t);
        }

        // legs: slow walk (hop is added in the jump event), crawl with none
        double speed = legs == 0 ? 0 : legs == 1 ? ONE_LEG_SPEED : NO_LEGS_SPEED;
        setModifier(p.getAttribute(Attributes.MOVEMENT_SPEED), SPEED_ID, speed, AttributeModifier.Operation.MULTIPLY_TOTAL);
        Attribute jump = ForgeRegistries.ATTRIBUTES.getValue(new ResourceLocation("palladium", "jump_power"));
        if (jump != null) setModifier(p.getAttribute(jump), JUMP_ID, legs == 2 ? -1.0 : 0, AttributeModifier.Operation.ADDITION);
        if (legs > 0) p.setSprinting(false);

        if (legs == 2) {
            p.setForcedPose(Pose.SWIMMING);
            d.putBoolean("crawl", true);
        } else if (d.getBoolean("crawl")) {
            p.setForcedPose(null);
            d.putBoolean("crawl", false);
        }

        // arms: swing with the arm you still have
        if (arms == 1) {
            HumanoidArm intact = (m & LEFT_ARM) != 0 ? HumanoidArm.RIGHT : HumanoidArm.LEFT;
            if (p.getMainArm() != intact) {
                if (!d.contains("origArm")) d.putInt("origArm", p.getMainArm().ordinal());
                p.setMainArm(intact);
            }
        } else if (d.contains("origArm")) {
            p.setMainArm(HumanoidArm.values()[d.getInt("origArm")]);
            d.remove("origArm");
        }

        // can't hold anything in a missing arm
        if (arms >= 1) dropHeld(p, InteractionHand.OFF_HAND);
        if (arms == 2) dropHeld(p, InteractionHand.MAIN_HAND);
    }

    private static void setModifier(AttributeInstance inst, UUID id, double amount, AttributeModifier.Operation op) {
        if (inst == null) return;
        AttributeModifier cur = inst.getModifier(id);
        if (amount == 0) {
            if (cur != null) inst.removeModifier(id);
        } else if (cur == null || cur.getAmount() != amount) {
            inst.removeModifier(id);
            inst.addTransientModifier(new AttributeModifier(id, "theboys_limb_loss", amount, op));
        }
    }

    private static void dropHeld(ServerPlayer p, InteractionHand hand) {
        ItemStack s = p.getItemInHand(hand);
        if (s.isEmpty()) return;
        p.drop(s.copy(), false);
        p.setItemInHand(hand, ItemStack.EMPTY);
    }

    // ---------- hopping on one leg / no jumping with none ----------
    @SubscribeEvent
    public static void onJump(LivingEvent.LivingJumpEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        if (legsLost(mask(p)) != 1) return;
        float f = p.zza, s = p.xxa;
        if (f == 0 && s == 0) return;
        double yaw = Math.toRadians(p.getYRot());
        double dx = -Math.sin(yaw) * f + Math.cos(yaw) * s;
        double dz = Math.cos(yaw) * f + Math.sin(yaw) * s;
        double len = Math.sqrt(dx * dx + dz * dz);
        if (len < 1.0E-4) return;
        Vec3 m = p.getDeltaMovement();
        p.setDeltaMovement(m.x + dx / len * HOP_IMPULSE, m.y, m.z + dz / len * HOP_IMPULSE);
        p.hurtMarked = true;
    }

    // ---------- arm restrictions ----------
    private static boolean cantUse(ServerPlayer p, InteractionHand hand) {
        int arms = armsLost(mask(p));
        return arms == 2 || (arms == 1 && hand == InteractionHand.OFF_HAND);
    }

    private static void block(PlayerInteractEvent e) {
        if (e.getEntity() instanceof ServerPlayer p && cantUse(p, e.getHand())) e.setCanceled(true);
    }

    @SubscribeEvent public static void onRightClickItem(PlayerInteractEvent.RightClickItem e) { block(e); }
    @SubscribeEvent public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock e) { block(e); }
    @SubscribeEvent public static void onLeftClickBlock(PlayerInteractEvent.LeftClickBlock e) { block(e); }
    @SubscribeEvent public static void onEntityInteract(PlayerInteractEvent.EntityInteract e) { block(e); }

    @SubscribeEvent
    public static void onAttack(AttackEntityEvent e) {
        if (e.getEntity() instanceof ServerPlayer p && armsLost(mask(p)) == 2) e.setCanceled(true);
    }

    // ---------- reset on death ----------
    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone e) {
        if (e.isWasDeath()) {
            e.getEntity().getPersistentData().remove(KEY);
            for (int limb : REGROW_ORDER) e.getEntity().removeTag(tagFor(limb));
        }
    }
}
