package com.theboys.mod;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import com.theboys.mod.client.HeadlessClient;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.Optional;
import java.util.function.Supplier;

public class NetPackets {
    private static final String VERSION = "1";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(TheBoysMod.MOD_ID, "main"), () -> VERSION, VERSION::equals, VERSION::equals);

    public static void init() {
        CHANNEL.registerMessage(0, DolphinInputPacket.class, DolphinInputPacket::encode, DolphinInputPacket::decode, DolphinInputPacket::handle);
        CHANNEL.registerMessage(1, HeadlessPacket.class, HeadlessPacket::encode, HeadlessPacket::decode, HeadlessPacket::handle, Optional.of(NetworkDirection.PLAY_TO_CLIENT));
    }

    public static class DolphinInputPacket {
        private final float forward, strafe;
        private final boolean jump;

        public DolphinInputPacket(float forward, float strafe, boolean jump) {
            this.forward = forward;
            this.strafe = strafe;
            this.jump = jump;
        }

        public static void encode(DolphinInputPacket p, FriendlyByteBuf buf) {
            buf.writeFloat(p.forward);
            buf.writeFloat(p.strafe);
            buf.writeBoolean(p.jump);
        }

        public static DolphinInputPacket decode(FriendlyByteBuf buf) {
            return new DolphinInputPacket(buf.readFloat(), buf.readFloat(), buf.readBoolean());
        }

        public static void handle(DolphinInputPacket p, Supplier<NetworkEvent.Context> ctx) {
            NetworkEvent.Context c = ctx.get();
            ServerPlayer sender = c.getSender();
            c.enqueueWork(() -> {
                if (sender != null) DeepEvents.setDolphinInput(sender, p.forward, p.strafe, p.jump);
            });
            c.setPacketHandled(true);
        }
    }

    public static class HeadlessPacket {
        private final int id;

        public HeadlessPacket(int id) {
            this.id = id;
        }

        public static void encode(HeadlessPacket p, FriendlyByteBuf buf) {
            buf.writeInt(p.id);
        }

        public static HeadlessPacket decode(FriendlyByteBuf buf) {
            return new HeadlessPacket(buf.readInt());
        }

        public static void handle(HeadlessPacket p, Supplier<NetworkEvent.Context> ctx) {
            NetworkEvent.Context c = ctx.get();
            c.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> HeadlessClient.mark(p.id)));
            c.setPacketHandled(true);
        }
    }
}
