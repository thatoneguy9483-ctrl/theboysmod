package com.theboys.mod;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDamageEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Mod.EventBusSubscriber(modid = TheBoysMod.MOD_ID)
public class NeumanEvents {
    private static final double RANGE = 32.0;
    private static final double SWEEP_RANGE = 20.0;
    private static final double SWEEP_CONE = 0.82;
    private static final double AIM_ASSIST = 0.99;
    private static final double FOCUS_CONE = 0.9;
    private static final int PRESSURE_TICKS = 30;
    private static final int SWEEP_PRESSURE_TICKS = 45;
    private static final int SWEEP_STAGGER = 4;
    private static final int SWEEP_MAX = 4;
    private static final int POP_COOLDOWN = 160;
    private static final int SWEEP_COOLDOWN = 900;
    private static final int HIT_LOCKOUT = 60;

    private static final String REQ_POP = "theboys_req_pop";
    private static final String REQ_SWEEP = "theboys_req_sweep";

    private static class Pending {
        final UUID target;
        final long popAt;

        Pending(UUID target, long popAt) {
            this.target = target;
            this.popAt = popAt;
        }
    }

    private static final Map<UUID, List<Pending>> PENDING = new HashMap<>();
    private static final Map<UUID, Long> POP_CD = new HashMap<>();
    private static final Map<UUID, Long> SWEEP_CD = new HashMap<>();

    @SubscribeEvent
    public static void onTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.player instanceof ServerPlayer p) || !p.isAlive() || p.isSpectator()) return;
        boolean pop = p.removeTag(REQ_POP);
        boolean sweep = p.removeTag(REQ_SWEEP);
        ServerLevel sl = p.serverLevel();
        long now = sl.getGameTime();
        List<Pending> list = PENDING.computeIfAbsent(p.getUUID(), k -> new ArrayList<>());

        if (list.isEmpty()) {
            if (pop && now >= POP_CD.getOrDefault(p.getUUID(), 0L)) {
                POP_CD.put(p.getUUID(), now + POP_COOLDOWN);
                LivingEntity t = lookedAt(p, sl);
                if (t != null) queue(p, sl, t, now + PRESSURE_TICKS);
            } else if (sweep && now >= SWEEP_CD.getOrDefault(p.getUUID(), 0L)) {
                SWEEP_CD.put(p.getUUID(), now + SWEEP_COOLDOWN);
                sweep(p, sl, now);
            }
        }

        if (list.isEmpty()) return;
        p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 5, 1, false, false, false));

        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        Iterator<Pending> it = list.iterator();
        while (it.hasNext()) {
            Pending pd = it.next();
            Entity en = sl.getEntity(pd.target);
            if (!(en instanceof LivingEntity t) || !t.isAlive() || t.distanceToSqr(p) > RANGE * RANGE || !p.hasLineOfSight(t)) {
                it.remove();
                continue;
            }
            Vec3 to = t.getEyePosition().subtract(eye);
            if (to.lengthSqr() > 1.0E-4 && to.normalize().dot(look) < FOCUS_CONE) {
                it.remove();
                continue;
            }
            if (now >= pd.popAt) {
                it.remove();
                pop(p, sl, t);
            } else if (now % 2 == 0) {
                Vec3 head = t.getEyePosition();
                sl.sendParticles(TheBoysMod.BLOOD_DROP.get(), head.x, head.y - 0.1, head.z, 2, 0.12, 0.05, 0.12, 0.02);
            }
        }
    }

    @SubscribeEvent
    public static void onDamage(LivingDamageEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p) || e.getAmount() < 1.0f) return;
        List<Pending> list = PENDING.get(p.getUUID());
        if (list == null || list.isEmpty()) return;
        list.clear();
        long until = p.level().getGameTime() + HIT_LOCKOUT;
        POP_CD.merge(p.getUUID(), until, Math::max);
        SWEEP_CD.merge(p.getUUID(), until, Math::max);
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) PENDING.remove(p.getUUID());
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        UUID id = e.getEntity().getUUID();
        PENDING.remove(id);
        POP_CD.remove(id);
        SWEEP_CD.remove(id);
    }

    private static void queue(ServerPlayer p, ServerLevel sl, LivingEntity t, long popAt) {
        sl.playSound(null, t.blockPosition(), SoundEvents.WARDEN_HEARTBEAT, SoundSource.PLAYERS, 0.7f, 1.0f);
        List<Pending> list = PENDING.computeIfAbsent(p.getUUID(), k -> new ArrayList<>());
        for (Pending pd : list) if (pd.target.equals(t.getUUID())) return;
        list.add(new Pending(t.getUUID(), popAt));
    }

    private static boolean valid(ServerPlayer p, Entity en) {
        if (!(en instanceof LivingEntity le) || en == p || !le.isAlive() || le.isSpectator()) return false;
        if (le instanceof Player pl && pl.getAbilities().invulnerable) return false;
        return true;
    }

    private static LivingEntity lookedAt(ServerPlayer p, ServerLevel sl) {
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        Vec3 end = eye.add(look.scale(RANGE));
        BlockHitResult bh = sl.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        Vec3 stop = bh.getType() == HitResult.Type.MISS ? end : bh.getLocation();
        AABB box = p.getBoundingBox().expandTowards(look.scale(RANGE)).inflate(1.0);
        EntityHitResult eh = ProjectileUtil.getEntityHitResult(sl, p, eye, stop, box, en -> valid(p, en));
        if (eh != null && eh.getEntity() instanceof LivingEntity le) return le;

        LivingEntity best = null;
        double bestDot = AIM_ASSIST;
        for (LivingEntity c : sl.getEntitiesOfClass(LivingEntity.class, box, en -> valid(p, en))) {
            Vec3 to = c.getEyePosition().subtract(eye);
            double dist = to.length();
            if (dist > RANGE || dist < 1.0E-3) continue;
            double dot = to.normalize().dot(look);
            if (dot > bestDot && p.hasLineOfSight(c)) {
                bestDot = dot;
                best = c;
            }
        }
        return best;
    }

    private static boolean sweepTarget(ServerPlayer p, LivingEntity le) {
        if (le instanceof Enemy || le instanceof Player) return true;
        return le instanceof Mob m && m.getTarget() == p;
    }

    private static void sweep(ServerPlayer p, ServerLevel sl, long now) {
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        List<LivingEntity> seen = new ArrayList<>();
        for (LivingEntity c : sl.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(SWEEP_RANGE), en -> valid(p, en))) {
            if (!sweepTarget(p, c) || c.distanceToSqr(p) > SWEEP_RANGE * SWEEP_RANGE) continue;
            Vec3 to = c.getEyePosition().subtract(eye);
            if (to.lengthSqr() < 1.0E-4 || to.normalize().dot(look) < SWEEP_CONE) continue;
            if (!p.hasLineOfSight(c)) continue;
            seen.add(c);
        }
        seen.sort(Comparator.comparingDouble(c -> c.distanceToSqr(p)));
        int n = 0;
        for (LivingEntity c : seen) {
            if (n >= SWEEP_MAX) break;
            queue(p, sl, c, now + SWEEP_PRESSURE_TICKS + n * SWEEP_STAGGER);
            n++;
        }
    }

    private static void pop(ServerPlayer p, ServerLevel sl, LivingEntity t) {
        Vec3 head = t.getEyePosition();
        Vec3 away = t.position().subtract(p.position());
        Vec3 dir = new Vec3(away.x, 0, away.z);
        dir = dir.lengthSqr() < 1.0E-4 ? new Vec3(0, 0, 1) : dir.normalize();

        DamageSource src = sl.damageSources().indirectMagic(p, p);
        ItemStack helm = t.getItemBySlot(EquipmentSlot.HEAD);
        if (!helm.isEmpty()) {
            t.setItemSlot(EquipmentSlot.HEAD, ItemStack.EMPTY);
            t.spawnAtLocation(helm);
        }
        t.invulnerableTime = 0;
        t.hurt(src, 1.0E6f);
        if (t.isAlive()) return;

        NetPackets.CHANNEL.send(PacketDistributor.TRACKING_ENTITY_AND_SELF.with(() -> t), new NetPackets.HeadlessPacket(t.getId()));

        ImpactBurstEntity fx = new ImpactBurstEntity(TheBoysMod.IMPACT_BURST.get(), sl);
        fx.setPos(head.x, head.y, head.z);
        fx.setYRot((float) (Mth.atan2(-dir.x, dir.z) * 57.29577951308232));
        fx.setLethal(true);
        fx.setCount(90);
        fx.setLife(320);
        fx.setScale(1.0f);
        sl.addFreshEntity(fx);

        sl.sendParticles(TheBoysMod.BLOOD_DROP.get(), head.x, head.y, head.z, 36, 0.25, 0.25, 0.25, 0.22);
        sl.sendParticles(TheBoysMod.BONE_CHIP.get(), head.x, head.y, head.z, 12, 0.2, 0.2, 0.2, 0.18);
        sl.playSound(null, t.blockPosition(), SoundEvents.PLAYER_ATTACK_CRIT, SoundSource.PLAYERS, 1.2f, 0.6f);
        sl.playSound(null, t.blockPosition(), SoundEvents.SLIME_BLOCK_BREAK, SoundSource.PLAYERS, 1.6f, 0.5f);
        sl.playSound(null, t.blockPosition(), SoundEvents.BONE_BLOCK_BREAK, SoundSource.PLAYERS, 1.2f, 0.6f);
        sl.playSound(null, t.blockPosition(), SoundEvents.HONEY_BLOCK_BREAK, SoundSource.PLAYERS, 1.2f, 0.5f);
    }
}
