package com.theboys.mod;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingEntityUseItemEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Mod.EventBusSubscriber(modid = TheBoysMod.MOD_ID)
public class PowerEvents {
    private static final float SHOCK_RESISTANCE = 0.5f;

    private static final float RUN_STEP_HEIGHT = 1.1f;
    private static final float DEFAULT_STEP_HEIGHT = 0.6f;
    private static final float RUN_EXHAUSTION = 0.05f;
    private static final float OVERDRIVE_EXHAUSTION = 0.12f;
    private static final double MOVING_SPEED = 0.1;
    private static final double RUN_SOUND_START_SPEED = 0.15;
    private static final int RUN_SOUND_IDLE_TICKS = 10;
    private static final int RUN_SOUND_COOLDOWN = 40;
    private static final int EXHAUSTED_BELOW = 1;
    private static final int RECOVERED_AT = 4;
    private static final float EAT_SPEED = 0.7f;

    private static final double IMPACT_MIN_SPEED = 0.6;
    private static final double IMPACT_DAMAGE_PER_SPEED = 20.0;
    private static final float IMPACT_MAX_DAMAGE = 40.0f;
    private static final double MOMENTUM_DAMAGE_PER_SPEED = 15.0;
    private static final float MOMENTUM_MAX_BONUS = 40.0f;

    private static final double BOOM_SPEED = 3.5;
    private static final int BOOM_COOLDOWN = 60;
    private static final int BOOM_REARM_TICKS = 20;
    private static final double BOOM_RADIUS = 9.0;
    private static final float BOOM_DAMAGE = 14.0f;
    private static final float STRAIN_PER_SECOND = 0.35f;
    private static final float STRAIN_MAX = 14.0f;
    private static final float STRAIN_FLOOR = 2.0f;

    private static final String TAG_RUNNING = "theboys_running", TAG_OVERDRIVE = "theboys_overdrive",
            TAG_SPEEDSTER = "theboys_speedster", TAG_EXHAUSTED = "theboys_exhausted";

    private static final UUID RUN_MODIFIER = UUID.fromString("3a7f2c10-8d4e-4b6a-a1c3-5e0000000100");
    private static final UUID OVERDRIVE_MODIFIER = UUID.fromString("3a7f2c10-8d4e-4b6a-a1c3-5e0000000102");
    private static final SoundEvent RUN_SOUND = SoundEvent.createVariableRangeEvent(new ResourceLocation(TheBoysMod.MOD_ID, "a_train_run"));

    private static class State {
        Vec3 last;
        Vec3 delta = Vec3.ZERO;
        double speed;
        double avg;
        final ArrayDeque<Vec3> hist = new ArrayDeque<>();
        int idleTicks = 100, slowTicks = 100, overdriveTicks;
        boolean boomArmed = true, wasOverdrive;
        long lastSound = -1000, lastBoom = -1000;
    }
    private static final Map<UUID, State> STATES = new HashMap<>();

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) { STATES.remove(e.getEntity().getUUID()); }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent e) { STATES.remove(e.getEntity().getUUID()); }

    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone e) {
        if (e.isWasDeath()) {
            e.getEntity().removeTag(TAG_RUNNING);
            e.getEntity().removeTag(TAG_OVERDRIVE);
            e.getEntity().removeTag(TAG_EXHAUSTED);
            STATES.remove(e.getEntity().getUUID());
        }
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) {
            p.removeTag(TAG_RUNNING);
            p.removeTag(TAG_OVERDRIVE);
            STATES.remove(p.getUUID());
        }
    }

    @SubscribeEvent
    public static void onEat(LivingEntityUseItemEvent.Start e) {
        if (e.getEntity() instanceof Player p && p.getTags().contains(TAG_SPEEDSTER) && e.getItem().isEdible()) {
            e.setDuration(Math.max(1, (int) (e.getDuration() * EAT_SPEED)));
        }
    }

    @SubscribeEvent
    public static void onHurt(LivingHurtEvent e) {
        if (e.getEntity() instanceof ServerPlayer p && p.getTags().contains("theboys_shock")) {
            if (e.getSource().is(DamageTypeTags.IS_FALL) || e.getSource().is(DamageTypeTags.IS_EXPLOSION)) {
                e.setAmount(e.getAmount() * SHOCK_RESISTANCE);
            }
        }

        if (e.getSource().getEntity() instanceof ServerPlayer a && e.getSource().getDirectEntity() == a
                && a.getTags().contains("theboys_momentum") && isRunning(a)) {
            State s = STATES.get(a.getUUID());
            if (s != null && s.avg > MOVING_SPEED) {
                e.setAmount(e.getAmount() + (float) Math.min(MOMENTUM_MAX_BONUS, s.avg * MOMENTUM_DAMAGE_PER_SPEED));
            }
        }
    }

    private static boolean isRunning(Player p) {
        AttributeInstance sp = p.getAttribute(Attributes.MOVEMENT_SPEED);
        return p.getTags().contains(TAG_RUNNING) && sp != null && sp.getModifier(RUN_MODIFIER) != null;
    }

    private static boolean isOverdrive(Player p) {
        AttributeInstance sp = p.getAttribute(Attributes.MOVEMENT_SPEED);
        return p.getTags().contains(TAG_OVERDRIVE) && sp != null && sp.getModifier(OVERDRIVE_MODIFIER) != null;
    }

    @SubscribeEvent
    public static void onTick(TickEvent.PlayerTickEvent e) {
        Player player = e.player;

        if (e.phase == TickEvent.Phase.START) {
            AttributeInstance sp = player.getAttribute(Attributes.MOVEMENT_SPEED);
            boolean running = sp != null && sp.getModifier(RUN_MODIFIER) != null;
            CompoundTag d = player.getPersistentData();
            if (running) {
                player.setMaxUpStep(RUN_STEP_HEIGHT);
                d.putBoolean("theboys_step", true);
            } else if (d.getBoolean("theboys_step")) {
                player.setMaxUpStep(DEFAULT_STEP_HEIGHT);
                d.putBoolean("theboys_step", false);
            }
            return;
        }
        if (e.phase != TickEvent.Phase.END || !(player instanceof ServerPlayer p) || !p.isAlive()) return;

        State s = STATES.computeIfAbsent(p.getUUID(), k -> new State());
        Vec3 pos = p.position();
        s.delta = s.last == null ? Vec3.ZERO : pos.subtract(s.last);
        if (s.delta.lengthSqr() > 60 * 60) { s.delta = Vec3.ZERO; s.hist.clear(); }
        s.last = pos;
        s.speed = Math.sqrt(s.delta.x * s.delta.x + s.delta.z * s.delta.z);
        s.hist.addLast(pos);
        while (s.hist.size() > 6) s.hist.pollFirst();
        if (s.hist.size() >= 2) {
            Vec3 a = s.hist.peekFirst(), b = s.hist.peekLast();
            s.avg = Math.sqrt((b.x - a.x) * (b.x - a.x) + (b.z - a.z) * (b.z - a.z)) / (s.hist.size() - 1);
        } else {
            s.avg = 0;
        }
        long now = p.level().getGameTime();

        if (p.getTags().contains(TAG_SPEEDSTER)) {
            int food = p.getFoodData().getFoodLevel();
            boolean exhausted = p.getTags().contains(TAG_EXHAUSTED);
            if (!exhausted && food <= EXHAUSTED_BELOW) {
                p.addTag(TAG_EXHAUSTED);
                p.level().playSound(null, p.blockPosition(), SoundEvents.PLAYER_BREATH, SoundSource.PLAYERS, 1.0f, 0.8f);
            } else if (exhausted && food >= RECOVERED_AT) {
                p.removeTag(TAG_EXHAUSTED);
            }
        }

        boolean running = isRunning(p);
        boolean overdrive = running && isOverdrive(p);

        if (running) {
            if (s.avg > MOVING_SPEED) {
                p.causeFoodExhaustion(RUN_EXHAUSTION + (overdrive ? OVERDRIVE_EXHAUSTION : 0f));
            }

            if (s.avg > RUN_SOUND_START_SPEED) {
                if (s.idleTicks >= RUN_SOUND_IDLE_TICKS && now - s.lastSound >= RUN_SOUND_COOLDOWN) {
                    p.level().playSound(null, p.blockPosition(), RUN_SOUND, SoundSource.PLAYERS, 2.0f, 1.0f);
                    s.lastSound = now;
                }
                s.idleTicks = 0;
            } else {
                s.idleTicks++;
            }
        } else {
            s.idleTicks = 100;
        }

        if (overdrive) {
            s.overdriveTicks++;
            if (s.avg >= BOOM_SPEED && s.boomArmed && now - s.lastBoom >= BOOM_COOLDOWN) {
                boom(p, s);
                s.boomArmed = false;
                s.lastBoom = now;
                s.slowTicks = 0;
            }
            if (s.avg < BOOM_SPEED * 0.7) s.slowTicks++; else s.slowTicks = 0;
            if (!s.boomArmed && s.slowTicks >= BOOM_REARM_TICKS) s.boomArmed = true;
        } else {
            if (s.wasOverdrive) deliverStrain(p, s);
            s.overdriveTicks = 0;
            s.boomArmed = true;
            s.slowTicks = 100;
        }
        s.wasOverdrive = overdrive;

        if (running && p.getTags().contains("theboys_impact") && s.speed >= IMPACT_MIN_SPEED) {
            Vec3 dir = new Vec3(s.delta.x, 0, s.delta.z).normalize();
            AABB box = p.getBoundingBox()
                    .expandTowards(-s.delta.x, -s.delta.y, -s.delta.z)
                    .expandTowards(s.delta.x, 0, s.delta.z)
                    .inflate(0.7, 0.3, 0.7);
            float dmg = (float) Math.min(IMPACT_MAX_DAMAGE, (s.speed - 0.3) * IMPACT_DAMAGE_PER_SPEED);
            for (LivingEntity t : p.level().getEntitiesOfClass(LivingEntity.class, box, t -> t != p && t.isAlive())) {
                if (t.hurt(p.damageSources().playerAttack(p), dmg)) {
                    boolean killed = t.isDeadOrDying();
                    if (!killed) {
                        t.setDeltaMovement(dir.x * (1.0 + s.speed), 0.45, dir.z * (1.0 + s.speed));
                        t.hurtMarked = true;
                    }
                    goreFx(p, t, dmg, dir, killed);

                    if (killed && !(t instanceof Player)) t.setInvisible(true);
                }
            }
        }
    }

    private static void goreFx(ServerPlayer p, LivingEntity t, float dmg, Vec3 dir, boolean killed) {
        ServerLevel sl = p.serverLevel();
        Vec3 at = t.position().add(0, t.getBbHeight() * 0.55, 0);

        ImpactBurstEntity fx = new ImpactBurstEntity(TheBoysMod.IMPACT_BURST.get(), sl);
        fx.setPos(at.x, at.y, at.z);
        fx.setYRot((float) (Mth.atan2(-dir.x, dir.z) * 57.29577951308232));
        fx.setLethal(killed);
        fx.setCount(killed ? 100 : 36);
        fx.setLife(killed ? 320 : 160);
        fx.setScale(killed ? Mth.clamp(0.8f + t.getBbHeight() * 0.5f, 1.0f, 3.0f) : 0.6f + Math.min(0.8f, dmg / 50f));
        sl.addFreshEntity(fx);

        sl.playSound(null, t.blockPosition(), SoundEvents.PLAYER_ATTACK_KNOCKBACK, SoundSource.PLAYERS, 1.4f, 0.7f);
        sl.playSound(null, t.blockPosition(), SoundEvents.HONEY_BLOCK_BREAK, SoundSource.PLAYERS, 1.2f, 0.6f);
        if (killed) {
            sl.playSound(null, t.blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 0.7f, 1.7f);
            sl.playSound(null, t.blockPosition(), SoundEvents.SLIME_BLOCK_BREAK, SoundSource.PLAYERS, 1.6f, 0.5f);
            sl.playSound(null, t.blockPosition(), SoundEvents.BONE_BLOCK_BREAK, SoundSource.PLAYERS, 1.2f, 0.6f);
        }
    }

    private static void deliverStrain(ServerPlayer p, State s) {
        float dmg = Math.min(STRAIN_MAX, s.overdriveTicks / 20f * STRAIN_PER_SECOND);
        dmg = Math.min(dmg, p.getHealth() - STRAIN_FLOOR);
        if (dmg < 0.5f) return;
        p.level().playSound(null, p.blockPosition(), SoundEvents.WARDEN_HEARTBEAT, SoundSource.PLAYERS, 1.6f, 0.8f);
        p.hurt(p.damageSources().magic(), dmg);
    }

    private static void boom(ServerPlayer p, State s) {
        ServerLevel sl = p.serverLevel();
        sl.playSound(null, p.blockPosition(), SoundEvents.WARDEN_SONIC_BOOM, SoundSource.PLAYERS, 4.0f, 0.9f);
        sl.playSound(null, p.blockPosition(), SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.PLAYERS, 1.5f, 1.4f);

        for (LivingEntity t : sl.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(BOOM_RADIUS), t -> t != p && t.isAlive())) {
            t.hurt(sl.damageSources().sonicBoom(p), BOOM_DAMAGE);
            Vec3 away = t.position().subtract(p.position()).multiply(1, 0, 1);
            away = away.lengthSqr() < 1.0E-4 ? Vec3.ZERO : away.normalize();
            t.setDeltaMovement(away.x * 2.0, 0.6, away.z * 2.0);
            t.hurtMarked = true;
        }
    }
}
