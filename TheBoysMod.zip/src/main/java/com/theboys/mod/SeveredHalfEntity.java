package com.theboys.mod;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;

import java.util.Optional;
import java.util.UUID;

public class SeveredHalfEntity extends Entity {
    public static final int LIFETIME = 700;

    private static final EntityDataAccessor<String> TYPE = SynchedEntityData.defineId(SeveredHalfEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<Boolean> UPPER = SynchedEntityData.defineId(SeveredHalfEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Float> CUT = SynchedEntityData.defineId(SeveredHalfEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> HEIGHT = SynchedEntityData.defineId(SeveredHalfEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> YAW = SynchedEntityData.defineId(SeveredHalfEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Optional<UUID>> OWNER = SynchedEntityData.defineId(SeveredHalfEntity.class, EntityDataSerializers.OPTIONAL_UUID);
    private static final EntityDataAccessor<CompoundTag> EQUIP = SynchedEntityData.defineId(SeveredHalfEntity.class, EntityDataSerializers.COMPOUND_TAG);
    private static final EntityDataAccessor<CompoundTag> NBT = SynchedEntityData.defineId(SeveredHalfEntity.class, EntityDataSerializers.COMPOUND_TAG);

    public SeveredHalfEntity(EntityType<?> type, Level level) {
        super(type, level);
    }

    @Override
    protected void defineSynchedData() {
        this.entityData.define(TYPE, "minecraft:zombie");
        this.entityData.define(UPPER, true);
        this.entityData.define(CUT, 0.5f);
        this.entityData.define(HEIGHT, 1.8f);
        this.entityData.define(YAW, 0f);
        this.entityData.define(OWNER, Optional.empty());
        this.entityData.define(EQUIP, new CompoundTag());
        this.entityData.define(NBT, new CompoundTag());
    }

    public void setup(String typeId, boolean upper, float cutFraction, float height, float yaw, UUID owner, ListTag equip, CompoundTag nbt) {
        this.entityData.set(TYPE, typeId);
        this.entityData.set(UPPER, upper);
        this.entityData.set(CUT, cutFraction);
        this.entityData.set(HEIGHT, height);
        this.entityData.set(YAW, yaw);
        this.entityData.set(OWNER, Optional.ofNullable(owner));
        CompoundTag wrap = new CompoundTag();
        wrap.put("list", equip);
        this.entityData.set(EQUIP, wrap);
        this.entityData.set(NBT, nbt == null ? new CompoundTag() : nbt);
    }

    public String getTypeId() { return this.entityData.get(TYPE); }
    public boolean isUpper() { return this.entityData.get(UPPER); }
    public float getCutFraction() { return this.entityData.get(CUT); }
    public float getBodyHeight() { return this.entityData.get(HEIGHT); }
    public float getBodyYaw() { return this.entityData.get(YAW); }
    public Optional<UUID> getOwnerId() { return this.entityData.get(OWNER); }
    public ListTag getEquip() { return this.entityData.get(EQUIP).getList("list", 10); }
    public CompoundTag getVictimNbt() { return this.entityData.get(NBT); }

    @Override
    public void tick() {
        super.tick();
        if (!this.level().isClientSide && this.tickCount > LIFETIME) {
            this.discard();
            return;
        }
        Vec3 dm = this.getDeltaMovement().add(0, -0.04, 0);
        this.setDeltaMovement(dm);
        this.move(MoverType.SELF, this.getDeltaMovement());
        float f = this.onGround() ? 0.6f * 0.91f : 0.91f;
        Vec3 v = this.getDeltaMovement();
        this.setDeltaMovement(v.x * f, this.onGround() ? 0 : v.y * 0.98, v.z * f);

        if (this.level().isClientSide && this.tickCount < 200 && this.tickCount % 2 == 0) {
            var r = this.random;
            this.level().addParticle(TheBoysMod.BLOOD_DROP.get(),
                    this.getX() + (r.nextDouble() - 0.5) * 0.3, this.getY() + 0.15 + (isUpper() ? 0.0 : getBodyHeight() * getCutFraction() * Math.max(0.0, 1.0 - this.tickCount / 14.0)),
                    this.getZ() + (r.nextDouble() - 0.5) * 0.3, (r.nextDouble() - 0.5) * 0.05, 0.02, (r.nextDouble() - 0.5) * 0.05);
        }
    }

    @Override public boolean shouldBeSaved() { return false; }
    @Override protected void readAdditionalSaveData(CompoundTag tag) {}
    @Override protected void addAdditionalSaveData(CompoundTag tag) {}

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }
}
