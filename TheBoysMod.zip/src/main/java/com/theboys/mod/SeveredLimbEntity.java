package com.theboys.mod;

import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;

import java.util.Optional;
import java.util.UUID;

/** A severed limb lying on the ground. Rendered client-side with the owner's skin. */
public class SeveredLimbEntity extends Entity {

    /** How long a limb stays on the ground (ticks). */
    public static final int LIFETIME = 600;

    private static final EntityDataAccessor<Integer> LIMB = SynchedEntityData.defineId(SeveredLimbEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Optional<UUID>> OWNER = SynchedEntityData.defineId(SeveredLimbEntity.class, EntityDataSerializers.OPTIONAL_UUID);

    public SeveredLimbEntity(EntityType<?> type, Level level) {
        super(type, level);
    }

    @Override
    protected void defineSynchedData() {
        this.entityData.define(LIMB, 4);
        this.entityData.define(OWNER, Optional.empty());
    }

    public int getLimb() { return this.entityData.get(LIMB); }
    public void setLimb(int limb) { this.entityData.set(LIMB, limb); }
    public Optional<UUID> getOwner() { return this.entityData.get(OWNER); }
    public void setOwner(UUID id) { this.entityData.set(OWNER, Optional.ofNullable(id)); }

    @Override
    public void tick() {
        super.tick();
        if (!this.level().isClientSide && this.tickCount > LIFETIME) {
            this.discard();
            return;
        }
        Vec3 dm = this.getDeltaMovement().add(0, -0.04, 0);
        this.setDeltaMovement(dm);
        this.move(MoverType.SELF, this.getDeltaMovement());
        float f = this.onGround() ? 0.6f * 0.91f : 0.91f;
        Vec3 v = this.getDeltaMovement();
        this.setDeltaMovement(v.x * f, this.onGround() ? 0 : v.y * 0.98, v.z * f);

        // bleeding for the first few seconds
        if (this.level().isClientSide && this.tickCount < 160 && this.tickCount % 3 == 0) {
            this.level().addParticle(TheBoysMod.BLOOD_DROP.get(),
                    this.getX(), this.getY() + 0.2, this.getZ(), 0, 0, 0);
        }
    }

    @Override public boolean shouldBeSaved() { return false; }
    @Override protected void readAdditionalSaveData(CompoundTag tag) {}
    @Override protected void addAdditionalSaveData(CompoundTag tag) {}

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }
}
