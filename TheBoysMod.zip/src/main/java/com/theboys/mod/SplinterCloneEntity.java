package com.theboys.mod;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.goal.target.TargetGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.targeting.TargetingConditions;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.DiggerItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.TridentItem;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;

import java.util.EnumSet;
import java.util.Optional;
import java.util.UUID;

public class SplinterCloneEntity extends PathfinderMob {
    public static final int EMERGE_TICKS = 14;
    public static final int MERGE_TICKS = 12;

    private static final EntityDataAccessor<Optional<UUID>> OWNER = SynchedEntityData.defineId(SplinterCloneEntity.class, EntityDataSerializers.OPTIONAL_UUID);
    private static final EntityDataAccessor<Integer> EMERGE = SynchedEntityData.defineId(SplinterCloneEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> MERGE = SynchedEntityData.defineId(SplinterCloneEntity.class, EntityDataSerializers.INT);

    private int awayTicks;
    private int lastAttackTick = -100;

    public SplinterCloneEntity(EntityType<? extends SplinterCloneEntity> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return PathfinderMob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0)
                .add(Attributes.MOVEMENT_SPEED, 0.28)
                .add(Attributes.ATTACK_DAMAGE, 1.0)
                .add(Attributes.ATTACK_KNOCKBACK, 0.0)
                .add(Attributes.ATTACK_SPEED, 4.0)
                .add(Attributes.FOLLOW_RANGE, 32.0);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(OWNER, Optional.empty());
        this.entityData.define(EMERGE, 0);
        this.entityData.define(MERGE, 0);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new CloneMeleeGoal(this));
        this.goalSelector.addGoal(2, new FollowOwnerGoal(this));
        this.goalSelector.addGoal(3, new WaterAvoidingRandomStrollGoal(this, 0.8));
        this.goalSelector.addGoal(4, new LookAtPlayerGoal(this, Player.class, 8.0f));
        this.goalSelector.addGoal(5, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new OwnerHurtByGoal(this));
        this.targetSelector.addGoal(2, new OwnerHurtTargetGoal(this));
        this.targetSelector.addGoal(3, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(4, new NearestAttackableTargetGoal<>(this, Monster.class, 10, true, false, this::nearOwner));
    }

    private boolean nearOwner(LivingEntity target) {
        Player o = getOwner();
        return o != null && target != null && target.distanceToSqr(o) < 256.0 && wantsToAttack(target);
    }

    public UUID ownerUUID() {
        return this.entityData.get(OWNER).orElse(null);
    }

    public Optional<UUID> getOwnerId() {
        return this.entityData.get(OWNER);
    }

    public Player getOwner() {
        UUID id = ownerUUID();
        return id == null ? null : this.level().getPlayerByUUID(id);
    }

    public boolean isOwnedBy(Player p) {
        UUID id = ownerUUID();
        return id != null && id.equals(p.getUUID());
    }

    public void setOwner(Player p) {
        this.entityData.set(OWNER, Optional.of(p.getUUID()));
        this.setCustomName(p.getName());
        this.setCustomNameVisible(true);
        AttributeInstance hp = this.getAttribute(Attributes.MAX_HEALTH);
        if (hp != null) hp.setBaseValue(Math.max(1.0, p.getMaxHealth()));
        this.setHealth(this.getMaxHealth());
    }

    public boolean isFriend(Entity e) {
        UUID o = ownerUUID();
        if (o == null || e == null) return false;
        if (e.getUUID().equals(o)) return true;
        return e instanceof SplinterCloneEntity c && o.equals(c.ownerUUID());
    }

    public boolean wantsToAttack(LivingEntity target) {
        return target != this && target.isAlive() && !isFriend(target);
    }

    public boolean isBusy() {
        return this.entityData.get(EMERGE) < EMERGE_TICKS || this.entityData.get(MERGE) > 0;
    }

    public boolean isMerging() {
        return this.entityData.get(MERGE) > 0;
    }

    public float splitProgress(float partial) {
        int m = this.entityData.get(MERGE);
        if (m > 0) return Mth.clamp(1.0f - (m - 1 + partial) / MERGE_TICKS, 0.0f, 1.0f);
        int e = this.entityData.get(EMERGE);
        return Mth.clamp((e + partial) / EMERGE_TICKS, 0.0f, 1.0f);
    }

    @Override
    public boolean isImmobile() {
        return super.isImmobile() || isBusy();
    }

    @Override
    public boolean isPushable() {
        return !isBusy() && super.isPushable();
    }

    @Override
    public boolean removeWhenFarAway(double dist) {
        return false;
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (isBusy() && !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) return false;
        if (isFriend(source.getEntity())) return false;
        return super.hurt(source, amount);
    }

    public boolean attackReady() {
        double speed = Math.max(0.1, getAttributeValue(Attributes.ATTACK_SPEED));
        return this.tickCount - lastAttackTick >= (int) Math.ceil(20.0 / speed);
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        lastAttackTick = this.tickCount;
        float dmg = (float) getAttributeValue(Attributes.ATTACK_DAMAGE);
        float kb = (float) getAttributeValue(Attributes.ATTACK_KNOCKBACK);
        ItemStack weapon = getMainHandItem();
        LivingEntity living = target instanceof LivingEntity le ? le : null;

        if (living != null) {
            dmg += EnchantmentHelper.getDamageBonus(weapon, living.getMobType());
            kb += EnchantmentHelper.getKnockbackBonus(this);
        }

        int fire = EnchantmentHelper.getFireAspect(this);
        if (fire > 0) target.setSecondsOnFire(fire * 4);

        boolean crit = living != null && this.fallDistance > 0.0f && !this.onGround() && !this.onClimbable()
                && !this.isInWater() && !this.hasEffect(MobEffects.BLINDNESS) && !this.isPassenger();
        if (crit) dmg *= 1.5f;

        boolean hurt = target.hurt(this.damageSources().mobAttack(this), dmg);
        if (!hurt) return false;

        double sin = Mth.sin(this.getYRot() * ((float) Math.PI / 180f));
        double cos = Mth.cos(this.getYRot() * ((float) Math.PI / 180f));

        if (kb > 0.0f && living != null) living.knockback(kb * 0.5f, sin, -cos);
        this.setDeltaMovement(this.getDeltaMovement().multiply(0.6, 1.0, 0.6));

        if (crit) {
            this.level().playSound(null, getX(), getY(), getZ(), SoundEvents.PLAYER_ATTACK_CRIT, SoundSource.PLAYERS, 1.0f, 1.0f);
        } else if (weapon.getItem() instanceof SwordItem && this.onGround() && living != null) {
            float sweep = 1.0f + EnchantmentHelper.getSweepingDamageRatio(this) * dmg;
            for (LivingEntity o : this.level().getEntitiesOfClass(LivingEntity.class, target.getBoundingBox().inflate(1.0, 0.25, 1.0))) {
                if (o == this || o == target || isFriend(o) || this.isAlliedTo(o)) continue;
                if (o instanceof ArmorStand a && a.isMarker()) continue;
                if (this.distanceToSqr(o) >= 9.0) continue;
                o.knockback(0.4f, sin, -cos);
                o.hurt(this.damageSources().mobAttack(this), sweep);
            }
            this.level().playSound(null, getX(), getY(), getZ(), SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.PLAYERS, 1.0f, 1.0f);
        } else {
            this.level().playSound(null, getX(), getY(), getZ(), SoundEvents.PLAYER_ATTACK_STRONG, SoundSource.PLAYERS, 1.0f, 1.0f);
        }

        this.doEnchantDamageEffects(this, target);
        this.setLastHurtMob(target);
        if (living != null && !weapon.isEmpty()) weapon.getItem().hurtEnemy(weapon, living, this);
        return true;
    }

    @Override
    protected void hurtArmor(DamageSource source, float amount) {
        if (amount <= 0.0f) return;
        int dmg = Math.max(1, (int) (amount / 4.0f));
        for (EquipmentSlot s : new EquipmentSlot[]{EquipmentSlot.FEET, EquipmentSlot.LEGS, EquipmentSlot.CHEST, EquipmentSlot.HEAD}) {
            ItemStack st = getItemBySlot(s);
            if (st.isEmpty() || !(st.getItem() instanceof ArmorItem)) continue;
            if (source.is(DamageTypeTags.IS_FIRE) && st.getItem().isFireResistant()) continue;
            st.hurtAndBreak(dmg, this, e -> e.broadcastBreakEvent(s));
        }
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.PLAYER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.PLAYER_DEATH;
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) return;

        int em = this.entityData.get(EMERGE);
        if (em < EMERGE_TICKS) this.entityData.set(EMERGE, em + 1);

        int mg = this.entityData.get(MERGE);
        if (mg > 0) {
            if (mg >= MERGE_TICKS) {
                finishMerge();
                return;
            }
            this.entityData.set(MERGE, mg + 1);
        }

        Player o = getOwner();
        if (o == null || !o.isAlive() || o.level() != this.level()) {
            if (++awayTicks > 200) vanish();
        } else {
            awayTicks = 0;
        }
    }

    public void beginMerge() {
        if (this.level().isClientSide || isMerging() || !isAlive()) return;
        returnGear();
        this.getNavigation().stop();
        this.entityData.set(MERGE, 1);
    }

    private void finishMerge() {
        if (this.level() instanceof ServerLevel sl) {
            Player o = getOwner();
            double x = o != null ? o.getX() : getX();
            double y = (o != null ? o.getY() : getY()) + 1.0;
            double z = o != null ? o.getZ() : getZ();
            SplinterEvents.fleshSound(sl, x, y, z, true);
        }
        this.discard();
    }

    public void vanish() {
        if (this.level().isClientSide || isRemoved()) return;
        returnGear();
        if (this.level() instanceof ServerLevel sl) {
            SplinterEvents.fleshSound(sl, getX(), getY() + 1.0, getZ(), true);
        }
        this.discard();
    }

    public boolean hasGear() {
        for (EquipmentSlot s : EquipmentSlot.values()) {
            if (!getItemBySlot(s).isEmpty()) return true;
        }
        return false;
    }

    public void returnGear() {
        Player o = getOwner();
        for (EquipmentSlot s : EquipmentSlot.values()) {
            ItemStack st = getItemBySlot(s);
            if (st.isEmpty()) continue;
            setItemSlot(s, ItemStack.EMPTY);
            if (o != null && o.isAlive() && o.level() == this.level()) {
                if (!o.getInventory().add(st)) o.drop(st, false);
            } else {
                spawnAtLocation(st);
            }
        }
    }

    private static EquipmentSlot slotFor(ItemStack stack) {
        EquipmentSlot es = stack.getEquipmentSlot();
        if (es != null && es.getType() == EquipmentSlot.Type.ARMOR) return es;
        Item item = stack.getItem();
        if (item instanceof ArmorItem armor) return armor.getEquipmentSlot();
        if (item instanceof SwordItem || item instanceof AxeItem || item instanceof DiggerItem || item instanceof TridentItem) {
            return EquipmentSlot.MAINHAND;
        }
        return null;
    }

    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (!isOwnedBy(player) || isBusy()) return InteractionResult.PASS;
        ItemStack held = player.getItemInHand(hand);

        if (held.isEmpty()) {
            if (!player.isShiftKeyDown() || !hasGear()) return InteractionResult.PASS;
            if (!this.level().isClientSide) {
                returnGear();
                this.level().playSound(null, getX(), getY(), getZ(), SoundEvents.ARMOR_EQUIP_GENERIC, SoundSource.PLAYERS, 1.0f, 1.0f);
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }

        EquipmentSlot slot = slotFor(held);
        if (slot == null) return InteractionResult.PASS;
        if (this.level().isClientSide) return InteractionResult.SUCCESS;

        ItemStack old = getItemBySlot(slot);
        ItemStack give = held.copy();
        give.setCount(1);
        setItemSlot(slot, give);
        setDropChance(slot, 2.0f);
        if (!player.getAbilities().instabuild) held.shrink(1);
        if (!old.isEmpty() && !player.getInventory().add(old)) player.drop(old, false);
        this.level().playSound(null, getX(), getY(), getZ(), SoundEvents.ARMOR_EQUIP_GENERIC, SoundSource.PLAYERS, 1.0f, 1.0f);
        return InteractionResult.CONSUME;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        UUID id = ownerUUID();
        if (id != null) tag.putUUID("Owner", id);
        tag.putInt("Emerge", this.entityData.get(EMERGE));
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.hasUUID("Owner")) this.entityData.set(OWNER, Optional.of(tag.getUUID("Owner")));
        this.entityData.set(EMERGE, tag.contains("Emerge") ? tag.getInt("Emerge") : EMERGE_TICKS);
        this.entityData.set(MERGE, 0);
        for (EquipmentSlot s : EquipmentSlot.values()) setDropChance(s, 2.0f);
    }

    private static class CloneMeleeGoal extends Goal {
        private final SplinterCloneEntity clone;
        private int repath;

        CloneMeleeGoal(SplinterCloneEntity clone) {
            this.clone = clone;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            LivingEntity t = clone.getTarget();
            return t != null && t.isAlive() && !clone.isBusy();
        }

        @Override
        public boolean canContinueToUse() {
            return canUse();
        }

        @Override
        public void start() {
            clone.setAggressive(true);
            repath = 0;
        }

        @Override
        public void stop() {
            clone.setAggressive(false);
            clone.getNavigation().stop();
        }

        @Override
        public boolean requiresUpdateEveryTick() {
            return true;
        }

        @Override
        public void tick() {
            LivingEntity t = clone.getTarget();
            if (t == null) return;
            clone.getLookControl().setLookAt(t, 30.0f, 30.0f);
            if (--repath <= 0) {
                repath = 4 + clone.getRandom().nextInt(7);
                clone.getNavigation().moveTo(t, 1.25);
            }
            if (clone.distanceToSqr(t) <= 9.0 && clone.attackReady() && clone.getSensing().hasLineOfSight(t)) {
                clone.swing(InteractionHand.MAIN_HAND);
                clone.doHurtTarget(t);
            }
        }
    }

    private static class FollowOwnerGoal extends Goal {
        private final SplinterCloneEntity clone;
        private Player owner;
        private int recalc;

        FollowOwnerGoal(SplinterCloneEntity clone) {
            this.clone = clone;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            Player o = clone.getOwner();
            if (o == null || o.isSpectator() || clone.isBusy()) return false;
            if (o.level() != clone.level()) return false;
            if (clone.distanceToSqr(o) < 36.0) return false;
            owner = o;
            return true;
        }

        @Override
        public boolean canContinueToUse() {
            return owner != null && owner.isAlive() && !clone.isBusy() && !clone.getNavigation().isDone() && clone.distanceToSqr(owner) > 9.0;
        }

        @Override
        public void start() {
            recalc = 0;
        }

        @Override
        public void stop() {
            owner = null;
            clone.getNavigation().stop();
        }

        @Override
        public void tick() {
            clone.getLookControl().setLookAt(owner, 10.0f, (float) clone.getMaxHeadXRot());
            if (--recalc > 0) return;
            recalc = this.adjustedTickDelay(10);
            if (clone.distanceToSqr(owner) >= 576.0) {
                for (int i = 0; i < 10; i++) {
                    double x = owner.getX() + (clone.getRandom().nextDouble() - 0.5) * 4.0;
                    double z = owner.getZ() + (clone.getRandom().nextDouble() - 0.5) * 4.0;
                    AABB box = clone.getBoundingBox().move(x - clone.getX(), owner.getY() - clone.getY(), z - clone.getZ());
                    if (clone.level().noCollision(clone, box)) {
                        clone.moveTo(x, owner.getY(), z, clone.getYRot(), clone.getXRot());
                        clone.getNavigation().stop();
                        return;
                    }
                }
            } else {
                clone.getNavigation().moveTo(owner, 1.2);
            }
        }
    }

    private static class OwnerHurtByGoal extends TargetGoal {
        private final SplinterCloneEntity clone;
        private LivingEntity attacker;
        private int timestamp;

        OwnerHurtByGoal(SplinterCloneEntity clone) {
            super(clone, false);
            this.clone = clone;
            this.setFlags(EnumSet.of(Goal.Flag.TARGET));
        }

        @Override
        public boolean canUse() {
            Player o = clone.getOwner();
            if (o == null || clone.isBusy()) return false;
            attacker = o.getLastHurtByMob();
            int t = o.getLastHurtByMobTimestamp();
            return t != timestamp && attacker != null && clone.wantsToAttack(attacker) && this.canAttack(attacker, TargetingConditions.DEFAULT);
        }

        @Override
        public void start() {
            this.mob.setTarget(attacker);
            Player o = clone.getOwner();
            if (o != null) timestamp = o.getLastHurtByMobTimestamp();
            super.start();
        }
    }

    private static class OwnerHurtTargetGoal extends TargetGoal {
        private final SplinterCloneEntity clone;
        private LivingEntity victim;
        private int timestamp;

        OwnerHurtTargetGoal(SplinterCloneEntity clone) {
            super(clone, false);
            this.clone = clone;
            this.setFlags(EnumSet.of(Goal.Flag.TARGET));
        }

        @Override
        public boolean canUse() {
            Player o = clone.getOwner();
            if (o == null || clone.isBusy()) return false;
            victim = o.getLastHurtMob();
            int t = o.getLastHurtMobTimestamp();
            return t != timestamp && victim != null && clone.wantsToAttack(victim) && this.canAttack(victim, TargetingConditions.DEFAULT);
        }

        @Override
        public void start() {
            this.mob.setTarget(victim);
            Player o = clone.getOwner();
            if (o != null) timestamp = o.getLastHurtMobTimestamp();
            super.start();
        }
    }
}
