package com.theboys.mod;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Mod.EventBusSubscriber(modid = TheBoysMod.MOD_ID)
public class SplinterEvents {
    public static final int MAX_CLONES = 8;
    private static final int SPLIT_COOLDOWN = 12;
    private static final int MERGE_COOLDOWN = 10;
    private static final double LOOK_RANGE = 24.0;

    private static final String REQ_SPLIT = "theboys_req_split";
    private static final String REQ_MERGE = "theboys_req_merge";

    private static final EquipmentSlot[] ARMOR = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
    private static final Map<UUID, Long> SPLIT_CD = new HashMap<>();
    private static final Map<UUID, Long> MERGE_CD = new HashMap<>();

    public static List<? extends SplinterCloneEntity> clonesOf(Player p, ServerLevel sl) {
        return sl.getEntities(TheBoysMod.SPLINTER_CLONE.get(), c -> c.isOwnedBy(p) && c.isAlive());
    }

    public static void fleshSound(ServerLevel sl, double x, double y, double z, boolean merging) {
        if (merging) {
            sl.playSound(null, x, y, z, SoundEvents.SLIME_BLOCK_PLACE, SoundSource.PLAYERS, 1.2f, 0.6f);
            sl.playSound(null, x, y, z, SoundEvents.HONEY_BLOCK_PLACE, SoundSource.PLAYERS, 1.0f, 0.5f);
        } else {
            sl.playSound(null, x, y, z, SoundEvents.SLIME_BLOCK_BREAK, SoundSource.PLAYERS, 1.4f, 0.55f);
            sl.playSound(null, x, y, z, SoundEvents.HONEY_BLOCK_BREAK, SoundSource.PLAYERS, 1.1f, 0.6f);
            sl.playSound(null, x, y, z, SoundEvents.PLAYER_ATTACK_KNOCKBACK, SoundSource.PLAYERS, 0.8f, 0.5f);
        }
    }

    @SubscribeEvent
    public static void onJoin(EntityJoinLevelEvent e) {
        if (e.getLevel().isClientSide() || !(e.getEntity() instanceof Monster m)) return;
        m.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(m, SplinterCloneEntity.class, true));
    }

    @SubscribeEvent
    public static void onTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.player instanceof ServerPlayer p) || !p.isAlive() || p.isSpectator()) return;
        boolean split = p.removeTag(REQ_SPLIT);
        boolean merge = p.removeTag(REQ_MERGE);
        if (!split && !merge) return;
        ServerLevel sl = p.serverLevel();
        long now = sl.getGameTime();
        if (split && now >= SPLIT_CD.getOrDefault(p.getUUID(), 0L)) {
            SPLIT_CD.put(p.getUUID(), now + SPLIT_COOLDOWN);
            split(p, sl);
        }
        if (merge && now >= MERGE_CD.getOrDefault(p.getUUID(), 0L)) {
            MERGE_CD.put(p.getUUID(), now + MERGE_COOLDOWN);
            merge(p, sl);
        }
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent e) {
        if (e.getEntity() instanceof ServerPlayer p && p.level() instanceof ServerLevel sl) {
            for (SplinterCloneEntity c : clonesOf(p, sl)) c.vanish();
        }
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        SPLIT_CD.remove(e.getEntity().getUUID());
        MERGE_CD.remove(e.getEntity().getUUID());
    }

    private static void split(ServerPlayer p, ServerLevel sl) {
        List<? extends SplinterCloneEntity> mine = clonesOf(p, sl);
        if (mine.size() >= MAX_CLONES) {
            sl.playSound(null, p.blockPosition(), SoundEvents.VILLAGER_NO, SoundSource.PLAYERS, 0.6f, 1.2f);
            return;
        }

        dropArmor(p, sl);

        SplinterCloneEntity c = new SplinterCloneEntity(TheBoysMod.SPLINTER_CLONE.get(), sl);
        Vec3 spot = findSpot(p, sl, c, mine.size());
        c.moveTo(spot.x, spot.y, spot.z, p.getYRot(), 0.0f);
        c.setYHeadRot(p.getYRot());
        c.yBodyRot = p.getYRot();
        c.setOwner(p);
        sl.addFreshEntity(c);

        fleshSound(sl, p.getX(), p.getY() + 1.0, p.getZ(), false);
    }

    private static void dropArmor(ServerPlayer p, ServerLevel sl) {
        boolean creative = p.getAbilities().instabuild;
        for (EquipmentSlot s : ARMOR) {
            ItemStack st = p.getItemBySlot(s);
            if (st.isEmpty()) continue;
            if (!creative && EnchantmentHelper.hasBindingCurse(st)) continue;
            p.setItemSlot(s, ItemStack.EMPTY);
            ItemEntity ie = new ItemEntity(sl, p.getX(), p.getY() + 0.5, p.getZ(), st);
            ie.setPickUpDelay(40);
            ie.setDeltaMovement((sl.random.nextDouble() - 0.5) * 0.2, 0.2, (sl.random.nextDouble() - 0.5) * 0.2);
            sl.addFreshEntity(ie);
        }
    }

    private static Vec3 findSpot(ServerPlayer p, ServerLevel sl, SplinterCloneEntity c, int index) {
        double yaw = Math.toRadians(p.getYRot());
        double rx = -Math.cos(yaw);
        double rz = -Math.sin(yaw);
        c.moveTo(p.getX(), p.getY(), p.getZ());
        for (int i = 0; i < 20; i++) {
            int n = index + i;
            double side = n % 2 == 0 ? 1.0 : -1.0;
            double reach = 1.2 + 0.8 * ((n / 2) % 3);
            double ang = (i / 2) * 0.35 * side;
            double dx = rx * Math.cos(ang) - rz * Math.sin(ang);
            double dz = rx * Math.sin(ang) + rz * Math.cos(ang);
            Vec3 cand = new Vec3(p.getX() + dx * reach * side, p.getY(), p.getZ() + dz * reach * side);
            AABB box = c.getBoundingBox().move(cand.x - p.getX(), 0.0, cand.z - p.getZ());
            if (sl.noCollision(c, box)) return cand;
        }
        return p.position();
    }

    private static SplinterCloneEntity lookedClone(ServerPlayer p, ServerLevel sl) {
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        Vec3 end = eye.add(look.scale(LOOK_RANGE));
        AABB box = p.getBoundingBox().expandTowards(look.scale(LOOK_RANGE)).inflate(1.0);
        EntityHitResult hit = ProjectileUtil.getEntityHitResult(sl, p, eye, end, box,
                en -> en instanceof SplinterCloneEntity sc && sc.isOwnedBy(p) && !sc.isBusy());
        return hit != null && hit.getEntity() instanceof SplinterCloneEntity c ? c : null;
    }

    private static void merge(ServerPlayer p, ServerLevel sl) {
        List<? extends SplinterCloneEntity> mine = clonesOf(p, sl);
        if (mine.isEmpty()) return;
        SplinterCloneEntity target = lookedClone(p, sl);
        if (target != null) {
            target.beginMerge();
        } else {
            for (SplinterCloneEntity c : mine) c.beginMerge();
        }
        fleshSound(sl, p.getX(), p.getY() + 1.0, p.getZ(), true);
    }
}
