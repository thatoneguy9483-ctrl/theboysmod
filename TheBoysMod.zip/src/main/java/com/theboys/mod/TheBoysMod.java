package com.theboys.mod;

import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(TheBoysMod.MOD_ID)
public class TheBoysMod {
    public static final String MOD_ID = "theboys";

    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MOD_ID);
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MOD_ID);
    public static final RegistryObject<EntityType<SeveredLimbEntity>> SEVERED_LIMB = ENTITIES.register("severed_limb",
            () -> EntityType.Builder.<SeveredLimbEntity>of(SeveredLimbEntity::new, MobCategory.MISC)
                    .sized(0.4f, 0.25f).clientTrackingRange(8).updateInterval(2).build("severed_limb"));

    public static final RegistryObject<EntityType<ImpactBurstEntity>> IMPACT_BURST = ENTITIES.register("impact_burst",
            () -> EntityType.Builder.<ImpactBurstEntity>of(ImpactBurstEntity::new, MobCategory.MISC)
                    .sized(0.1f, 0.1f).clientTrackingRange(16).updateInterval(20).build("impact_burst"));

    public static final RegistryObject<EntityType<CinderBurstEntity>> CINDER_BURST = ENTITIES.register("cinder_burst",
            () -> EntityType.Builder.<CinderBurstEntity>of(CinderBurstEntity::new, MobCategory.MISC)
                    .sized(0.1f, 0.1f).clientTrackingRange(16).updateInterval(20).build("cinder_burst"));

    public static final RegistryObject<EntityType<FlameOrbEntity>> FLAME_ORB = ENTITIES.register("flame_orb",
            () -> EntityType.Builder.<FlameOrbEntity>of(FlameOrbEntity::new, MobCategory.MISC)
                    .sized(0.4f, 0.4f).clientTrackingRange(8).updateInterval(2).fireImmune().build("flame_orb"));

    public static final RegistryObject<EntityType<SeveredHalfEntity>> SEVERED_HALF = ENTITIES.register("severed_half",
            () -> EntityType.Builder.<SeveredHalfEntity>of(SeveredHalfEntity::new, MobCategory.MISC)
                    .sized(0.5f, 0.5f).clientTrackingRange(10).updateInterval(2).build("severed_half"));

    public static final RegistryObject<EntityType<SplinterCloneEntity>> SPLINTER_CLONE = ENTITIES.register("splinter_clone",
            () -> EntityType.Builder.<SplinterCloneEntity>of(SplinterCloneEntity::new, MobCategory.MISC)
                    .sized(0.6f, 1.8f).clientTrackingRange(10).updateInterval(2).build("splinter_clone"));

    public static final DeferredRegister<ParticleType<?>> PARTICLES = DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES, MOD_ID);
    public static final RegistryObject<SimpleParticleType> FLAME_LICK = PARTICLES.register("flame_lick", () -> new SimpleParticleType(false));
    public static final RegistryObject<SimpleParticleType> FLAME_LICK_BIG = PARTICLES.register("flame_lick_big", () -> new SimpleParticleType(false));
    public static final RegistryObject<SimpleParticleType> SMOKE_PUFF = PARTICLES.register("smoke_puff", () -> new SimpleParticleType(false));
    public static final RegistryObject<SimpleParticleType> SPARK = PARTICLES.register("spark", () -> new SimpleParticleType(false));
    public static final RegistryObject<SimpleParticleType> SHOCK_RING = PARTICLES.register("shock_ring", () -> new SimpleParticleType(false));
    public static final RegistryObject<SimpleParticleType> PING = PARTICLES.register("ping", () -> new SimpleParticleType(false));
    public static final RegistryObject<SimpleParticleType> BONE_CHIP = PARTICLES.register("bone_chip", () -> new SimpleParticleType(false));
    public static final RegistryObject<SimpleParticleType> BLOOD_DROP = PARTICLES.register("blood_drop", () -> new SimpleParticleType(false));
    public static final RegistryObject<SimpleParticleType> GLOW_MOTE = PARTICLES.register("glow_mote", () -> new SimpleParticleType(false));
    public static final RegistryObject<SimpleParticleType> BUBBLE = PARTICLES.register("bubble", () -> new SimpleParticleType(false));
    public static final RegistryObject<SimpleParticleType> WATER_SPLASH = PARTICLES.register("water_splash", () -> new SimpleParticleType(false));
    public static final RegistryObject<SimpleParticleType> SEA_SENSE = PARTICLES.register("sea_sense", () -> new SimpleParticleType(false));
    public static final RegistryObject<SimpleParticleType> XRAY_RED = PARTICLES.register("xray_red", () -> new SimpleParticleType(false));
    public static final RegistryObject<SimpleParticleType> XRAY_CYAN = PARTICLES.register("xray_cyan", () -> new SimpleParticleType(false));
    public static final RegistryObject<SimpleParticleType> XRAY_GREEN = PARTICLES.register("xray_green", () -> new SimpleParticleType(false));
    public static final RegistryObject<SimpleParticleType> FLAME_FLOW = PARTICLES.register("flame_flow", () -> new SimpleParticleType(false));

    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MOD_ID);

    public static final RegistryObject<Item> EMPTY_INJECTOR = ITEMS.register("empty_injector", () -> new Item(new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> TEMP_V = ITEMS.register("temp_v", () -> new Item(new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> COMPOUND_V = ITEMS.register("compound_v", () -> new CompoundVItem(new Item.Properties().stacksTo(1)));

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("main", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.theboys"))
            .icon(() -> new ItemStack(COMPOUND_V.get()))
            .displayItems((params, out) -> {
                out.accept(EMPTY_INJECTOR.get());
                out.accept(TEMP_V.get());
                out.accept(COMPOUND_V.get());
            }).build());

    public TheBoysMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ITEMS.register(bus);
        ENTITIES.register(bus);
        PARTICLES.register(bus);
        TABS.register(bus);
        bus.addListener(this::registerAttributes);
        NetPackets.init();
    }

    private void registerAttributes(EntityAttributeCreationEvent e) {
        e.put(SPLINTER_CLONE.get(), SplinterCloneEntity.createAttributes().build());
    }
}
