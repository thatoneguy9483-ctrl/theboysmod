package com.theboys.mod;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(TheBoysMod.MOD_ID)
public class TheBoysMod {
    public static final String MOD_ID = "theboys";

    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MOD_ID);
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MOD_ID);
    public static final RegistryObject<EntityType<SeveredLimbEntity>> SEVERED_LIMB = ENTITIES.register("severed_limb",
            () -> EntityType.Builder.<SeveredLimbEntity>of(SeveredLimbEntity::new, MobCategory.MISC)
                    .sized(0.4f, 0.25f).clientTrackingRange(8).updateInterval(2).build("severed_limb"));

    public static final RegistryObject<EntityType<ImpactBurstEntity>> IMPACT_BURST = ENTITIES.register("impact_burst",
            () -> EntityType.Builder.<ImpactBurstEntity>of(ImpactBurstEntity::new, MobCategory.MISC)
                    .sized(0.1f, 0.1f).clientTrackingRange(16).updateInterval(20).build("impact_burst"));

    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MOD_ID);

    public static final RegistryObject<Item> EMPTY_INJECTOR = ITEMS.register("empty_injector", () -> new Item(new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> TEMP_V = ITEMS.register("temp_v", () -> new Item(new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> COMPOUND_V = ITEMS.register("compound_v", () -> new CompoundVItem(new Item.Properties().stacksTo(1)));

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("main", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.theboys"))
            .icon(() -> new ItemStack(COMPOUND_V.get()))
            .displayItems((params, out) -> {
                out.accept(EMPTY_INJECTOR.get());
                out.accept(TEMP_V.get());
                out.accept(COMPOUND_V.get());
            }).build());

    public TheBoysMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ITEMS.register(bus);
        ENTITIES.register(bus);
        TABS.register(bus);
    }
}
