package com.theboys.mod;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Translucent. The cloak itself is animated on the client (see client/CloakClient). Here, once the animation has had time to
 * finish, we flip vanilla's invisible flag so the body is truly gone (and mobs lose track of you), while armor and held items stay visible,
 * exactly as vanilla invisibility works and exactly as in the show. Also: bulletproof + fireproof skin.
 */
@Mod.EventBusSubscriber(modid = TheBoysMod.MOD_ID)
public class TranslucentEvents {

    /** Ticks for the cloak to sweep over the body. Must match CloakClient.CLOAK_TICKS. */
    public static final int CLOAK_TICKS = 28;
    /** Must match the "cloak" attribute modifier uuid in translucent.json. */
    public static final UUID CLOAK_MODIFIER = UUID.fromString("9b2e5d70-3c1a-4f8e-b6d4-7a0000000001");

    private static final String TAG_CLOAKED = "theboys_cloaked";
    private static final String FLAG = "theboys_inv_set";
    private static final Map<UUID, Integer> TICKS = new HashMap<>();

    private static boolean isCloaked(Player p) {
        AttributeInstance a = p.getAttribute(Attributes.ARMOR);
        return p.getTags().contains(TAG_CLOAKED) && a != null && a.getModifier(CLOAK_MODIFIER) != null;
    }

    @SubscribeEvent
    public static void onTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.player instanceof ServerPlayer p) || !p.isAlive()) return;
        int t = TICKS.getOrDefault(p.getUUID(), 0);
        if (isCloaked(p)) {
            t = Math.min(CLOAK_TICKS, t + 1);
            if (t >= CLOAK_TICKS) {
                p.setInvisible(true);                       // re-asserted every tick: vanilla clears it when you have no effects
                p.getPersistentData().putBoolean(FLAG, true);
            }
        } else {
            if (t > 0 || p.getPersistentData().getBoolean(FLAG)) {
                if (p.getPersistentData().getBoolean(FLAG)) {
                    p.setInvisible(false);                  // the client plays the reveal animation
                    p.getPersistentData().putBoolean(FLAG, false);
                }
                t = 0;
            }
        }
        TICKS.put(p.getUUID(), t);
    }

    @SubscribeEvent
    public static void onHurt(LivingHurtEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        if (p.getTags().contains("theboys_bulletproof") && e.getSource().is(DamageTypeTags.IS_PROJECTILE)) {
            e.setCanceled(true);
        } else if (p.getTags().contains("theboys_fireproof") && e.getSource().is(DamageTypeTags.IS_FIRE)) {
            p.clearFire();
            e.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) {
            p.removeTag(TAG_CLOAKED);
            p.getPersistentData().putBoolean(FLAG, false);
            TICKS.remove(p.getUUID());
        }
    }

    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone e) {
        if (e.isWasDeath()) {
            e.getEntity().removeTag(TAG_CLOAKED);
            e.getEntity().getPersistentData().putBoolean(FLAG, false);
        }
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) { TICKS.remove(e.getEntity().getUUID()); }
}
