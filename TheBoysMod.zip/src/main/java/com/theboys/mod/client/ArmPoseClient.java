package com.theboys.mod.client;

import com.theboys.mod.LamplighterEvents;
import com.theboys.mod.TheBoysMod;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Both arms raised and pointing where you look while the flame blast is on (the same stance as drawing a bow, with two
 * arms). The client knows the blast is on because its marker attribute modifier is synced to every client.
 */
@Mod.EventBusSubscriber(modid = TheBoysMod.MOD_ID, value = Dist.CLIENT)
public class ArmPoseClient {

    @SubscribeEvent
    public static void onRender(RenderLivingEvent.Pre<?, ?> e) {
        if (!(e.getEntity() instanceof Player p)) return;
        if (!(e.getRenderer().getModel() instanceof PlayerModel<?> m)) return;

        AttributeInstance a = p.getAttribute(Attributes.ARMOR_TOUGHNESS);
        if (a == null || a.getModifier(LamplighterEvents.BLAST_MODIFIER) == null) return;

        m.rightArmPose = HumanoidModel.ArmPose.BOW_AND_ARROW;
        m.leftArmPose = HumanoidModel.ArmPose.BOW_AND_ARROW;
    }
}
