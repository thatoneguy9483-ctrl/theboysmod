package com.theboys.mod.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.theboys.mod.CinderBurstEntity;
import com.theboys.mod.TheBoysMod;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Quaternionf;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.WeakHashMap;

/**
 * Ash and embers. Glowing embers rise and cool from orange to black, grey ash drifts up and settles, and when a body
 * is burned away there is a puff of smoke, charred flecks that scorch whatever block they hit, and a scorch mark with
 * glowing coals that slowly go out. Collision paths are planned once per effect (same approach as the blood).
 */
public class CinderBurstRenderer extends EntityRenderer<CinderBurstEntity> {

    // ---- tweak these ----
    private static final int SMOKE_PUFFS = 10;
    private static final int FADE = 50;                          // ticks to fade out at the end
    private static final double GRAVITY = 0.03;                  // for charred flecks
    private static final double MARCH_STEP = 2.0;
    private static final double MARCH_MAX = 60.0;
    private static final int FULL_BRIGHT = 15728880;

    private static final ResourceLocation EMBER = new ResourceLocation(TheBoysMod.MOD_ID, "textures/effect/cinder_ember.png");
    private static final ResourceLocation ASH = new ResourceLocation(TheBoysMod.MOD_ID, "textures/effect/cinder_ash.png");
    private static final ResourceLocation SMOKE = new ResourceLocation(TheBoysMod.MOD_ID, "textures/effect/cinder_smoke.png");
    private static final ResourceLocation SCORCH = new ResourceLocation(TheBoysMod.MOD_ID, "textures/effect/cinder_scorch.png");

    private static final class Fleck {
        double vx, vy, vz, size, landT;
        Vec3 rel = Vec3.ZERO, normal = new Vec3(0, 1, 0);
        boolean landed;
        int idx;
    }

    private static final class Plan {
        final List<Fleck> flecks = new ArrayList<>();
        boolean floor;
        Vec3 floorRel = Vec3.ZERO;
    }

    private static final Map<CinderBurstEntity, Plan> PLANS = new WeakHashMap<>();

    public CinderBurstRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
        this.shadowRadius = 0f;
    }

    @Override public ResourceLocation getTextureLocation(CinderBurstEntity e) { return SCORCH; }

    @Override
    public boolean shouldRender(CinderBurstEntity e, net.minecraft.client.renderer.culling.Frustum f, double x, double y, double z) {
        return true;
    }

    private static float smooth(float u) { u = Math.max(0f, Math.min(1f, u)); return u * u * (3f - 2f * u); }
    private static float lerp(float t, float a, float b) { return a + (b - a) * t; }

    // ---------- planning ----------
    private Plan build(CinderBurstEntity e) {
        Plan plan = new Plan();
        Level lv = e.level();
        Vec3 o = e.position();
        Random rd = new Random(e.getId() * 104729L + 11L);

        if (e.isLethal()) {
            int n = Math.max(6, e.getCount() / 3);
            for (int i = 0; i < n; i++) {
                double a = rd.nextDouble(), b = rd.nextDouble(), c = rd.nextDouble(), s = rd.nextDouble();
                Fleck f = new Fleck();
                f.idx = i;
                double th = a * Math.PI * 2, ph = Math.acos(2 * b - 1), sp = 0.12 + c * 0.4;
                f.vx = sp * Math.sin(ph) * Math.cos(th);
                f.vz = sp * Math.sin(ph) * Math.sin(th);
                f.vy = Math.abs(sp * Math.cos(ph)) * 1.1 + 0.05;
                f.size = (0.05 + s * 0.09) * (0.7 + 0.4 * e.getScale());

                Vec3 prev = o;
                double prevT = 0;
                f.landT = MARCH_MAX;
                for (double t = MARCH_STEP; t <= MARCH_MAX; t += MARCH_STEP) {
                    Vec3 cur = o.add(f.vx * t, f.vy * t - 0.5 * GRAVITY * t * t, f.vz * t);
                    BlockHitResult h = lv.clip(new ClipContext(prev, cur, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, e));
                    if (h.getType() == HitResult.Type.BLOCK) {
                        double total = prev.distanceTo(cur);
                        double frac = total < 1.0E-6 ? 0 : prev.distanceTo(h.getLocation()) / total;
                        f.landT = prevT + (t - prevT) * frac;
                        f.landed = true;
                        f.rel = h.getLocation().subtract(o);
                        f.normal = new Vec3(h.getDirection().getStepX(), h.getDirection().getStepY(), h.getDirection().getStepZ());
                        break;
                    }
                    prev = cur;
                    prevT = t;
                }
                plan.flecks.add(f);
            }
        }

        BlockHitResult down = lv.clip(new ClipContext(o, o.add(0, -8, 0), ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, e));
        if (down.getType() == HitResult.Type.BLOCK) {
            plan.floor = true;
            plan.floorRel = down.getLocation().subtract(o);
        }
        return plan;
    }

    // ---------- rendering ----------
    @Override
    public void render(CinderBurstEntity e, float yaw, float pt, PoseStack ps, MultiBufferSource buf, int light) {
        final float age = e.tickCount + pt;
        final boolean lethal = e.isLethal();
        final float scale = e.getScale();
        final int life = e.getLife();
        if (age >= life) return;
        final float fade = age > life - FADE ? smooth((life - age) / FADE) : 1f;
        final Plan plan = PLANS.computeIfAbsent(e, this::build);
        final Quaternionf cam = this.entityRenderDispatcher.cameraOrientation();
        final double floorY = plan.floor ? plan.floorRel.y + 0.03 : -1000;

        // smoke puff as the body goes
        if (lethal && age < 26f) {
            Random r = new Random(e.getId() * 7919L + 5L);
            VertexConsumer sv = buf.getBuffer(RenderType.entityTranslucent(SMOKE));
            float mt = age / 26f;
            float ease = 1f - (1f - mt) * (1f - mt);
            for (int i = 0; i < SMOKE_PUFFS; i++) {
                double ox = (r.nextDouble() - 0.5) * 0.8 * scale, oy = (r.nextDouble() - 0.3) * 0.9 * scale, oz = (r.nextDouble() - 0.5) * 0.8 * scale;
                double dx = (r.nextDouble() - 0.5) * 0.25, dy = 0.1 + r.nextDouble() * 0.25, dz = (r.nextDouble() - 0.5) * 0.25;
                float size = (0.4f + 1.4f * ease) * scale * (0.7f + r.nextFloat() * 0.6f);
                billboard(sv, ps, cam, ox + dx * age * 0.3, oy + dy * age * 0.3, oz + dz * age * 0.3, size, 1f, 1f, 1f, 0.8f * smooth(1f - mt), light);
            }
        }

        int n = e.getCount();

        // embers: rise, flicker and cool from white-orange to black
        VertexConsumer ev = buf.getBuffer(RenderType.entityTranslucent(EMBER));
        int emberN = Math.max(4, n / 2);
        for (int i = 0; i < emberN; i++) {
            Random r = new Random(e.getId() * 6151L + i * 131L);
            double ox = (r.nextDouble() - 0.5) * 0.7 * scale, oy = (r.nextDouble() - 0.4) * 0.8 * scale, oz = (r.nextDouble() - 0.5) * 0.7 * scale;
            double vx = (r.nextDouble() - 0.5) * 0.05, vy = 0.03 + r.nextDouble() * 0.07, vz = (r.nextDouble() - 0.5) * 0.05;
            float delay = r.nextFloat() * Math.min(10f, life * 0.2f);
            float elife = 30f + r.nextFloat() * 45f;
            float phase = r.nextFloat() * 6.283f;
            float size0 = (0.05f + r.nextFloat() * 0.08f) * (0.7f + 0.4f * scale);
            float u = (age - delay) / elife;
            if (u < 0f || u > 1f) continue;
            float flicker = 0.75f + 0.25f * (float) Math.sin(age * 0.7f + phase);
            double t = age - delay;
            double x = ox + vx * t + Math.sin(t * 0.25 + phase) * 0.04;
            double z = oz + vz * t + Math.cos(t * 0.21 + phase) * 0.04;
            double y = oy + vy * t;
            float cool = u * u;
            billboard(ev, ps, cam, x, y, z, size0 * (1f - 0.5f * u), lerp(cool, 1f, 0.35f), lerp(cool, 0.8f, 0.1f), lerp(cool, 0.35f, 0.05f),
                    (1f - u) * flicker * fade, FULL_BRIGHT);
        }

        // ash flakes: float up, then settle slowly
        VertexConsumer av = buf.getBuffer(RenderType.entityTranslucent(ASH));
        int ashN = lethal ? Math.max(4, n / 2) : Math.max(2, n / 4);
        for (int i = 0; i < ashN; i++) {
            Random r = new Random(e.getId() * 9973L + i * 211L);
            double ox = (r.nextDouble() - 0.5) * 0.7 * scale, oy = (r.nextDouble() - 0.4) * 0.9 * scale, oz = (r.nextDouble() - 0.5) * 0.7 * scale;
            double vx = (r.nextDouble() - 0.5) * 0.06, vy = 0.04 + r.nextDouble() * 0.12, vz = (r.nextDouble() - 0.5) * 0.06;
            float delay = r.nextFloat() * 8f;
            float alife = Math.min(life - 5f, 70f + r.nextFloat() * 130f);
            float phase = r.nextFloat() * 6.283f;
            float size0 = (0.05f + r.nextFloat() * 0.07f) * (0.7f + 0.4f * scale);
            float u = (age - delay) / alife;
            if (u < 0f || u > 1f) continue;
            double t = age - delay;
            double x = ox + vx * t + Math.sin(t * 0.12 + phase) * 0.12;
            double z = oz + vz * t + Math.cos(t * 0.1 + phase) * 0.12;
            double y = Math.max(floorY, oy + vy * t - 0.5 * 0.0032 * t * t);
            float shade = 0.4f + r.nextFloat() * 0.35f;
            billboard(av, ps, cam, x, y, z, size0, shade, shade * 0.97f, shade * 0.93f, smooth(1f - u) * 0.95f * fade, light);
        }

        if (!lethal) return;

        // charred flecks in flight, then scorch marks where they land
        VertexConsumer fv = buf.getBuffer(RenderType.entityTranslucent(ASH));
        VertexConsumer sv2 = buf.getBuffer(RenderType.entityTranslucent(SCORCH));
        for (Fleck f : plan.flecks) {
            if (age < f.landT) {
                double x = f.vx * age, y = f.vy * age - 0.5 * GRAVITY * age * age, z = f.vz * age;
                billboard(fv, ps, cam, x, y, z, (float) f.size, 0.12f, 0.1f, 0.09f, fade, light);
            } else if (f.landed) {
                float grow = (float) Math.min(1.0, (age - f.landT) / 3.0);
                decal(sv2, ps, f.rel, f.normal, (float) (f.size * 2.6 * grow), (f.idx * 47) % 360, 1f, 1f, 1f, 0.85f * fade, light);
            }
        }

        // the main scorch mark, with coals that glow for a while and go out
        if (plan.floor) {
            float fall = (float) Math.sqrt(2.0 * Math.max(0.05, -plan.floorRel.y) / GRAVITY);
            if (age > fall * 0.5f) {
                float grow = smooth((age - fall * 0.5f) / 16f);
                float radius = 0.95f * scale * grow;
                Vec3 at = plan.floorRel.add(0, 0.004, 0);
                int spin = (e.getId() * 53) % 360;
                decal(sv2, ps, at, new Vec3(0, 1, 0), radius, spin, 1f, 1f, 1f, 0.95f * fade, light);

                float glow = 1f - smooth((age - fall * 0.5f) / 90f);
                if (glow > 0.01f) {
                    VertexConsumer gv = buf.getBuffer(RenderType.entityTranslucent(EMBER));
                    float flick = 0.8f + 0.2f * (float) Math.sin(age * 0.5f);
                    decal(gv, ps, plan.floorRel.add(0, 0.008, 0), new Vec3(0, 1, 0), radius * 0.55f, spin + 30, 1f, 0.55f, 0.15f,
                            glow * flick * 0.8f * fade, FULL_BRIGHT);
                }
            }
        }
    }

    // ---------- drawing helpers ----------
    private static void billboard(VertexConsumer vc, PoseStack ps, Quaternionf cam, double x, double y, double z, float s,
                                  float r, float g, float b, float a, int light) {
        if (a <= 0.003f) return;
        ps.pushPose();
        ps.translate(x, y, z);
        ps.mulPose(cam);
        Matrix4f pose = ps.last().pose();
        Matrix3f nrm = ps.last().normal();
        put(vc, pose, nrm, -s, -s, 0, 0, 1, r, g, b, a, light, 0, 0, 1);
        put(vc, pose, nrm, s, -s, 0, 1, 1, r, g, b, a, light, 0, 0, 1);
        put(vc, pose, nrm, s, s, 0, 1, 0, r, g, b, a, light, 0, 0, 1);
        put(vc, pose, nrm, -s, s, 0, 0, 0, r, g, b, a, light, 0, 0, 1);
        ps.popPose();
    }

    /** A flat mark lying on any surface: floor, wall or ceiling. */
    private static void decal(VertexConsumer vc, PoseStack ps, Vec3 rel, Vec3 n, float s, float spinDeg,
                              float r, float g, float b, float a, int light) {
        if (a <= 0.003f || s <= 0.003f) return;
        ps.pushPose();
        ps.translate(rel.x + n.x * 0.012, rel.y + n.y * 0.012, rel.z + n.z * 0.012);
        ps.mulPose(new Quaternionf().rotationTo(0f, 1f, 0f, (float) n.x, (float) n.y, (float) n.z));
        ps.mulPose(Axis.YP.rotationDegrees(spinDeg));
        Matrix4f pose = ps.last().pose();
        Matrix3f nrm = ps.last().normal();
        put(vc, pose, nrm, -s, 0, -s, 0, 0, r, g, b, a, light, 0, 1, 0);
        put(vc, pose, nrm, -s, 0, s, 0, 1, r, g, b, a, light, 0, 1, 0);
        put(vc, pose, nrm, s, 0, s, 1, 1, r, g, b, a, light, 0, 1, 0);
        put(vc, pose, nrm, s, 0, -s, 1, 0, r, g, b, a, light, 0, 1, 0);
        ps.popPose();
    }

    private static void put(VertexConsumer vc, Matrix4f pose, Matrix3f nrm, float x, float y, float z, float u, float v,
                            float r, float g, float b, float a, int light, float nx, float ny, float nz) {
        vc.vertex(pose, x, y, z).color(r, g, b, a).uv(u, v).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(light).normal(nrm, nx, ny, nz).endVertex();
    }
}
