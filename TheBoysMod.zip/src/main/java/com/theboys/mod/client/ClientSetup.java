package com.theboys.mod.client;

import com.theboys.mod.TheBoysMod;
import net.minecraft.client.renderer.entity.EntityRenderers;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = TheBoysMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientSetup {
    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers e) {
        e.registerEntityRenderer(TheBoysMod.SEVERED_LIMB.get(), SeveredLimbRenderer::new);
        e.registerEntityRenderer(TheBoysMod.IMPACT_BURST.get(), ImpactBurstRenderer::new);
    }
}
