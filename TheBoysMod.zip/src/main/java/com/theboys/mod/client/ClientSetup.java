package com.theboys.mod.client;

import com.theboys.mod.TheBoysMod;
import net.minecraft.client.renderer.entity.EntityRenderers;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterParticleProvidersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = TheBoysMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientSetup {
    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers e) {
        e.registerEntityRenderer(TheBoysMod.SEVERED_LIMB.get(), SeveredLimbRenderer::new);
        e.registerEntityRenderer(TheBoysMod.IMPACT_BURST.get(), ImpactBurstRenderer::new);
        e.registerEntityRenderer(TheBoysMod.CINDER_BURST.get(), CinderBurstRenderer::new);
        e.registerEntityRenderer(TheBoysMod.FLAME_ORB.get(), FlameOrbRenderer::new);
        e.registerEntityRenderer(TheBoysMod.SEVERED_HALF.get(), SeveredHalfRenderer::new);
        e.registerEntityRenderer(TheBoysMod.SPLINTER_CLONE.get(), SplinterCloneRenderer::new);
    }

    @SubscribeEvent
    public static void registerParticles(RegisterParticleProvidersEvent e) {
        e.registerSpriteSet(TheBoysMod.FLAME_LICK.get(), sprites -> new FlameParticle.Provider(sprites, false, 1.0f));
        e.registerSpriteSet(TheBoysMod.FLAME_LICK_BIG.get(), sprites -> new FlameParticle.Provider(sprites, false, 1.9f));
        e.registerSpriteSet(TheBoysMod.SMOKE_PUFF.get(), sp -> new FxParticle.Provider(sp, new FxParticle.Cfg()
                .life(25, 40).size(0.25f, 0.9f).color(0.38f, 0.36f, 0.33f, 0.2f, 0.2f, 0.2f).alpha(0.8f, 0f).gravity(-0.15f).friction(0.96f).spin(0.02f)));
        e.registerSpriteSet(TheBoysMod.SPARK.get(), sp -> new FxParticle.Provider(sp, new FxParticle.Cfg()
                .life(8, 16).size(0.14f, 0.02f).color(1f, 0.95f, 0.6f, 1f, 0.5f, 0.1f).alpha(1f, 0f).gravity(0.6f).friction(0.92f).bright()));
        e.registerSpriteSet(TheBoysMod.SHOCK_RING.get(), sp -> new FxParticle.Provider(sp, new FxParticle.Cfg()
                .life(12, 12).size(0.5f, 4.5f).color(0.95f, 0.97f, 1f, 0.7f, 0.8f, 1f).alpha(0.9f, 0f).friction(1f).bright()));
        e.registerSpriteSet(TheBoysMod.PING.get(), sp -> new FxParticle.Provider(sp, new FxParticle.Cfg()
                .life(30, 30).size(0.25f, 1.0f).color(0.45f, 0.85f, 1f, 0.2f, 0.5f, 1f).alpha(1f, 0f).friction(1f).bright().overlay()));
        e.registerSpriteSet(TheBoysMod.BONE_CHIP.get(), sp -> new FxParticle.Provider(sp, new FxParticle.Cfg()
                .life(20, 32).size(0.07f, 0.06f).color(0.92f, 0.9f, 0.82f, 0.8f, 0.78f, 0.7f).alpha(1f, 0.2f).gravity(1f).friction(0.9f).physics().spin(0.15f)));
        e.registerSpriteSet(TheBoysMod.BLOOD_DROP.get(), sp -> new FxParticle.Provider(sp, new FxParticle.Cfg()
                .life(20, 34).size(0.08f, 0.05f).color(0.6f, 0.02f, 0.02f, 0.35f, 0.01f, 0.01f).alpha(1f, 0.3f).gravity(1.2f).friction(0.9f).physics()));
        e.registerSpriteSet(TheBoysMod.GLOW_MOTE.get(), sp -> new FxParticle.Provider(sp, new FxParticle.Cfg()
                .life(20, 40).size(0.18f, 0.02f).color(0.65f, 1f, 0.85f, 0.2f, 0.6f, 0.6f).alpha(1f, 0f).gravity(-0.1f).friction(0.94f).bright()));
        e.registerSpriteSet(TheBoysMod.BUBBLE.get(), sp -> new FxParticle.Provider(sp, new FxParticle.Cfg()
                .life(24, 44).size(0.07f, 0.11f).color(0.7f, 0.92f, 1f, 0.9f, 1f, 1f).alpha(0.85f, 0f).gravity(-0.3f).friction(0.95f).bright()));
        e.registerSpriteSet(TheBoysMod.WATER_SPLASH.get(), sp -> new FxParticle.Provider(sp, new FxParticle.Cfg()
                .life(14, 22).size(0.14f, 0.05f).color(0.55f, 0.8f, 1f, 0.8f, 0.92f, 1f).alpha(0.9f, 0f).gravity(1.0f).friction(0.94f).bright()));
        e.registerSpriteSet(TheBoysMod.SEA_SENSE.get(), sp -> new FxParticle.Provider(sp, new FxParticle.Cfg()
                .life(14, 14).size(0.12f, 0.2f).color(0.3f, 1f, 0.9f, 0.4f, 0.8f, 1f).alpha(0.95f, 0.3f).friction(1f).bright().overlay()));
        e.registerSpriteSet(TheBoysMod.XRAY_RED.get(), sp -> new FxParticle.Provider(sp, new FxParticle.Cfg()
                .life(7, 7).size(0.1f, 0.12f).color(1f, 0.25f, 0.2f, 1f, 0.25f, 0.2f).alpha(0.95f, 0.7f).friction(1f).bright().overlay()));
        e.registerSpriteSet(TheBoysMod.XRAY_CYAN.get(), sp -> new FxParticle.Provider(sp, new FxParticle.Cfg()
                .life(7, 7).size(0.1f, 0.12f).color(0.3f, 0.9f, 1f, 0.3f, 0.9f, 1f).alpha(0.95f, 0.7f).friction(1f).bright().overlay()));
        e.registerSpriteSet(TheBoysMod.XRAY_GREEN.get(), sp -> new FxParticle.Provider(sp, new FxParticle.Cfg()
                .life(7, 7).size(0.1f, 0.12f).color(0.4f, 1f, 0.4f, 0.4f, 1f, 0.4f).alpha(0.95f, 0.7f).friction(1f).bright().overlay()));
        e.registerSpriteSet(TheBoysMod.FLAME_FLOW.get(), sprites -> new FlameParticle.Provider(sprites, true, 1.0f));
    }
}
