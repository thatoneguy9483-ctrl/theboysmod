package com.theboys.mod.client;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.List;

/**
 * Wraps a MultiBufferSource and slices every quad drawn through it against a plane, so any entity renderer can be made
 * to draw only the part of the body above or below a cut. Quads that straddle the plane are clipped (not just dropped).
 * The plane is given in the same (view) space the vertices arrive in.
 */
public class ClipBufferSource implements MultiBufferSource {

    private final MultiBufferSource inner;
    private final Vector3f origin;
    private final Vector3f normal;
    private final float sign;

    /** Keeps the side of the plane where sign * dot(normal, p - origin) >= 0. */
    public ClipBufferSource(MultiBufferSource inner, Vector3f origin, Vector3f normal, float sign) {
        this.inner = inner;
        this.origin = origin;
        this.normal = normal;
        this.sign = sign;
    }

    @Override
    public VertexConsumer getBuffer(RenderType type) {
        // name tags, hitboxes and other non-quad geometry are not part of a body half
        if (type.mode() != VertexFormat.Mode.QUADS || type.toString().startsWith("RenderType[text")) return Noop.INSTANCE;
        return new Clip(this.inner.getBuffer(type));
    }

    private static final class V {
        double x, y, z;
        int r = 255, g = 255, b = 255, a = 255, o1, o2, l1, l2;
        float u, v, nx, ny = 1, nz;
        boolean hasC, hasUv, hasO, hasL, hasN;
        double d;

        V lerp(V o, double t) {
            V n = new V();
            n.x = x + (o.x - x) * t; n.y = y + (o.y - y) * t; n.z = z + (o.z - z) * t;
            n.r = (int) (r + (o.r - r) * t); n.g = (int) (g + (o.g - g) * t); n.b = (int) (b + (o.b - b) * t); n.a = (int) (a + (o.a - a) * t);
            n.u = (float) (u + (o.u - u) * t); n.v = (float) (v + (o.v - v) * t);
            n.o1 = o1; n.o2 = o2;
            n.l1 = (int) (l1 + (o.l1 - l1) * t); n.l2 = (int) (l2 + (o.l2 - l2) * t);
            n.nx = nx; n.ny = ny; n.nz = nz;
            n.hasC = hasC; n.hasUv = hasUv; n.hasO = hasO; n.hasL = hasL; n.hasN = hasN;
            return n;
        }
    }

    private final class Clip implements VertexConsumer {
        private final VertexConsumer out;
        private final List<V> quad = new ArrayList<>(4);
        private V cur = new V();

        Clip(VertexConsumer out) { this.out = out; }

        @Override public VertexConsumer vertex(double x, double y, double z) { cur.x = x; cur.y = y; cur.z = z; return this; }
        @Override public VertexConsumer color(int r, int g, int b, int a) { cur.r = r; cur.g = g; cur.b = b; cur.a = a; cur.hasC = true; return this; }
        @Override public VertexConsumer uv(float u, float v) { cur.u = u; cur.v = v; cur.hasUv = true; return this; }
        @Override public VertexConsumer overlayCoords(int u, int v) { cur.o1 = u; cur.o2 = v; cur.hasO = true; return this; }
        @Override public VertexConsumer uv2(int u, int v) { cur.l1 = u; cur.l2 = v; cur.hasL = true; return this; }
        @Override public VertexConsumer normal(float x, float y, float z) { cur.nx = x; cur.ny = y; cur.nz = z; cur.hasN = true; return this; }
        @Override public void defaultColor(int r, int g, int b, int a) { out.defaultColor(r, g, b, a); }
        @Override public void unsetDefaultColor() { out.unsetDefaultColor(); }

        @Override
        public void endVertex() {
            cur.d = sign * (normal.x() * (cur.x - origin.x()) + normal.y() * (cur.y - origin.y()) + normal.z() * (cur.z - origin.z()));
            quad.add(cur);
            cur = new V();
            if (quad.size() == 4) {
                flush();
                quad.clear();
            }
        }

        private void flush() {
            int inside = 0;
            for (V v : quad) if (v.d >= 0) inside++;
            if (inside == 0) return;
            if (inside == 4) {
                for (V v : quad) emit(v);
                return;
            }
            // clip the polygon against the plane
            List<V> poly = new ArrayList<>(5);
            for (int i = 0; i < 4; i++) {
                V a = quad.get(i), b = quad.get((i + 1) % 4);
                if (a.d >= 0) poly.add(a);
                if ((a.d >= 0) != (b.d >= 0)) poly.add(a.lerp(b, a.d / (a.d - b.d)));
            }
            int n = poly.size();
            if (n < 3) return;
            for (int i = 1; i < n - 1; i += 2) {
                emit(poly.get(0));
                emit(poly.get(i));
                emit(poly.get(i + 1));
                emit(i + 2 < n ? poly.get(i + 2) : poly.get(i + 1));
            }
        }

        private void emit(V v) {
            out.vertex(v.x, v.y, v.z);
            if (v.hasC) out.color(v.r, v.g, v.b, v.a);
            if (v.hasUv) out.uv(v.u, v.v);
            if (v.hasO) out.overlayCoords(v.o1, v.o2);
            if (v.hasL) out.uv2(v.l1, v.l2);
            if (v.hasN) out.normal(v.nx, v.ny, v.nz);
            out.endVertex();
        }
    }

    /** Swallows everything. */
    private static final class Noop implements VertexConsumer {
        static final Noop INSTANCE = new Noop();
        @Override public VertexConsumer vertex(double x, double y, double z) { return this; }
        @Override public VertexConsumer color(int r, int g, int b, int a) { return this; }
        @Override public VertexConsumer uv(float u, float v) { return this; }
        @Override public VertexConsumer overlayCoords(int u, int v) { return this; }
        @Override public VertexConsumer uv2(int u, int v) { return this; }
        @Override public VertexConsumer normal(float x, float y, float z) { return this; }
        @Override public void endVertex() {}
        @Override public void defaultColor(int r, int g, int b, int a) {}
        @Override public void unsetDefaultColor() {}
    }
}
