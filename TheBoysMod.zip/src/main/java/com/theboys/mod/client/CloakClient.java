package com.theboys.mod.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.theboys.mod.TheBoysMod;
import com.theboys.mod.TranslucentEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderArmEvent;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

@Mod.EventBusSubscriber(modid = TheBoysMod.MOD_ID, value = Dist.CLIENT)
public class CloakClient {
    public static final int CLOAK_TICKS = TranslucentEvents.CLOAK_TICKS;
    private static final float EDGE_WIDTH = 0.30f;
    private static final float BODY_HEIGHT = 1.85f;

    private static final Map<UUID, float[]> PROGRESS = new HashMap<>();
    private static boolean rendering = false;

    private static boolean isCloaked(Player p) {
        AttributeInstance a = p.getAttribute(Attributes.ARMOR);
        return a != null && a.getModifier(TranslucentEvents.CLOAK_MODIFIER) != null;
    }

    private static float ease(float x) { x = Mth.clamp(x, 0f, 1f); return x * x * (3f - 2f * x); }

    private static float progress(Player p, float pt) {
        float[] v = PROGRESS.get(p.getUUID());
        return v == null ? 0f : ease(Mth.lerp(pt, v[0], v[1]));
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) { PROGRESS.clear(); return; }
        Set<UUID> seen = new HashSet<>();
        for (Player p : mc.level.players()) {
            seen.add(p.getUUID());
            float[] v = PROGRESS.computeIfAbsent(p.getUUID(), k -> new float[]{0f, 0f});
            v[0] = v[1];
            float target = isCloaked(p) ? 1f : 0f;
            float step = 1f / CLOAK_TICKS;
            v[1] = v[1] < target ? Math.min(target, v[1] + step) : Math.max(target, v[1] - step);
        }
        PROGRESS.keySet().retainAll(seen);
    }

    @SubscribeEvent
    public static void onRenderPlayer(RenderPlayerEvent.Pre e) {
        if (rendering) return;
        Player p = e.getEntity();
        if (!(p instanceof AbstractClientPlayer cp)) return;
        float prog = progress(p, e.getPartialTick());
        if (prog <= 0.001f || p.isInvisible()) return;

        e.setCanceled(true);
        PoseStack ps = e.getPoseStack();
        float baseY = ps.last().pose().m31();
        FadeBuffer fb = new FadeBuffer(e.getMultiBufferSource(), cp.getSkinTextureLocation(), baseY, prog, false);
        float yaw = Mth.lerp(e.getPartialTick(), p.yRotO, p.getYRot());
        rendering = true;
        try {
            e.getRenderer().render(cp, yaw, e.getPartialTick(), ps, fb, e.getPackedLight());
        } finally {
            rendering = false;
        }
    }

    @SubscribeEvent
    public static void onRenderArm(RenderArmEvent e) {
        Player p = e.getPlayer();
        float prog = progress(p, 1f);
        if (prog <= 0.001f || !(p instanceof AbstractClientPlayer cp)) return;
        e.setCanceled(true);
        if (prog >= 0.97f) return;
        PlayerRenderer r = (PlayerRenderer) Minecraft.getInstance().getEntityRenderDispatcher().getRenderer(cp);
        FadeBuffer fb = new FadeBuffer(e.getMultiBufferSource(), cp.getSkinTextureLocation(), 0f, prog, true);
        if (e.getArm() == HumanoidArm.RIGHT) r.renderRightHand(e.getPoseStack(), fb, e.getPackedLight(), cp);
        else r.renderLeftHand(e.getPoseStack(), fb, e.getPackedLight(), cp);
    }

    private static final class FadeBuffer implements MultiBufferSource {
        private final MultiBufferSource delegate;
        private final ResourceLocation skin;
        private final String skinKey;
        private final float baseY, prog;
        private final boolean uniform;

        FadeBuffer(MultiBufferSource delegate, ResourceLocation skin, float baseY, float prog, boolean uniform) {
            this.delegate = delegate;
            this.skin = skin;
            this.skinKey = skin.toString();
            this.baseY = baseY;
            this.prog = prog;
            this.uniform = uniform;
        }

        @Override
        public VertexConsumer getBuffer(RenderType type) {
            if (type.toString().contains(skinKey)) {
                return new Fade(delegate.getBuffer(RenderType.entityTranslucent(skin)), baseY, prog, uniform);
            }
            return delegate.getBuffer(type);
        }
    }

    private static final class Fade implements VertexConsumer {
        private final VertexConsumer v;
        private final float baseY, prog;
        private final boolean uniform;
        private float y;

        Fade(VertexConsumer v, float baseY, float prog, boolean uniform) {
            this.v = v; this.baseY = baseY; this.prog = prog; this.uniform = uniform;
        }

        private float alpha() {
            if (uniform) return 1f - prog;
            float h = Mth.clamp((y - baseY) / BODY_HEIGHT, 0f, 1f);
            float covered = Mth.clamp((prog * (1f + EDGE_WIDTH) - (1f - h)) / EDGE_WIDTH, 0f, 1f);
            return 1f - covered;
        }

        @Override public VertexConsumer vertex(double x, double yy, double z) { this.y = (float) yy; v.vertex(x, yy, z); return this; }
        @Override public VertexConsumer color(int r, int g, int b, int a) { v.color(r, g, b, (int) (a * alpha())); return this; }
        @Override public VertexConsumer uv(float u, float vv) { v.uv(u, vv); return this; }
        @Override public VertexConsumer overlayCoords(int u, int vv) { v.overlayCoords(u, vv); return this; }
        @Override public VertexConsumer uv2(int u, int vv) { v.uv2(u, vv); return this; }
        @Override public VertexConsumer normal(float x, float yy, float z) { v.normal(x, yy, z); return this; }
        @Override public void endVertex() { v.endVertex(); }
        @Override public void defaultColor(int r, int g, int b, int a) { v.defaultColor(r, g, b, a); }
        @Override public void unsetDefaultColor() { v.unsetDefaultColor(); }
    }
}
