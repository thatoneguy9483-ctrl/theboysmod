package com.theboys.mod.client;

import com.theboys.mod.NetPackets;
import com.theboys.mod.TheBoysMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.animal.Dolphin;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = TheBoysMod.MOD_ID, value = Dist.CLIENT)
public class DolphinClient {
    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        LocalPlayer p = Minecraft.getInstance().player;
        if (p == null || !(p.getVehicle() instanceof Dolphin)) return;
        NetPackets.CHANNEL.sendToServer(new NetPackets.DolphinInputPacket(p.input.forwardImpulse, p.input.leftImpulse, p.input.jumping));
    }
}
