package com.theboys.mod.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.theboys.mod.FlameOrbEntity;
import com.theboys.mod.TheBoysMod;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

public class FlameOrbRenderer extends EntityRenderer<FlameOrbEntity> {
    private static final ResourceLocation GLOW = new ResourceLocation(TheBoysMod.MOD_ID, "textures/effect/cinder_ember.png");
    private static final int FULL_BRIGHT = 15728880;

    public FlameOrbRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
        this.shadowRadius = 0f;
    }

    @Override public ResourceLocation getTextureLocation(FlameOrbEntity e) { return GLOW; }

    @Override
    protected int getBlockLightLevel(FlameOrbEntity e, net.minecraft.core.BlockPos pos) { return 15; }

    @Override
    public void render(FlameOrbEntity e, float yaw, float pt, PoseStack ps, MultiBufferSource buf, int light) {
        float age = e.tickCount + pt;
        float pulse = (1f + 0.12f * (float) Math.sin(age * 0.9f)) * (0.6f + 0.9f * e.getPower());
        VertexConsumer vc = buf.getBuffer(RenderType.entityTranslucent(GLOW));

        ps.pushPose();
        ps.translate(0, 0.2, 0);
        ps.mulPose(this.entityRenderDispatcher.cameraOrientation());

        layer(vc, ps, 0.62f * pulse, age * 7f, 1.0f, 0.28f, 0.04f, 0.45f);
        layer(vc, ps, 0.40f * pulse, -age * 11f, 1.0f, 0.6f, 0.12f, 0.85f);
        layer(vc, ps, 0.22f * pulse, age * 17f, 1.0f, 0.95f, 0.7f, 1.0f);

        ps.popPose();
    }

    private static void layer(VertexConsumer vc, PoseStack ps, float s, float spinDeg, float r, float g, float b, float a) {
        ps.pushPose();
        ps.mulPose(Axis.ZP.rotationDegrees(spinDeg));
        Matrix4f pose = ps.last().pose();
        Matrix3f nrm = ps.last().normal();
        put(vc, pose, nrm, -s, -s, 0, 0, 1, r, g, b, a);
        put(vc, pose, nrm, s, -s, 0, 1, 1, r, g, b, a);
        put(vc, pose, nrm, s, s, 0, 1, 0, r, g, b, a);
        put(vc, pose, nrm, -s, s, 0, 0, 0, r, g, b, a);
        ps.popPose();
    }

    private static void put(VertexConsumer vc, Matrix4f pose, Matrix3f nrm, float x, float y, float z, float u, float v,
                            float r, float g, float b, float a) {
        vc.vertex(pose, x, y, z).color(r, g, b, a).uv(u, v).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(FULL_BRIGHT).normal(nrm, 0, 0, 1).endVertex();
    }
}
