package com.theboys.mod.client;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;

public class FlameParticle extends TextureSheetParticle {
    private final boolean flow;

    protected FlameParticle(ClientLevel level, double x, double y, double z, double vx, double vy, double vz, SpriteSet sprites, boolean flow, float sizeMul) {
        super(level, x, y, z);
        this.flow = flow;
        this.xd = vx;
        this.yd = vy;
        this.zd = vz;
        this.gravity = 0f;
        this.friction = flow ? 1.0f : 0.93f;
        this.hasPhysics = false;
        this.lifetime = flow ? 12 : 12 + this.random.nextInt(12);
        this.quadSize = flow ? 0.12f + this.random.nextFloat() * 0.06f : 0.16f + this.random.nextFloat() * 0.14f;
        if (!flow && vx * vx + vy * vy + vz * vz < 0.0004) this.yd += 0.02;
        this.quadSize *= sizeMul;
        this.pickSprite(sprites);
        this.rCol = 1f; this.gCol = 0.95f; this.bCol = 0.6f; this.alpha = 1f;
    }

    @Override
    public void tick() {
        super.tick();
        float t = Math.min(1f, (float) this.age / (float) this.lifetime);
        if (this.flow) {
            this.rCol = 1f;
            this.gCol = 0.85f - 0.35f * t;
            this.bCol = 0.45f - 0.35f * t;
            this.alpha = Math.min(1f, t * 5f) * (1f - 0.25f * t);
        } else {
            this.rCol = t < 0.75f ? 1f : Math.max(0.3f, 1f - (t - 0.75f) * 2.8f);
            this.gCol = Math.max(0.1f, 0.95f - 0.85f * t);
            this.bCol = Math.max(0.03f, 0.55f - 0.6f * t);
            this.alpha = 1f - t * t;
        }
    }

    @Override
    public float getQuadSize(float partial) {
        float t = ((float) this.age + partial) / (float) this.lifetime;
        return this.quadSize * (this.flow ? 1f - 0.3f * t : 1f - 0.65f * t);
    }

    @Override
    protected int getLightColor(float partial) { return 15728880; }

    @Override
    public ParticleRenderType getRenderType() { return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT; }

    public static class Provider implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet sprites;
        private final boolean flow;
        private final float sizeMul;

        public Provider(SpriteSet sprites, boolean flow, float sizeMul) {
            this.sprites = sprites;
            this.flow = flow;
            this.sizeMul = sizeMul;
        }

        @Override
        public net.minecraft.client.particle.Particle createParticle(SimpleParticleType type, ClientLevel level,
                                                                      double x, double y, double z, double vx, double vy, double vz) {
            return new FlameParticle(level, x, y, z, vx, vy, vz, this.sprites, this.flow, this.sizeMul);
        }
    }
}
