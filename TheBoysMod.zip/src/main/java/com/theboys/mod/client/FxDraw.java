package com.theboys.mod.client;

import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Camera;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;
import org.joml.Vector3f;

public class FxDraw {
    public static void beam(VertexConsumer vc, Matrix4f m, Vec3 a, Vec3 b, Vec3 cam, float w, float r, float g, float bl, float al) {
        Vec3 d = b.subtract(a);
        Vec3 mid = a.add(b).scale(0.5).subtract(cam);
        Vec3 side = d.cross(mid);
        if (side.lengthSqr() < 1.0E-10) return;
        side = side.normalize().scale(w);
        Vec3 ra = a.subtract(cam), rb = b.subtract(cam);
        quad(vc, m, ra.add(side), ra.subtract(side), rb.subtract(side), rb.add(side), r, g, bl, al);
    }

    public static void disc(VertexConsumer vc, Matrix4f m, Vec3 c, Vec3 cam, Camera camera, float radius, float r, float g, float b, float al) {
        Vector3f left = camera.getLeftVector();
        Vector3f up = camera.getUpVector();
        Vec3 l = new Vec3(left.x(), left.y(), left.z()).scale(radius);
        Vec3 u = new Vec3(up.x(), up.y(), up.z()).scale(radius);
        Vec3 rc = c.subtract(cam);
        quad(vc, m, rc.add(l).add(u), rc.subtract(l).add(u), rc.subtract(l).subtract(u), rc.add(l).subtract(u), r, g, b, al);
    }

    public static void face(VertexConsumer vc, Matrix4f m, Vec3 cam, Vec3 p1, Vec3 p2, Vec3 p3, Vec3 p4, float r, float g, float b, float a) {
        quad(vc, m, p1.subtract(cam), p2.subtract(cam), p3.subtract(cam), p4.subtract(cam), r, g, b, a);
    }

    public static void box(VertexConsumer vc, Matrix4f m, Vec3 cam, AABB bb, float edge, float r, float g, float b, float fillAlpha) {
        Vec3[] c = {
                new Vec3(bb.minX, bb.minY, bb.minZ), new Vec3(bb.maxX, bb.minY, bb.minZ),
                new Vec3(bb.maxX, bb.minY, bb.maxZ), new Vec3(bb.minX, bb.minY, bb.maxZ),
                new Vec3(bb.minX, bb.maxY, bb.minZ), new Vec3(bb.maxX, bb.maxY, bb.minZ),
                new Vec3(bb.maxX, bb.maxY, bb.maxZ), new Vec3(bb.minX, bb.maxY, bb.maxZ)};
        int[][] edges = {{0, 1}, {1, 2}, {2, 3}, {3, 0}, {4, 5}, {5, 6}, {6, 7}, {7, 4}, {0, 4}, {1, 5}, {2, 6}, {3, 7}};
        for (int[] e : edges) beam(vc, m, c[e[0]], c[e[1]], cam, edge, r, g, b, 0.95f);
        if (fillAlpha > 0) {
            int[][] faces = {{0, 1, 2, 3}, {4, 5, 6, 7}, {0, 1, 5, 4}, {1, 2, 6, 5}, {2, 3, 7, 6}, {3, 0, 4, 7}};
            for (int[] f : faces) face(vc, m, cam, c[f[0]], c[f[1]], c[f[2]], c[f[3]], r, g, b, fillAlpha);
        }
    }

    public static void quad(VertexConsumer vc, Matrix4f m, Vec3 p1, Vec3 p2, Vec3 p3, Vec3 p4, float r, float g, float b, float a) {
        vc.vertex(m, (float) p1.x, (float) p1.y, (float) p1.z).color(r, g, b, a).endVertex();
        vc.vertex(m, (float) p2.x, (float) p2.y, (float) p2.z).color(r, g, b, a).endVertex();
        vc.vertex(m, (float) p3.x, (float) p3.y, (float) p3.z).color(r, g, b, a).endVertex();
        vc.vertex(m, (float) p4.x, (float) p4.y, (float) p4.z).color(r, g, b, a).endVertex();
    }
}
