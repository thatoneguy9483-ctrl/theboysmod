package com.theboys.mod.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

public class FxParticle extends TextureSheetParticle {
    public static class Cfg {
        int lifeMin = 20, lifeMax = 30;
        float s0 = 0.1f, s1 = 0.1f;
        float r0 = 1, g0 = 1, b0 = 1, r1 = 1, g1 = 1, b1 = 1;
        float a0 = 1, a1 = 0;
        float gravity = 0f, friction = 0.95f;
        boolean fullbright = false, physics = false, overlay = false;
        float spin = 0f;

        public Cfg life(int min, int max) { lifeMin = min; lifeMax = max; return this; }
        public Cfg size(float from, float to) { s0 = from; s1 = to; return this; }
        public Cfg color(float r0, float g0, float b0, float r1, float g1, float b1) {
            this.r0 = r0; this.g0 = g0; this.b0 = b0; this.r1 = r1; this.g1 = g1; this.b1 = b1; return this;
        }
        public Cfg alpha(float from, float to) { a0 = from; a1 = to; return this; }
        public Cfg gravity(float g) { gravity = g; return this; }
        public Cfg friction(float f) { friction = f; return this; }
        public Cfg bright() { fullbright = true; return this; }
        public Cfg physics() { physics = true; return this; }
        public Cfg spin(float s) { spin = s; return this; }
        public Cfg overlay() { overlay = true; return this; }
    }

    private static final ParticleRenderType OVERLAY = new ParticleRenderType() {
        @Override
        public void begin(BufferBuilder builder, TextureManager textures) {
            RenderSystem.depthMask(false);
            RenderSystem.disableDepthTest();
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            RenderSystem.setShader(GameRenderer::getParticleShader);
            RenderSystem.setShaderTexture(0, TextureAtlas.LOCATION_PARTICLES);
            builder.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.PARTICLE);
        }

        @Override
        public void end(Tesselator tesselator) {
            tesselator.end();
            RenderSystem.enableDepthTest();
            RenderSystem.depthMask(true);
        }

        @Override
        public String toString() { return "theboys:overlay"; }
    };

    private final Cfg c;

    protected FxParticle(ClientLevel level, double x, double y, double z, double vx, double vy, double vz, SpriteSet sprites, Cfg c) {
        super(level, x, y, z);
        this.c = c;
        this.xd = vx;
        this.yd = vy;
        this.zd = vz;
        this.gravity = c.gravity;
        this.friction = c.friction;
        this.hasPhysics = c.physics;
        this.lifetime = c.lifeMin + (c.lifeMax > c.lifeMin ? this.random.nextInt(c.lifeMax - c.lifeMin + 1) : 0);
        this.quadSize = c.s0;
        this.roll = this.random.nextFloat() * 6.283f;
        this.oRoll = this.roll;
        this.pickSprite(sprites);
        this.rCol = c.r0; this.gCol = c.g0; this.bCol = c.b0; this.alpha = c.a0;
    }

    @Override
    public void tick() {
        super.tick();
        float t = Math.min(1f, (float) this.age / (float) this.lifetime);
        this.rCol = Mth.lerp(t, c.r0, c.r1);
        this.gCol = Mth.lerp(t, c.g0, c.g1);
        this.bCol = Mth.lerp(t, c.b0, c.b1);
        this.alpha = Mth.lerp(t, c.a0, c.a1);
        this.oRoll = this.roll;
        this.roll += c.spin;
    }

    @Override
    public float getQuadSize(float partial) {
        float t = Math.min(1f, ((float) this.age + partial) / (float) this.lifetime);
        float size = Mth.lerp(t, c.s0, c.s1);
        if (c.overlay) {
            Vec3 cam = Minecraft.getInstance().gameRenderer.getMainCamera().getPosition();
            double dx = cam.x - this.x, dy = cam.y - this.y, dz = cam.z - this.z;
            float dist = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
            size *= Mth.clamp(dist / 8.0f, 1.0f, 10.0f);
        }
        return size;
    }

    @Override
    protected int getLightColor(float partial) {
        return c.fullbright ? 15728880 : super.getLightColor(partial);
    }

    @Override
    public ParticleRenderType getRenderType() { return c.overlay ? OVERLAY : ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT; }

    public static class Provider implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet sprites;
        private final Cfg cfg;

        public Provider(SpriteSet sprites, Cfg cfg) {
            this.sprites = sprites;
            this.cfg = cfg;
        }

        @Override
        public Particle createParticle(SimpleParticleType type, ClientLevel level, double x, double y, double z, double vx, double vy, double vz) {
            return new FxParticle(level, x, y, z, vx, vy, vz, this.sprites, this.cfg);
        }
    }
}
