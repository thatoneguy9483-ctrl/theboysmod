package com.theboys.mod.client;

import com.theboys.mod.TheBoysMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.HeadedModel;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashMap;
import java.util.Map;

@Mod.EventBusSubscriber(modid = TheBoysMod.MOD_ID, value = Dist.CLIENT)
public class HeadlessClient {
    private static final long KEEP_TICKS = 400;
    private static final Map<Integer, Long> MARKED = new HashMap<>();

    private static ModelPart headPart, hatPart;
    private static boolean headWas, hatWas;

    public static void mark(int id) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        MARKED.put(id, mc.level.getGameTime() + KEEP_TICKS);
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END || MARKED.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) {
            MARKED.clear();
            return;
        }
        long now = mc.level.getGameTime();
        MARKED.values().removeIf(t -> t < now);
    }

    @SubscribeEvent
    public static void onPre(RenderLivingEvent.Pre<?, ?> e) {
        if (!MARKED.containsKey(e.getEntity().getId())) return;
        EntityModel<?> m = e.getRenderer().getModel();
        if (m instanceof HeadedModel hm) {
            headPart = hm.getHead();
            headWas = headPart.visible;
            headPart.visible = false;
        }
        if (m instanceof HumanoidModel<?> hu) {
            hatPart = hu.hat;
            hatWas = hatPart.visible;
            hatPart.visible = false;
        }
    }

    @SubscribeEvent
    public static void onPost(RenderLivingEvent.Post<?, ?> e) {
        if (headPart != null) {
            headPart.visible = headWas;
            headPart = null;
        }
        if (hatPart != null) {
            hatPart.visible = hatWas;
            hatPart = null;
        }
    }
}
