package com.theboys.mod.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.theboys.mod.ImpactBurstEntity;
import com.theboys.mod.TheBoysMod;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Quaternionf;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.WeakHashMap;

/**
 * Blood: droplets fly out, and each one is traced through the actual blocks around the wound, so it splatters on
 * whatever it really hits: floors (at the real floor height, even past a ledge), walls and ceilings.
 * A red mist and a puddle are added when the victim bursts. Droplet paths are planned once per effect.
 */
public class ImpactBurstRenderer extends EntityRenderer<ImpactBurstEntity> {

    // ---- tweak these ----
    private static final int MIST_PUFFS = 16;
    private static final int FADE = 60;                         // ticks to fade out at the end
    private static final double GRAVITY = 0.04;
    private static final double MARCH_STEP = 2.0;               // ticks per collision check
    private static final double MARCH_MAX = 70.0;               // give up on a droplet after this many ticks

    private static final ResourceLocation DROP = new ResourceLocation(TheBoysMod.MOD_ID, "textures/effect/blood_drop.png");
    private static final ResourceLocation MIST = new ResourceLocation(TheBoysMod.MOD_ID, "textures/effect/blood_mist.png");
    private static final ResourceLocation PUDDLE = new ResourceLocation(TheBoysMod.MOD_ID, "textures/effect/blood_puddle.png");

    private static final class Drop {
        double vx, vy, vz, size, landT;
        Vec3 rel = Vec3.ZERO, normal = new Vec3(0, 1, 0);
        boolean landed;
        int idx;
    }

    private static final class Plan {
        final List<Drop> drops = new ArrayList<>();
        boolean puddle;
        Vec3 puddleRel = Vec3.ZERO;
    }

    private static final Map<ImpactBurstEntity, Plan> PLANS = new WeakHashMap<>();

    public ImpactBurstRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
        this.shadowRadius = 0f;
    }

    @Override public ResourceLocation getTextureLocation(ImpactBurstEntity e) { return PUDDLE; }

    @Override
    public boolean shouldRender(ImpactBurstEntity e, net.minecraft.client.renderer.culling.Frustum f, double x, double y, double z) {
        return true;
    }

    private static float smooth(float u) { u = Math.max(0f, Math.min(1f, u)); return u * u * (3f - 2f * u); }

    // ---------- planning ----------
    private Plan build(ImpactBurstEntity e) {
        Plan plan = new Plan();
        Level lv = e.level();
        Vec3 o = e.position();
        boolean lethal = e.isLethal();
        float scale = e.getScale();
        boolean mild = scale < 0.55f;                               // small wounds (lost limbs): gentler, all directions
        double yr = Math.toRadians(e.getYRot());
        double fx = -Math.sin(yr), fz = Math.cos(yr);
        Random rd = new Random(e.getId() * 104729L + 7L);

        for (int i = 0; i < e.getCount(); i++) {
            double a = rd.nextDouble(), b = rd.nextDouble(), c = rd.nextDouble(), d = rd.nextDouble(), s = rd.nextDouble();
            float om = rd.nextFloat();
            boolean omni = lethal ? om < 0.55f : (mild && om < 0.7f);
            Drop dr = new Drop();
            dr.idx = i;
            if (omni) {
                double th = a * Math.PI * 2, ph = Math.acos(2 * b - 1), sp = 0.15 + c * 0.45;
                dr.vx = sp * Math.sin(ph) * Math.cos(th);
                dr.vz = sp * Math.sin(ph) * Math.sin(th);
                dr.vy = Math.abs(sp * Math.cos(ph)) * 1.2 + 0.05;
            } else {
                double sp = (0.35 + a * 0.7) * (lethal ? 1.3 : 1.0);
                dr.vx = fx * sp + (b - 0.5) * 0.45;
                dr.vz = fz * sp + (c - 0.5) * 0.45;
                dr.vy = 0.08 + d * 0.4;
            }
            if (mild) { dr.vx *= 0.55; dr.vz *= 0.55; dr.vy *= 0.8; }
            dr.size = (0.08 + s * 0.14) * (0.7 + 0.5 * scale) * (mild ? 0.85 : 1.0);

            // march the droplet through the world until it hits a block
            Vec3 prev = o;
            double prevT = 0;
            dr.landT = MARCH_MAX;
            for (double t = MARCH_STEP; t <= MARCH_MAX; t += MARCH_STEP) {
                Vec3 cur = o.add(dr.vx * t, dr.vy * t - 0.5 * GRAVITY * t * t, dr.vz * t);
                BlockHitResult h = lv.clip(new ClipContext(prev, cur, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, e));
                if (h.getType() == HitResult.Type.BLOCK) {
                    double total = prev.distanceTo(cur);
                    double frac = total < 1.0E-6 ? 0 : prev.distanceTo(h.getLocation()) / total;
                    dr.landT = prevT + (t - prevT) * frac;
                    dr.landed = true;
                    dr.rel = h.getLocation().subtract(o);
                    dr.normal = new Vec3(h.getDirection().getStepX(), h.getDirection().getStepY(), h.getDirection().getStepZ());
                    break;
                }
                prev = cur;
                prevT = t;
            }
            plan.drops.add(dr);
        }

        // main puddle: straight down from the wound onto whatever is really below
        BlockHitResult down = lv.clip(new ClipContext(o, o.add(0, -8, 0), ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, e));
        if (down.getType() == HitResult.Type.BLOCK) {
            plan.puddle = true;
            plan.puddleRel = down.getLocation().subtract(o);
        }
        return plan;
    }

    // ---------- rendering ----------
    @Override
    public void render(ImpactBurstEntity e, float yaw, float pt, PoseStack ps, MultiBufferSource buf, int light) {
        final float age = e.tickCount + pt;
        final boolean lethal = e.isLethal();
        final float scale = e.getScale();
        final int life = e.getLife();
        if (age >= life) return;
        final float fade = age > life - FADE ? smooth((life - age) / FADE) : 1f;
        final Plan plan = PLANS.computeIfAbsent(e, this::build);
        final Quaternionf cam = this.entityRenderDispatcher.cameraOrientation();

        // mist (only when the victim bursts)
        if (lethal && age < 18f) {
            Random r = new Random(e.getId() * 7919L + 13L);
            VertexConsumer mv = buf.getBuffer(RenderType.entityTranslucent(MIST));
            float mt = age / 18f;
            float ease = 1f - (1f - mt) * (1f - mt);
            for (int i = 0; i < MIST_PUFFS; i++) {
                double ox = (r.nextDouble() - 0.5) * 0.9 * scale, oy = (r.nextDouble() - 0.3) * 0.9 * scale, oz = (r.nextDouble() - 0.5) * 0.9 * scale;
                double dxv = (r.nextDouble() - 0.5) * 0.5, dyv = r.nextDouble() * 0.3, dzv = (r.nextDouble() - 0.5) * 0.5;
                float size = (0.5f + 1.5f * ease) * scale * (0.7f + r.nextFloat() * 0.6f);
                billboard(mv, ps, cam, ox + dxv * age * 0.25, oy + dyv * age * 0.25, oz + dzv * age * 0.25, size, 0.7f * smooth(1f - mt), light);
            }
        }

        // droplets in flight, then splatters where they actually land
        VertexConsumer dv = buf.getBuffer(RenderType.entityTranslucent(DROP));
        List<Drop> landedNow = new ArrayList<>();
        for (Drop d : plan.drops) {
            if (age < d.landT) {
                double x = d.vx * age, y = d.vy * age - 0.5 * GRAVITY * age * age, z = d.vz * age;
                billboard(dv, ps, cam, x, y, z, (float) d.size, fade, light);
            } else if (d.landed) {
                landedNow.add(d);
            }
        }

        VertexConsumer pv = buf.getBuffer(RenderType.entityTranslucent(PUDDLE));
        for (Drop d : landedNow) {
            float grow = (float) Math.min(1.0, (age - d.landT) / 3.0);
            decal(pv, ps, d.rel, d.normal, (float) (d.size * 2.4 * grow), (d.idx * 47) % 360, 0.9f * fade, light);
        }
        if (plan.puddle) {
            float fall = (float) Math.sqrt(2.0 * Math.max(0.05, -plan.puddleRel.y) / GRAVITY);
            if (age > fall * 0.8f) {
                float grow = smooth((age - fall * 0.8f) / 14f);
                float radius = (lethal ? 1.15f : (scale < 0.55f ? 0.2f : 0.38f)) * scale * grow;
                decal(pv, ps, plan.puddleRel.add(0, 0.003, 0), new Vec3(0, 1, 0), radius, (e.getId() * 53) % 360, 0.95f * fade, light);
            }
        }
    }

    // ---------- drawing helpers ----------
    private static void billboard(VertexConsumer vc, PoseStack ps, Quaternionf cam, double x, double y, double z, float s, float a, int light) {
        if (a <= 0.003f) return;
        ps.pushPose();
        ps.translate(x, y, z);
        ps.mulPose(cam);
        Matrix4f pose = ps.last().pose();
        Matrix3f nrm = ps.last().normal();
        put(vc, pose, nrm, -s, -s, 0, 0, 1, a, light, 0, 0, 1);
        put(vc, pose, nrm, s, -s, 0, 1, 1, a, light, 0, 0, 1);
        put(vc, pose, nrm, s, s, 0, 1, 0, a, light, 0, 0, 1);
        put(vc, pose, nrm, -s, s, 0, 0, 0, a, light, 0, 0, 1);
        ps.popPose();
    }

    /** A flat splat lying on any surface: floor, wall or ceiling (rotated so it faces along the surface normal). */
    private static void decal(VertexConsumer vc, PoseStack ps, Vec3 rel, Vec3 n, float s, float spinDeg, float a, int light) {
        if (a <= 0.003f || s <= 0.003f) return;
        ps.pushPose();
        ps.translate(rel.x + n.x * 0.012, rel.y + n.y * 0.012, rel.z + n.z * 0.012);
        ps.mulPose(new Quaternionf().rotationTo(0f, 1f, 0f, (float) n.x, (float) n.y, (float) n.z));
        ps.mulPose(Axis.YP.rotationDegrees(spinDeg));
        Matrix4f pose = ps.last().pose();
        Matrix3f nrm = ps.last().normal();
        put(vc, pose, nrm, -s, 0, -s, 0, 0, a, light, 0, 1, 0);
        put(vc, pose, nrm, -s, 0, s, 0, 1, a, light, 0, 1, 0);
        put(vc, pose, nrm, s, 0, s, 1, 1, a, light, 0, 1, 0);
        put(vc, pose, nrm, s, 0, -s, 1, 0, a, light, 0, 1, 0);
        ps.popPose();
    }

    private static void put(VertexConsumer vc, Matrix4f pose, Matrix3f nrm, float x, float y, float z, float u, float v,
                            float a, int light, float nx, float ny, float nz) {
        vc.vertex(pose, x, y, z).color(1f, 1f, 1f, a).uv(u, v).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(light).normal(nrm, nx, ny, nz).endVertex();
    }
}
