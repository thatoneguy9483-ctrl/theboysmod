package com.theboys.mod.client;

import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.renderer.RenderType;

public class OverlayRenderTypes extends RenderType {
    private OverlayRenderTypes(String name, VertexFormat format, VertexFormat.Mode mode, int buffer, boolean affectsCrumbling, boolean sort, Runnable setup, Runnable clear) {
        super(name, format, mode, buffer, affectsCrumbling, sort, setup, clear);
        throw new IllegalStateException("not instantiable");
    }

    public static final RenderType BEAM = create("theboys_beam",
            DefaultVertexFormat.POSITION_COLOR, VertexFormat.Mode.QUADS, 1024, false, false,
            RenderType.CompositeState.builder()
                    .setShaderState(POSITION_COLOR_SHADER)
                    .setTransparencyState(LIGHTNING_TRANSPARENCY)
                    .setWriteMaskState(COLOR_WRITE)
                    .setCullState(NO_CULL)
                    .createCompositeState(false));
}
