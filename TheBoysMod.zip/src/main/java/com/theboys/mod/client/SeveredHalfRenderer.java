package com.theboys.mod.client;

import com.mojang.authlib.GameProfile;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.theboys.mod.SeveredHalfEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.client.player.RemotePlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.resources.DefaultPlayerSkin;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import org.joml.Vector3f;

import java.util.Map;
import java.util.UUID;
import java.util.WeakHashMap;

/**
 * Draws one half of a cut body. It rebuilds a copy of the victim on the client (same type, equipment and saved data, or the
 * player's skin) and renders it through ClipBufferSource, which keeps only the part above (or below) the cut plane.
 * The upper half topples over at the cut; the lower half stays standing for a moment and then falls.
 */
public class SeveredHalfRenderer extends EntityRenderer<SeveredHalfEntity> {

    private final Map<SeveredHalfEntity, Entity> dummies = new WeakHashMap<>();

    public SeveredHalfRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
        this.shadowRadius = 0f;
    }

    @Override
    public ResourceLocation getTextureLocation(SeveredHalfEntity e) { return DefaultPlayerSkin.getDefaultSkin(); }

    @Override
    public boolean shouldRender(SeveredHalfEntity e, net.minecraft.client.renderer.culling.Frustum f, double x, double y, double z) { return true; }

    private Entity dummyFor(SeveredHalfEntity e) {
        Entity d = this.dummies.get(e);
        if (d != null) return d;
        try {
            if (!(e.level() instanceof ClientLevel lv)) return null;
            String id = e.getTypeId();
            if ("minecraft:player".equals(id)) {
                UUID owner = e.getOwnerId().orElse(null);
                if (owner == null) return null;
                PlayerInfo info = Minecraft.getInstance().getConnection() == null ? null : Minecraft.getInstance().getConnection().getPlayerInfo(owner);
                GameProfile gp = info != null ? info.getProfile() : new GameProfile(owner, "player");
                d = new RemotePlayer(lv, gp);
            } else {
                EntityType<?> type = EntityType.byString(id).orElse(null);
                if (type == null) return null;
                d = type.create(lv);
                CompoundTag nbt = e.getVictimNbt();
                if (d != null && nbt != null && !nbt.isEmpty()) {
                    try { d.load(nbt); } catch (Exception ignored) { }
                }
            }
            if (d == null) return null;
            if (d instanceof LivingEntity le) {
                ListTag equip = e.getEquip();
                for (int i = 0; i < equip.size(); i++) {
                    CompoundTag c = equip.getCompound(i);
                    EquipmentSlot slot = EquipmentSlot.byName(c.getString("slot"));
                    le.setItemSlot(slot, ItemStack.of(c.getCompound("item")));
                }
            }
            d.setInvisible(false);
            d.setCustomNameVisible(false);
            this.dummies.put(e, d);
            return d;
        } catch (Exception ex) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public void render(SeveredHalfEntity e, float yaw, float pt, PoseStack ps, MultiBufferSource buf, int light) {
        Entity dummy = dummyFor(e);
        if (dummy == null) return;

        float h = e.getBodyHeight();
        float cut = h * e.getCutFraction();
        float age = e.tickCount + pt;
        boolean upper = e.isUpper();
        float side = (e.getId() % 2 == 0) ? 1f : -1f;

        float remaining = SeveredHalfEntity.LIFETIME - age;
        float scale = Mth.clamp(remaining / 20f, 0f, 1f);       // shrink away at the end
        if (scale <= 0f) return;

        float bodyYaw = e.getBodyYaw();
        dummy.setPos(0, 0, 0);
        dummy.setYRot(bodyYaw);
        dummy.yRotO = bodyYaw;
        dummy.setXRot(0);
        dummy.xRotO = 0;
        if (dummy instanceof LivingEntity le) {
            le.yBodyRot = bodyYaw; le.yBodyRotO = bodyYaw;
            le.yHeadRot = bodyYaw; le.yHeadRotO = bodyYaw;
            le.hurtTime = 0; le.deathTime = 0;
        }

        ps.pushPose();
        ps.scale(scale, scale, scale);
        ps.mulPose(Axis.YP.rotationDegrees((e.getId() * 53) % 360));        // which way it topples
        if (upper) {
            float prog = Math.min(1f, age / 7f);
            ps.translate(0, -(cut - 0.2f) * prog, 0);                       // comes to rest on the ground
            ps.translate(0, cut, 0);
            ps.mulPose(Axis.ZP.rotationDegrees(prog * 90f * side));
            ps.translate(0, -cut, 0);
        } else {
            float prog = Mth.clamp((age - 5f) / 9f, 0f, 1f);
            ps.mulPose(Axis.ZP.rotationDegrees(-prog * 90f * side));
        }

        // the cut plane, in the space the vertices will arrive in
        Vector3f origin = new Vector3f(0, cut, 0);
        ps.last().pose().transformPosition(origin);
        Vector3f normal = new Vector3f(0, 1, 0);
        ps.last().normal().transform(normal);
        normal.normalize();

        ClipBufferSource clipped = new ClipBufferSource(buf, origin, normal, upper ? 1f : -1f);
        EntityRenderer<Entity> r = (EntityRenderer<Entity>) (EntityRenderer<?>) Minecraft.getInstance().getEntityRenderDispatcher().getRenderer(dummy);
        r.render(dummy, bodyYaw, pt, ps, clipped, light);
        ps.popPose();
    }
}
