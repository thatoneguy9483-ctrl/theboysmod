package com.theboys.mod.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.theboys.mod.SeveredLimbEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.resources.DefaultPlayerSkin;
import net.minecraft.resources.ResourceLocation;

import java.util.UUID;

public class SeveredLimbRenderer extends EntityRenderer<SeveredLimbEntity> {

    private final PlayerModel<AbstractClientPlayer> wide;
    private final PlayerModel<AbstractClientPlayer> slim;

    public SeveredLimbRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
        this.shadowRadius = 0.0f;
        this.wide = new PlayerModel<>(ctx.bakeLayer(ModelLayers.PLAYER), false);
        this.slim = new PlayerModel<>(ctx.bakeLayer(ModelLayers.PLAYER_SLIM), true);
    }

    @Override
    public ResourceLocation getTextureLocation(SeveredLimbEntity entity) {
        return DefaultPlayerSkin.getDefaultSkin();
    }

    @Override
    public void render(SeveredLimbEntity e, float yaw, float partialTick, PoseStack ps, MultiBufferSource buf, int light) {
        UUID id = e.getOwner().orElse(null);
        PlayerInfo info = null;
        if (id != null && Minecraft.getInstance().getConnection() != null) {
            info = Minecraft.getInstance().getConnection().getPlayerInfo(id);
        }
        ResourceLocation tex = info != null ? info.getSkinLocation()
                : id != null ? DefaultPlayerSkin.getDefaultSkin(id) : DefaultPlayerSkin.getDefaultSkin();
        boolean isSlim = info != null ? "slim".equals(info.getModelName())
                : id != null && "slim".equals(DefaultPlayerSkin.getSkinModelName(id));
        PlayerModel<AbstractClientPlayer> m = isSlim ? slim : wide;

        ModelPart base, overlay;
        boolean leg = false;
        switch (e.getLimb()) {
            case 1 -> { base = m.leftArm; overlay = m.leftSleeve; }
            case 2 -> { base = m.rightArm; overlay = m.rightSleeve; }
            case 4 -> { base = m.leftLeg; overlay = m.leftPants; leg = true; }
            default -> { base = m.rightLeg; overlay = m.rightPants; leg = true; }
        }
        for (ModelPart p : new ModelPart[]{base, overlay}) {
            p.setPos(0, 0, 0);
            p.xRot = 0; p.yRot = 0; p.zRot = 0;
            p.visible = true;
        }

        float remaining = SeveredLimbEntity.LIFETIME - (e.tickCount + partialTick);
        float scale = Math.max(0f, Math.min(1f, remaining / 20f));   // shrink away at the end

        ps.pushPose();
        ps.translate(0, 0.125 * scale, 0);
        ps.scale(scale, scale, scale);
        ps.mulPose(Axis.YP.rotationDegrees((e.getId() * 47) % 360));
        ps.mulPose(Axis.XP.rotationDegrees(90));
        ps.scale(-1, -1, 1);
        ps.translate(0, leg ? -0.375 : -0.25, 0);
        VertexConsumer vc = buf.getBuffer(RenderType.entityCutoutNoCull(tex));
        base.render(ps, vc, light, OverlayTexture.NO_OVERLAY);
        overlay.render(ps, vc, light, OverlayTexture.NO_OVERLAY);
        ps.popPose();
    }
}
