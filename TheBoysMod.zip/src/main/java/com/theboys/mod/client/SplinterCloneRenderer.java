package com.theboys.mod.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.theboys.mod.SplinterCloneEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.client.resources.DefaultPlayerSkin;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;

import java.util.UUID;

public class SplinterCloneRenderer extends HumanoidMobRenderer<SplinterCloneEntity, PlayerModel<SplinterCloneEntity>> {
    private static final int GHOSTS = 3;
    private static final float GHOST_LAG = 0.13f;

    private final PlayerModel<SplinterCloneEntity> wideModel;
    private final PlayerModel<SplinterCloneEntity> slimModel;
    private boolean ghosting;

    public SplinterCloneRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new PlayerModel<>(ctx.bakeLayer(ModelLayers.PLAYER), false), 0.5f);
        this.wideModel = this.model;
        this.slimModel = new PlayerModel<>(ctx.bakeLayer(ModelLayers.PLAYER_SLIM), true);
        this.addLayer(new HumanoidArmorLayer<>(this,
                new HumanoidModel<>(ctx.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)),
                new HumanoidModel<>(ctx.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR)),
                ctx.getModelManager()));
    }

    private static PlayerInfo infoOf(SplinterCloneEntity e) {
        UUID id = e.getOwnerId().orElse(null);
        ClientPacketListener conn = Minecraft.getInstance().getConnection();
        return id != null && conn != null ? conn.getPlayerInfo(id) : null;
    }

    @Override
    public ResourceLocation getTextureLocation(SplinterCloneEntity e) {
        PlayerInfo info = infoOf(e);
        if (info != null) return info.getSkinLocation();
        return DefaultPlayerSkin.getDefaultSkin(e.getOwnerId().orElse(e.getUUID()));
    }

    @Override
    protected void scale(SplinterCloneEntity e, PoseStack ps, float pt) {
        ps.scale(0.9375f, 0.9375f, 0.9375f);
    }

    @Override
    protected boolean shouldShowName(SplinterCloneEntity e) {
        return !ghosting && super.shouldShowName(e);
    }

    private static float smooth(float x) {
        x = Mth.clamp(x, 0f, 1f);
        return x * x * (3f - 2f * x);
    }

    @Override
    public void render(SplinterCloneEntity e, float yaw, float pt, PoseStack ps, MultiBufferSource buf, int light) {
        PlayerInfo info = infoOf(e);
        UUID id = e.getOwnerId().orElse(e.getUUID());
        String modelName = info != null ? info.getModelName() : DefaultPlayerSkin.getSkinModelName(id);
        this.model = "slim".equals(modelName) ? slimModel : wideModel;

        float p = e.splitProgress(pt);
        if (p >= 0.999f) {
            super.render(e, yaw, pt, ps, buf, light);
            return;
        }

        ResourceLocation skin = getTextureLocation(e);
        boolean merging = e.isMerging();

        double dx = 0, dy = 0, dz = 0;
        Player owner = e.getOwner();
        if (owner != null) {
            dx = Mth.lerp(pt, owner.xo, owner.getX()) - Mth.lerp(pt, e.xo, e.getX());
            dy = Mth.lerp(pt, owner.yo, owner.getY()) - Mth.lerp(pt, e.yo, e.getY());
            dz = Mth.lerp(pt, owner.zo, owner.getZ()) - Mth.lerp(pt, e.zo, e.getZ());
        }

        float shake = (1f - p) * 0.06f * Mth.sin((e.tickCount + pt) * 2.7f);

        ghosting = true;
        for (int i = GHOSTS; i >= 0; i--) {
            float pp = merging ? Math.min(1f, p + i * GHOST_LAG) : p - i * GHOST_LAG;
            if (pp <= 0f && i > 0) continue;
            float ease = smooth(pp);
            float alpha;
            if (i == 0) {
                alpha = 0.35f + 0.65f * p;
            } else {
                alpha = (0.34f / i) * Mth.clamp(1.25f - p, 0f, 1f);
            }
            ps.pushPose();
            ps.translate(dx * (1.0 - ease) + shake * (i + 1), dy * (1.0 - ease), dz * (1.0 - ease));
            super.render(e, yaw, pt, ps, new GhostBuffer(buf, skin, alpha), light);
            ps.popPose();
        }
        ghosting = false;
    }

    private static final class GhostBuffer implements MultiBufferSource {
        private final MultiBufferSource delegate;
        private final ResourceLocation skin;
        private final String skinKey;
        private final float alpha;

        GhostBuffer(MultiBufferSource delegate, ResourceLocation skin, float alpha) {
            this.delegate = delegate;
            this.skin = skin;
            this.skinKey = skin.toString();
            this.alpha = alpha;
        }

        @Override
        public VertexConsumer getBuffer(RenderType type) {
            if (type.toString().contains(skinKey)) {
                return new Ghost(delegate.getBuffer(RenderType.entityTranslucent(skin)), alpha);
            }
            return delegate.getBuffer(type);
        }
    }

    private static final class Ghost implements VertexConsumer {
        private final VertexConsumer v;
        private final float alpha;

        Ghost(VertexConsumer v, float alpha) {
            this.v = v;
            this.alpha = alpha;
        }

        @Override public VertexConsumer vertex(double x, double y, double z) { v.vertex(x, y, z); return this; }
        @Override public VertexConsumer color(int r, int g, int b, int a) { v.color(r, g, b, (int) (a * alpha)); return this; }
        @Override public VertexConsumer uv(float u, float vv) { v.uv(u, vv); return this; }
        @Override public VertexConsumer overlayCoords(int u, int vv) { v.overlayCoords(u, vv); return this; }
        @Override public VertexConsumer uv2(int u, int vv) { v.uv2(u, vv); return this; }
        @Override public VertexConsumer normal(float x, float y, float z) { v.normal(x, y, z); return this; }
        @Override public void endVertex() { v.endVertex(); }
        @Override public void defaultColor(int r, int g, int b, int a) { v.defaultColor(r, g, b, a); }
        @Override public void unsetDefaultColor() { v.unsetDefaultColor(); }
    }
}
