package com.theboys.mod.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.theboys.mod.HomelanderEvents;
import com.theboys.mod.TheBoysMod;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix4f;
import org.joml.Vector3f;

@Mod.EventBusSubscriber(modid = TheBoysMod.MOD_ID, value = Dist.CLIENT)
public class VisionClient {
    private static final double RANGE = 48.0;
    private static final double EYE_SPREAD = 0.115;
    private static final double NECK_HEIGHT = 1.41;
    private static final double EYE_ABOVE_NECK = 0.2;
    private static final double FACE_FORWARD = 0.24;
    private static final double HORIZONTAL_HEAD_REACH = 1.55;

    private static Vec3 dir(float xRot, float yRot) {
        float f = xRot * ((float) Math.PI / 180F);
        float f1 = -yRot * ((float) Math.PI / 180F);
        float f2 = Mth.cos(f1), f3 = Mth.sin(f1), f4 = Mth.cos(f), f5 = Mth.sin(f);
        return new Vec3(f3 * f4, -f5, f2 * f4);
    }

    private static Vec3 headEye(Player p, float pt, Vec3 look) {
        Vec3 feet = new Vec3(Mth.lerp(pt, p.xo, p.getX()), Mth.lerp(pt, p.yo, p.getY()), Mth.lerp(pt, p.zo, p.getZ()));
        if (p.isFallFlying() || p.isVisuallySwimming() || p.getBbHeight() < 1.0f) {
            return feet.add(look.scale(HORIZONTAL_HEAD_REACH));
        }
        Vec3 up = dir(p.getViewXRot(pt) - 90f, p.getViewYRot(pt));
        double neck = NECK_HEIGHT - (p.isCrouching() ? 0.3 : 0.0);
        return feet.add(0, neck, 0).add(up.scale(EYE_ABOVE_NECK)).add(look.scale(FACE_FORWARD));
    }

    @SubscribeEvent
    public static void onRender(RenderLevelStageEvent e) {
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;

        PoseStack ps = e.getPoseStack();
        Camera camera = e.getCamera();
        Vec3 cam = camera.getPosition();
        float pt = e.getPartialTick();
        MultiBufferSource.BufferSource bs = mc.renderBuffers().bufferSource();
        VertexConsumer vc = null;

        for (Player p : mc.level.players()) {
            if (!p.isAlive() || p.isSpectator()) continue;
            AttributeInstance a = p.getAttribute(Attributes.LUCK);
            if (a == null || a.getModifier(HomelanderEvents.VISION_MODIFIER) == null) continue;

            boolean firstPerson = p == mc.player && mc.options.getCameraType().isFirstPerson();
            Vec3 aimEye = p.getEyePosition(pt);
            Vec3 look = p.getViewVector(pt);
            Vec3 origin;
            if (firstPerson) {
                Vector3f cl = camera.getLookVector();
                look = new Vec3(cl.x(), cl.y(), cl.z());
                aimEye = cam;
                origin = cam.add(look.scale(0.3)).add(0, -0.06, 0);
            } else {
                origin = headEye(p, pt, look);
            }

            Vec3 end = aimEye.add(look.scale(RANGE));
            BlockHitResult bh = mc.level.clip(new ClipContext(aimEye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
            Vec3 stop = bh.getType() == HitResult.Type.MISS ? end : bh.getLocation();
            EntityHitResult eh = ProjectileUtil.getEntityHitResult(mc.level, p, aimEye, stop,
                    p.getBoundingBox().expandTowards(look.scale(RANGE)).inflate(1.0), en -> !en.isSpectator() && en.isPickable() && en != p);
            if (eh != null) stop = eh.getLocation();

            Vec3 right = look.cross(new Vec3(0, 1, 0));
            if (right.lengthSqr() < 1.0E-6) right = new Vec3(1, 0, 0);
            right = right.normalize();

            if (vc == null) vc = bs.getBuffer(OverlayRenderTypes.BEAM);
            Matrix4f m = ps.last().pose();
            float flicker = 0.85f + 0.15f * Mth.sin((p.tickCount + pt) * 2.3f);

            for (int side = -1; side <= 1; side += 2) {
                Vec3 from = origin.add(right.scale((firstPerson ? 0.14 : EYE_SPREAD) * side));
                FxDraw.beam(vc, m, from, stop, cam, 0.075f * flicker, 1.0f, 0.08f, 0.02f, 0.22f);
                FxDraw.beam(vc, m, from, stop, cam, 0.04f * flicker, 1.0f, 0.3f, 0.08f, 0.55f);
                FxDraw.beam(vc, m, from, stop, cam, 0.016f, 1.0f, 0.85f, 0.7f, 1.0f);
                FxDraw.disc(vc, m, from, cam, camera, 0.09f, 1.0f, 0.4f, 0.15f, 0.7f);
            }

            float r = (0.28f + 0.1f * Mth.sin((p.tickCount + pt) * 1.7f)) * flicker;
            FxDraw.disc(vc, m, stop, cam, camera, r * 1.6f, 1.0f, 0.1f, 0.03f, 0.35f);
            FxDraw.disc(vc, m, stop, cam, camera, r, 1.0f, 0.45f, 0.12f, 0.7f);
            FxDraw.disc(vc, m, stop, cam, camera, r * 0.45f, 1.0f, 0.95f, 0.8f, 1.0f);
        }
        if (vc != null) bs.endBatch(OverlayRenderTypes.BEAM);
    }
}
