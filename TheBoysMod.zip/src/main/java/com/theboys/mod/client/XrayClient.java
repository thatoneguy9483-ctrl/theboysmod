package com.theboys.mod.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.theboys.mod.HomelanderEvents;
import com.theboys.mod.TheBoysMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * X-ray vision: outlines every living thing that is hidden behind blocks, visible through walls. The client knows the
 * ability is on because its marker attribute modifier is synced.
 */
@Mod.EventBusSubscriber(modid = TheBoysMod.MOD_ID, value = Dist.CLIENT)
public class XrayClient {

    private static final double RANGE = 64.0;
    private static final int MAX_ENTITIES = 60;

    @SubscribeEvent
    public static void onRender(RenderLevelStageEvent e) {
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES) return;
        Minecraft mc = Minecraft.getInstance();
        Player me = mc.player;
        if (me == null || mc.level == null) return;
        AttributeInstance a = me.getAttribute(Attributes.ATTACK_SPEED);
        if (a == null || a.getModifier(HomelanderEvents.XRAY_MODIFIER) == null) return;

        PoseStack ps = e.getPoseStack();
        Vec3 cam = e.getCamera().getPosition();
        float pt = e.getPartialTick();
        MultiBufferSource.BufferSource bs = mc.renderBuffers().bufferSource();
        VertexConsumer vc = bs.getBuffer(XrayRenderTypes.LINES);
        Vec3 eye = me.getEyePosition(pt);

        int n = 0;
        for (LivingEntity t : mc.level.getEntitiesOfClass(LivingEntity.class, me.getBoundingBox().inflate(RANGE), t -> t != me && t.isAlive() && !t.isInvisible())) {
            if (n >= MAX_ENTITIES) break;
            Vec3 head = t.getEyePosition(pt);
            Vec3 body = t.getBoundingBox().getCenter();
            boolean hiddenBody = mc.level.clip(new ClipContext(eye, body, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, me)).getType() != HitResult.Type.MISS;
            boolean hiddenHead = mc.level.clip(new ClipContext(eye, head, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, me)).getType() != HitResult.Type.MISS;
            if (!hiddenBody || !hiddenHead) continue;       // something you can already see needs no outline
            n++;

            Vec3 shift = t.getPosition(pt).subtract(t.position());
            AABB box = t.getBoundingBox().move(shift).move(-cam.x, -cam.y, -cam.z);
            float r, g, b;
            if (t instanceof Enemy) { r = 1f; g = 0.25f; b = 0.2f; }
            else if (t instanceof Player) { r = 0.3f; g = 0.9f; b = 1f; }
            else { r = 0.4f; g = 1f; b = 0.4f; }
            LevelRenderer.renderLineBox(ps, vc, box, r, g, b, 1f);
            // a second, smaller box marks the head
            LevelRenderer.renderLineBox(ps, vc, new AABB(head.x - 0.2, head.y - 0.2, head.z - 0.2, head.x + 0.2, head.y + 0.2, head.z + 0.2)
                    .move(-cam.x, -cam.y, -cam.z), r, g, b, 1f);
        }
        bs.endBatch(XrayRenderTypes.LINES);
    }
}
